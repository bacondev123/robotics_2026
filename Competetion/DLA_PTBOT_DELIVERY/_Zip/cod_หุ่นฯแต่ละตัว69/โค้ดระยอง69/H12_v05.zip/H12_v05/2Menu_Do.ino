/* -------------------------------------- DoMenuTest -------------------------------------- */
void DoMenuTest(char btn) {
  setAngleOffset();
  current_degree = 0;
  lcdSetTextSize(1);
  delay(300);  // หน่วงเวลาเล็กน้อยก่อนหุ่นพุ่งตัว

  if (X == 0) {
    if (btn == 'A') {
      assemblyMode();  // ประกอบ และปรับค่า Servo (ตั้งค่าเริ่มต้น, โหมดสลับกระป๋อง, ตั้งเซอร์โวหาหลุม)
    } else if (btn == 'B') {
      assemblyMode_switchCan();  // ปรับค่า Servo โหมดสลับกระป๋อง
    }
  } else if (X == 1) {
    if (btn == 'A') {
      assemblyMode_placeCan();  // ปรับค่า Servo ตั้งเซอร์โวหาหลุม
    } else if (btn == 'B') {
      ShowValue_Sensor();  // โชว์ค่าเซ็นเซอร์ตรวจจับเส้น
    }
  } else if (X == 2) {
    if (btn == 'A') {
      ShowDistanceSensor();  // โชว์ค่าเซ็นเซอร์วัดระยะทาง
    } else if (btn == 'B') {
      calibrateCanColor();  // Calibrate เซ็นเซอร์อ่านค่าสีกระป่อง
    }
  } else if (X == 3) {
    if (btn == 'A') {
      calibrateIMU();  // Calibrate เซ็นเซอร์ไจโร
    } else if (btn == 'B') {
      CheckColLoop();
    }
  } else if (X == 4) {
    if (btn == 'A') {
      autoPickCan(0);
    } else if (btn == 'B') {
      MBlock(60, 1, 'R');
    }
  } else if (X == 5) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 6) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 7) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 8) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 9) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 10) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 11) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 12) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 99) {
    if (btn == 'A') {
      beep(100);
    } else if (btn == 'B') {
      beep(100);
    }
  }

  motorStop();
  delay(100);
}
/* -------------------------------------- DoMenuRun -------------------------------------- */
void DoMenuRun(char btn) {
  setAngleOffset();
  current_degree = 0;
  lcdSetTextSize(1);
  delay(300);  // หน่วงเวลาเล็กน้อยก่อนหุ่นพุ่งตัว

  if (X == 0) {
    if (btn == 'A') {
      FullMap();
    } else if (btn == 'B') {
      SelectPlace();
    }
  } else if (X == 1) {
    if (btn == 'A') {
      
    } else if (btn == 'B') {
      
    }
  } else if (X == 2) {
    if (btn == 'A') {
      
    } else if (btn == 'B') {
      
    }
  } else if (X == 3) {
    if (btn == 'A') {
      
    } else if (btn == 'B') {
    }
  } else if (X == 4) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 5) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 6) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 7) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 8) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 9) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 10) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 11) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 12) {
    if (btn == 'A') {

    } else if (btn == 'B') {
    }
  } else if (X == 99) {
    if (btn == 'A') {
      beep(100);
    } else if (btn == 'B') {
      beep(100);
    }
  }

  motorStop();
  delay(100);
}