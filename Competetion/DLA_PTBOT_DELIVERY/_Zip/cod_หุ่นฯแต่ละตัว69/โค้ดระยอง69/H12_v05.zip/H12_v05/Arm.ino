void servoArmWrite(byte channel, byte degree) {
  if (channel <= 4) {
    byte servo_pin[] = { 12, 13, 14, 15 };
    if (degree < 0)
      degree = 0;
    else if (degree > 180)
      degree = 180;
    servo_arm.setPWM(servo_pin[channel], 0, map(degree, 0, 180, 111, 492));
  }
}

void measureRobot() {
  setupServo();
  lift(7);
  delay(700);
  servoArmWrite(chanal_Swing_Left, Stock_Left + 15);
  servoArmWrite(chanal_Swing_Right, Stock_Right + 15);
  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
}

void setupServo() {
  servo_arm.begin();
  servo_arm.setOscillatorFrequency(27000000);
  servo_arm.setPWMFreq(50);
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  servoArmWrite(chanal_Gripper_Right, Open_Right);
  servoWrite(chanal_Stock_Tray_Left, Tray_In_Left);
  servoWrite(chanal_Stock_Tray_Right, Tray_In_Right);
}

/*----------------------------------------------------------------------------------------*/

void retractArmIN() {
  servoArmWrite(chanal_Gripper_Left, Close_Left + 2);
  servoArmWrite(chanal_Gripper_Right, Close_Right + 2);
  servoArmWrite(chanal_Swing_Left, Swing_Left_center - 5);
  servoArmWrite(chanal_Swing_Right, Swing_Right_center - 5);
}

void retractArmIN_Setup() {
  servoArmWrite(chanal_Gripper_Left, Close_Left + 2);
  servoArmWrite(chanal_Gripper_Right, Close_Right + 2);
  servoArmWrite(chanal_Swing_Left, Swing_Left_center - 5);
  servoArmWrite(chanal_Swing_Right, Swing_Right_center - 5);
  delay(200);
  lift(2);
}

void retractArmIN_Can() {
  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  servoArmWrite(chanal_Swing_Left, swing_switch_can_left + swingL_IN);
  servoArmWrite(chanal_Swing_Right, swing_switch_can_right + swingR_IN);
}

void servoOpenLeft() {
  for (int i = Close_Left; i > Open_Left; i--) {
    servoArmWrite(chanal_Gripper_Left, i);
    delay(5);
  }
}

void servoCloseLeft() {
  servoArmWrite(chanal_Gripper_Left, Close_Left);
}

void servoOpenRight() {
  for (int i = Close_Right; i > Open_Right; i--) {
    servoArmWrite(chanal_Gripper_Right, i);
    delay(5);
  }
}

void servoCloseRight() {
  servoArmWrite(chanal_Gripper_Right, Close_Right);
}

void servoClose(int close_degree) {
  servoArmWrite(chanal_Gripper_Left, Close_Left + close_degree);
  servoArmWrite(chanal_Gripper_Right, Close_Right + close_degree);
}

void extendArm() {
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoOpenRight();
  servoOpenLeft();
}

void retractArm() {
  swingGripper('l', Swing_Left + 65);
  swingGripper('r', Swing_Right + 65);
}

void setCan() {
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  lift(3);
  delay(200);
  servoArmWrite(chanal_Gripper_Left, Close_Left - Open_Drop_Left + 2);
  servoArmWrite(chanal_Gripper_Right, Close_Right - Open_Drop_Right + 2);
  delay(200);
  lift(0);
  delay(300);
  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  delay(100);
  lift(3);
  delay(300);
}

/*----------------------------------------------------------------------------------------*/

void switchGripperLoop(void *pvParameters) {
  while (1) {
    if (switch_flag == -1) {
      servoArmWrite(chanal_Swing_Left, swing_switch_can_left);
      servoArmWrite(chanal_Gripper_Left, Open_Left);
      servoArmWrite(chanal_Swing_Right, Swing_Right + 10);
      delay(400);
      servoArmWrite(chanal_Swing_Right, swing_switch_can_right);
      delay(300);
      servoCloseLeft();
      delay(300);
      servoArmWrite(chanal_Gripper_Right, Open_Right - 5);
      delay(300);
      servoArmWrite(chanal_Swing_Left, Swing_Left);
      delay(300);
      switch_flag = 0;
    } else if (switch_flag == 1) {
      servoArmWrite(chanal_Swing_Right, swing_switch_can_right);
      servoArmWrite(chanal_Gripper_Right, Open_Right);
      servoArmWrite(chanal_Swing_Left, Swing_Left + 10);
      delay(400);
      servoArmWrite(chanal_Swing_Left, swing_switch_can_left);
      delay(300);
      servoCloseRight();
      delay(300);
      servoArmWrite(chanal_Gripper_Left, Open_Left - 5);
      delay(300);
      servoArmWrite(chanal_Swing_Right, Swing_Right);
      delay(300);
      switch_flag = 0;
    }
    vTaskDelay(10 / portTICK_PERIOD_MS);
  }
}

void switchGripper(char from_gripper, char to_gripper) {
  if (from_gripper == 'l' && to_gripper == 'r') switch_flag = 1;
  else if (from_gripper == 'r' && to_gripper == 'l') switch_flag = -1;
}

void swingGripper(char gripper, int degree) {
  if (gripper == 'l') {
    swing_current_degree[0] = degree;
    servoArmWrite(chanal_Swing_Left, swing_current_degree[0]);
  } else if (gripper == 'r') {
    swing_current_degree[1] = degree;
    servoArmWrite(chanal_Swing_Right, swing_current_degree[1]);
  }
}

/*----------------------------------------------------------------------------------------*/

void liftLoop(void *pvParameters) {
  const int CLK = 39;
  const int DT = 36;
  float error, previous_error = 0, integral = 0, derivative;
  float p_value, i_value, d_value, motor_speed;
  float Kp = 3.0, Ki = 0.001, Kd = 0.05;

  encoder.attachHalfQuad(DT, CLK);
  encoder.setCount(0);

  long last_encoder_count = 0;
  unsigned long last_change_time = millis();
  const unsigned long timeout_ms = 500;

  int last_lift_target = lift_target;
  bool stopped_due_to_timeout = false;

  while (1) {
    long current_count = encoder.getCount() / 2;
    error = current_count - lift_target;

    // ตรวจจับการเปลี่ยนแปลงของ encoder
    if (abs(abs(current_count) - abs(last_encoder_count)) > 5) {
      last_change_time = millis();
      last_encoder_count = current_count;
    }

    // ตรวจสอบว่ามีการเปลี่ยนแปลง lift_target หรือไม่
    if (lift_target != last_lift_target) {
      // หากเคยหยุดจาก timeout ให้เริ่มใหม่
      stopped_due_to_timeout = false;
      last_change_time = millis();
      integral = 0;
      previous_error = 0;
      last_lift_target = lift_target;
    }

    // หยุดหาก encoder ไม่ขยับเป็นระยะเวลาหนึ่ง
    if (!stopped_due_to_timeout && millis() - last_change_time > timeout_ms) {
      motorWrite(3, 0);
      stopped_due_to_timeout = true;
    }

    // หากอยู่ในสถานะหยุดจาก timeout ให้รอจน lift_target เปลี่ยนก่อนจะกลับมาทำงาน
    if (stopped_due_to_timeout) {
      vTaskDelay(10 / portTICK_PERIOD_MS);
      continue;
    }

    // PID control
    p_value = Kp * error;
    integral += error;
    i_value = Ki * integral;
    derivative = error - previous_error;
    d_value = Kd * derivative;
    motor_speed = p_value + i_value + d_value;

    motor_speed = constrain(motor_speed, -100, 100);

    if (abs(error) >= 5)
      motorWrite(3, motor_speed);
    else
      motorWrite(3, 0);

    previous_error = error;
    vTaskDelay(50 / portTICK_PERIOD_MS);
  }
}

void lift(int position) {
  if (position > 17) position = 17;
  lift_target = position * lift_Sensitivity;
  if (lift_target > 900) lift_target = 900;
}

/*----------------------------------------------------------------------------------------*/

void stockLoop(void *pvParameters) {
  while (1) {
    if (stock_flag == -1) {  // stock in left
      lift(13);
      while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
      servoWrite(chanal_Stock_Tray_Left, Tray_Out_Left);
      servoArmWrite(chanal_Swing_Left, Stock_Left);
      delay(800);
      lift(9);
      while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
      delay(300);
      servoArmWrite(chanal_Gripper_Left, Close_Left - 15);
      delay(200);
      servoArmWrite(chanal_Gripper_Left, 0);
      delay(200);
      servoWrite(chanal_Stock_Tray_Left, Tray_In_Left);
      delay(200);
      servoArmWrite(chanal_Swing_Left, Swing_Left);
      servoArmWrite(chanal_Gripper_Left, Close_Left);
      lift(3);
      stock_flag = 0;
    } else if (stock_flag == 1) {  // stock out left
      lift(7);
      while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
      servoArmWrite(chanal_Gripper_Left, 0);
      servoArmWrite(chanal_Swing_Left, Stock_Left);
      delay(500);
      servoWrite(chanal_Stock_Tray_Left, Tray_Out_Left);
      delay(200);
      servoArmWrite(chanal_Gripper_Left, Close_Left - Open_Drop_Left);
      delay(300);
      lift(5);
      while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
      delay(300);
      servoArmWrite(chanal_Gripper_Left, Close_Left + 3);
      delay(200);
      lift(15);
      delay(400);
      servoArmWrite(chanal_Swing_Left, Swing_Left);
      servoWrite(chanal_Stock_Tray_Left, Tray_In_Left);
      can_in_gripper[0] = can_in_stock[0];
      can_in_stock[0] = 'u';
      delay(500);
      lift(3);
      servoArmWrite(chanal_Gripper_Left, Close_Left);
      stock_flag = 0;
    } else if (stock_flag == -2) {  // stock in right
      lift(13);
      while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
      servoWrite(chanal_Stock_Tray_Right, Tray_Out_Right);
      servoArmWrite(chanal_Swing_Right, Stock_Right);
      delay(800);
      lift(9);
      while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
      delay(300);
      servoArmWrite(chanal_Gripper_Right, Close_Right - 15);
      delay(200);
      servoArmWrite(chanal_Gripper_Right, 0);
      delay(200);
      servoWrite(chanal_Stock_Tray_Right, Tray_In_Right);
      delay(200);
      servoArmWrite(chanal_Swing_Right, Swing_Right);
      servoArmWrite(chanal_Gripper_Right, Close_Right);
      lift(3);
      stock_flag = 0;
    } else if (stock_flag == 2) {  // stock out right
      lift(7);
      while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
      servoArmWrite(chanal_Gripper_Right, 0);
      servoArmWrite(chanal_Swing_Right, Stock_Right);
      delay(500);
      servoWrite(chanal_Stock_Tray_Right, Tray_Out_Right);
      delay(200);
      servoArmWrite(chanal_Gripper_Right, Close_Right - Open_Drop_Right);
      delay(300);
      motorWrite(3, 50);
      delay(150);
      motorStop();
      servoArmWrite(chanal_Gripper_Right, Close_Right + 3);
      delay(200);
      lift(15);
      delay(400);
      servoArmWrite(chanal_Swing_Right, Swing_Right);
      servoWrite(chanal_Stock_Tray_Right, Tray_In_Right);
      can_in_gripper[1] = can_in_stock[1];
      can_in_stock[1] = 'u';
      delay(500);
      lift(3);
      servoArmWrite(chanal_Gripper_Right, Close_Right);
      stock_flag = 0;
    }
    vTaskDelay(100 / portTICK_PERIOD_MS);
  }
}

void stockIn(char stock, char color, bool wait) {
  switch_flag = 0;
  if (stock == 'l') {
    stock_flag = -1;
    can_in_stock[0] = color;
  } else if (stock == 'r') {
    stock_flag = -2;
    can_in_stock[1] = color;
  }
  if (wait == true) {
    while (1) {
      if (stock_flag == 0) break;
      delay(10);
    }
  }
}

void stockOut(char stock, bool wait) {
  switch_flag = 0;
  if (stock == 'l') stock_flag = 1;
  else if (stock == 'r') stock_flag = 2;
  if (wait == true) {
    while (1) {
      if (stock_flag == 0) break;
      delay(10);
    }
  }
}

/*----------------------------------------------------------------------------------------*/
void moveToCanPick_floor(float distance) {
  // vTaskResume(sonarTaskHandle);
  // sonar_enable = 1;
  // delay(200);
  // unsigned long int timer = millis();
  // while (readSonar() > distance + 10 && millis() - timer <= 10000) FF(speed_pick_can);
  // timer = millis();
  // delay(50);
  // while (readSonar() > distance && millis() - timer <= 10000) FF(speed_pick_can_slow);
  // FF(10);
  // delay(40);
  // motorStop();
  // vTaskSuspend(sonarTaskHandle);
  // sonar_enable = 0;
  //--------------------------------------------------------------
  FF(15, 1250);
  FF(10, distance);
  motorStop();
}

void moveToCanPick(float distance) {
  vTaskResume(sonarTaskHandle);
  sonar_enable = 1;
  delay(200);
  unsigned long int timer = millis();
  while (readSonar() > distance + 10 && millis() - timer <= 10000) FF(speed_pick_can);
  timer = millis();
  delay(50);
  while (readSonar() > distance && millis() - timer <= 10000) FF(speed_pick_can_slow);
  FF(10);
  delay(40);
  motorStop();
  vTaskSuspend(sonarTaskHandle);
  sonar_enable = 0;
}

void moveToCanPlace(float distance) {
  vTaskResume(sonarTaskHandle);
  sonar_enable = 1;
  delay(200);
  unsigned long int timer = millis();
  while (readSonar() > distance + 10 && millis() - timer <= 10000) FF(speed_place_can);
  timer = millis();
  delay(75);
  while (readSonar() > distance && millis() - timer <= 10000) FF(speed_place_can_slow);
  // FF(10);
  // delay(5);
  motorStop();
  vTaskSuspend(sonarTaskHandle);
  sonar_enable = 0;
}

void moveToCan(float distance) {
  vTaskResume(sonarTaskHandle);
  sonar_enable = 1;
  delay(200);
  unsigned long int timer = millis();
  while (readSonar() > distance || millis() - timer <= 500) FF(15);
  FF(10, 250);
  motorStop();
  vTaskSuspend(sonarTaskHandle);
  sonar_enable = 0;
}

void moveToCanTime(int time) {
  unsigned long int timer = millis();
  while (millis() - timer < time) FF(15);
  motorStop();
}

void shakeGripper(char gripper) {
  int increment = 1;
  delayTime = 15;
  swingRange = 11;  // 10
  int count_swing = 0;
  if (gripper == 'a') count_swing = 2;
  else count_swing = 3;
  for (int i = 0; i < count_swing; i++) {
    if (gripper == 'l' || gripper == 'a') {
      for (int i = 0; i <= swingRange; i += increment) {
        servoArmWrite(chanal_Swing_Left, swing_current_degree[0] - i);
        if (gripper == 'a') servoArmWrite(chanal_Swing_Right, swing_current_degree[1] - i);
        delay(delayTime);
      }
      for (int i = 0; i <= swingRange * 2; i += increment) {
        servoArmWrite(chanal_Swing_Left, swing_current_degree[0] - swingRange + i);
        if (gripper == 'a') servoArmWrite(chanal_Swing_Right, swing_current_degree[1] - swingRange + i);
        delay(delayTime);
      }
      for (int i = 0; i <= swingRange; i += increment) {
        servoArmWrite(chanal_Swing_Left, swing_current_degree[0] + swingRange - i);
        if (gripper == 'a') servoArmWrite(chanal_Swing_Right, swing_current_degree[1] + swingRange - i);
        delay(delayTime);
      }
    }
    if (gripper == 'r' || gripper == 'a') {
      for (int i = 0; i <= swingRange; i += increment) {
        servoArmWrite(chanal_Swing_Right, swing_current_degree[1] - i);
        if (gripper == 'a') servoArmWrite(chanal_Swing_Left, swing_current_degree[0] - i);
        delay(delayTime);
      }
      for (int i = 0; i <= swingRange * 2; i += increment) {
        servoArmWrite(chanal_Swing_Right, swing_current_degree[1] - swingRange + i);
        if (gripper == 'a') servoArmWrite(chanal_Swing_Left, swing_current_degree[0] - swingRange + i);
        delay(delayTime);
      }
      for (int i = 0; i <= swingRange; i += increment) {
        servoArmWrite(chanal_Swing_Right, swing_current_degree[1] + swingRange - i);
        if (gripper == 'a') servoArmWrite(chanal_Swing_Left, swing_current_degree[0] + swingRange - i);
        delay(delayTime);
      }
    }
  }
}

void dropCan(char gripper) {
  if (gripper == 'l') {
    servoArmWrite(chanal_Gripper_Left, Close_Left - Open_Drop_Left);
    shakeGripper('l');
    delay(200);
    servoArmWrite(chanal_Gripper_Left, Open_Left - 10);
  } else if (gripper == 'r') {
    servoArmWrite(chanal_Gripper_Right, Close_Right - Open_Drop_Right);
    shakeGripper('r');
    delay(200);
    servoArmWrite(chanal_Gripper_Right, Open_Right - 10);
  } else if (gripper == 'a') {
    servoArmWrite(chanal_Gripper_Left, Close_Left - Open_Drop_Left);
    servoArmWrite(chanal_Gripper_Right, Close_Right - Open_Drop_Right);
    shakeGripper('a');
    delay(200);
    servoArmWrite(chanal_Gripper_Left, Open_Left - 10);
    servoArmWrite(chanal_Gripper_Right, Open_Right - 10);
  }
}

void dropCan(int drop_height, char gripper) {
  if (gripper == 'l') {
    lift(drop_height - 1);
    // while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
    delay(100);
    servoArmWrite(chanal_Gripper_Left, Close_Left - Open_Drop_Left);
    delay(200);
    lift(drop_height + 1);
    delay(100);
    shakeGripper('l');
    delay(100);
    servoArmWrite(chanal_Gripper_Left, Open_Left - 10);
  } else if (gripper == 'r') {
    lift(drop_height - 1);
    // while (abs((encoder.getCount() / 2) - lift_target) > 60) { delay(10); }
    delay(100);
    servoArmWrite(chanal_Gripper_Right, Close_Right - Open_Drop_Right);
    delay(200);
    lift(drop_height + 2);
    delay(100);
    shakeGripper('r');
    delay(100);
    servoArmWrite(chanal_Gripper_Right, Open_Right - 10);
  } else if (gripper == 'a') {
    lift(drop_height - 1);
    // while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
    delay(100);
    servoArmWrite(chanal_Gripper_Left, Close_Left - Open_Drop_Left);
    servoArmWrite(chanal_Gripper_Right, Close_Right - Open_Drop_Right);
    delay(200);
    lift(drop_height + 1);
    delay(100);
    shakeGripper('a');
    delay(100);
    servoArmWrite(chanal_Gripper_Left, Open_Left - 10);
    servoArmWrite(chanal_Gripper_Right, Open_Right - 10);
  }
}

void stock() {
  // ซ้าย ขวา สีป๋องสลับกัน
  if (mode_Switch_Can_Color == true) {
    if (((hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'l')) || ((hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') && (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'l')) || ((hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'c')) || ((hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') && (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'c')) || ((hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') && (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'r')) || ((hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') && (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'r'))) {
      if (can_in_stock[0] == 'u') {
        stockIn('l', can_in_gripper[0], true);
        can_in_gripper[0] = 'u';
      } else if (can_in_stock[1] == 'u') {
        stockIn('r', can_in_gripper[1], true);
        can_in_gripper[1] = 'u';
      }
      delay(200);
      lift(3);
      retractArmIN_Can();
      delay(200);
    }
  }
  // ซ้าย ขวา สีป๋องเหมือนกัน
  if (can_in_gripper[0] == can_in_gripper[1]) {
    if (can_in_gripper[0] == 'r') {
      if (can_in_stock[0] == 'u') {
        stockIn('l', can_in_gripper[0], true);
        can_in_gripper[0] = 'u';
        can_in_gripper[1] = 'r';
      } else if (can_in_stock[1] == 'u') {
        stockIn('r', can_in_gripper[0], true);
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'u';
      } else {
        while (1) {
          beep(10000);
        }
      }
    } else {
      if (can_in_gripper[0] == 'g') can_in_gripper[0] = 'l';
      else if (can_in_gripper[0] == 'y') can_in_gripper[0] = 'c';
      if (can_in_stock[1] == 'u') {
        stockIn('r', can_in_gripper[0], true);
        can_in_gripper[1] = 'u';
      } else if (can_in_stock[0] == 'u') {
        stockIn('l', can_in_gripper[0], true);
        can_in_gripper[1] = can_in_gripper[0];
        can_in_gripper[0] = 'u';
      } else {
        while (1) {
          beep(10000);
        }
      }
    }
    delay(200);
    lift(3);
    retractArmIN_Can();
    delay(200);
  }

  // ซ้าย ขวา สีป๋องไม่เหมือนกัน
  else {
    lift(3);
    retractArmIN_Can();
  }
}

/*----------------------------------------------------------------------------------------*/

void autoPickCan(int pick_height) {
  if (pick_height != 0) autoPickCan(pick_height, pick_can_distance);
  else autoPickCan(pick_height, pick_can_floor);
  setCan();
  retractArmIN_Can();
}

void autoPickCan(int pick_height, float distance) {
  servoArmWrite(chanal_Swing_Left, Swing_Left - 0);
  servoArmWrite(chanal_Swing_Right, Swing_Right - 0);
  servoArmWrite(chanal_Gripper_Left, Open_Left - 15);
  servoArmWrite(chanal_Gripper_Right, Open_Right - 15);
  lift(pick_height);
  if (pick_height != 0) moveToCanPick(distance);
  else moveToCanPick_floor(distance);  // moveToCanPick(distance);
  servoArmWrite(chanal_Gripper_Left, Close_Left - Open_Drop_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right - Open_Drop_Right);
  motorWrite(3, 50);
  delay(100);
  motorStop();
  delay(300);
  servoCloseLeft();
  servoCloseRight();
  delay(200);
  lift(pick_height + 3);
  delay(300);
  can_in_gripper[0] = readColor('l');
  can_in_gripper[1] = readColor('r');
  count_pick += 1;
  if (count_pick == 3 && (can_in_gripper[0] == can_in_gripper[1])) {
    State_EndMission = true;
  } else if (mode_Switch_Can_Color == false) {
    if (((hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'g')) || ((hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') && (can_in_gripper[0] == 'y' && can_in_gripper[1] == 'g')) || ((hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'y')) || ((hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') && (can_in_gripper[0] == 'g' && can_in_gripper[1] == 'y')) || ((hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') && (can_in_gripper[0] == 'y' && can_in_gripper[1] == 'r')) || ((hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') && (can_in_gripper[0] == 'g' && can_in_gripper[1] == 'r'))) {
      swingGripper('r', Swing_Right + 10);
      for (int i = Swing_Left; i > swing_switch_can_left; i -= 1) {
        swingGripper('l', i);
        delay(15);
      }
      vTaskResume(switchGripperTaskHandle);
      delay(10);
      lift(pick_height);
      delay(200);
      for (int i = Close_Left; i > Open_Left; i -= 1) {
        servoArmWrite(chanal_Gripper_Left, i);
        delay(15);
      }
      for (int i = swing_switch_can_left; i < swing_switch_can_left + 5; i += 1) {
        swingGripper('l', i);
        delay(5);
      }
      lift(pick_height + 3);
      BB(30, 350);
      switchGripper('r', 'l');
      delay(1800);
      swingGripper('l', Swing_Left_side);
      swingGripper('r', swing_switch_can_right);
      servoArmWrite(chanal_Gripper_Right, Open_Right - 10);
      delay(200);
      if (pick_height != 0) FF(15, switch_moveToPickCan_distance);  // ระยะทางเดินเข้าไปหยิบป๋องที่สลับไว้บนแท่น
      else FF(15, switch_moveToPickCan_distance_floor);             // ระยะทางเดินเข้าไปหยิบป๋องที่สลับไว้ที่พื้น
      lift(pick_height);
      delay(300);
      servoCloseRight();
      delay(200);
      lift(pick_height + 2);
      vTaskSuspend(switchGripperTaskHandle);
      if (hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') {
        can_in_gripper[0] = 'l';
        can_in_gripper[1] = 'r';
      }
      if (hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') {
        can_in_gripper[0] = 'l';
        can_in_gripper[1] = 'c';
      }
      if (hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') {
        can_in_gripper[0] = 'c';
        can_in_gripper[1] = 'r';
      }
      if (hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') {
        can_in_gripper[0] = 'c';
        can_in_gripper[1] = 'l';
      }
      if (hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') {
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'c';
      }
      if (hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') {
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'l';
      }
    } else {
      if (can_in_gripper[0] == 'r') can_in_gripper[0] = 'r';
      else if (can_in_gripper[0] == 'g') can_in_gripper[0] = 'l';
      else if (can_in_gripper[0] == 'y') can_in_gripper[0] = 'c';
      if (can_in_gripper[1] == 'r') can_in_gripper[1] = 'r';
      else if (can_in_gripper[1] == 'g') can_in_gripper[1] = 'l';
      else if (can_in_gripper[1] == 'y') can_in_gripper[1] = 'c';
    }
  } else if (mode_Switch_Can_Color == true) {
    if (can_in_gripper[0] == 'r') can_in_gripper[0] = 'r';
    else if (can_in_gripper[0] == 'g') can_in_gripper[0] = 'l';
    else if (can_in_gripper[0] == 'y') can_in_gripper[0] = 'c';
    if (can_in_gripper[1] == 'r') can_in_gripper[1] = 'r';
    else if (can_in_gripper[1] == 'g') can_in_gripper[1] = 'l';
    else if (can_in_gripper[1] == 'y') can_in_gripper[1] = 'c';
  }
  BB(30, after_pick_can_distance);
  lift(3);
}

void autoPickCan_stick(int pick_height) {
  if (pick_height != 0) autoPickCan_stick(pick_height, pick_can_distance);
  else autoPickCan_stick(pick_height, pick_can_floor);
}

void autoPickCan_stick(int pick_height, float distance) {
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  servoArmWrite(chanal_Gripper_Right, Open_Right);
  lift(pick_height);
  delay(500);
  moveToCanPick(distance);
  delay(200);
  servoArmWrite(chanal_Gripper_Left, Close_Left - Open_Drop_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right - Open_Drop_Right);
  motorWrite(3, 50);
  delay(120);
  motorStop();
  delay(200);
  servoCloseLeft();
  servoCloseRight();
  delay(200);
  lift(pick_height + 3);
  delay(300);
  can_in_gripper[0] = readColor('l');
  can_in_gripper[1] = readColor('r');
  count_pick += 1;
  if (count_pick == 3 && (can_in_gripper[0] == can_in_gripper[1])) {
    State_EndMission = true;
  } else if (mode_Switch_Can_Color == false) {
    if (((hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'g')) || ((hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') && (can_in_gripper[0] == 'y' && can_in_gripper[1] == 'g')) || ((hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'y')) || ((hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') && (can_in_gripper[0] == 'g' && can_in_gripper[1] == 'y')) || ((hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') && (can_in_gripper[0] == 'y' && can_in_gripper[1] == 'r')) || ((hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') && (can_in_gripper[0] == 'g' && can_in_gripper[1] == 'r'))) {
      swingGripper('r', Swing_Right + 10);
      for (int i = Swing_Left; i > swing_switch_can_left; i -= 1) {
        swingGripper('l', i);
        delay(15);
      }
      vTaskResume(switchGripperTaskHandle);
      delay(10);
      lift(pick_height);
      delay(200);
      for (int i = Close_Left; i > Open_Left; i -= 1) {
        servoArmWrite(chanal_Gripper_Left, i);
        delay(15);
      }
      for (int i = swing_switch_can_left; i < swing_switch_can_left + 5; i += 1) {
        swingGripper('l', i);
        delay(5);
      }
      lift(pick_height + 3);
      BB(30, 350);
      switchGripper('r', 'l');
      delay(1800);
      swingGripper('l', Swing_Left_side);
      swingGripper('r', swing_switch_can_right);
      servoArmWrite(chanal_Gripper_Right, Open_Right - 10);
      delay(200);
      if (pick_height != 0) FF(15, switch_moveToPickCan_distance);  // ระยะทางเดินเข้าไปหยิบป๋องที่สลับไว้บนแท่น
      else FF(15, switch_moveToPickCan_distance_floor);             // ระยะทางเดินเข้าไปหยิบป๋องที่สลับไว้ที่พื้น
      lift(pick_height);
      delay(300);
      servoCloseRight();
      delay(200);
      lift(pick_height + 2);
      vTaskSuspend(switchGripperTaskHandle);
      if (hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') {
        can_in_gripper[0] = 'l';
        can_in_gripper[1] = 'r';
      }
      if (hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') {
        can_in_gripper[0] = 'l';
        can_in_gripper[1] = 'c';
      }
      if (hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') {
        can_in_gripper[0] = 'c';
        can_in_gripper[1] = 'r';
      }
      if (hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') {
        can_in_gripper[0] = 'c';
        can_in_gripper[1] = 'l';
      }
      if (hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') {
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'c';
      }
      if (hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') {
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'l';
      }
    } else {
      if (can_in_gripper[0] == 'r') can_in_gripper[0] = 'r';
      else if (can_in_gripper[0] == 'g') can_in_gripper[0] = 'l';
      else if (can_in_gripper[0] == 'y') can_in_gripper[0] = 'c';
      if (can_in_gripper[1] == 'r') can_in_gripper[1] = 'r';
      else if (can_in_gripper[1] == 'g') can_in_gripper[1] = 'l';
      else if (can_in_gripper[1] == 'y') can_in_gripper[1] = 'c';
    }
  } else if (mode_Switch_Can_Color == true) {
    if (can_in_gripper[0] == 'r') can_in_gripper[0] = 'r';
    else if (can_in_gripper[0] == 'g') can_in_gripper[0] = 'l';
    else if (can_in_gripper[0] == 'y') can_in_gripper[0] = 'c';
    if (can_in_gripper[1] == 'r') can_in_gripper[1] = 'r';
    else if (can_in_gripper[1] == 'g') can_in_gripper[1] = 'l';
    else if (can_in_gripper[1] == 'y') can_in_gripper[1] = 'c';
  }
  retractArmIN_Can();
  BB(20, 450);
  lift(3);
}

void placeCan1(int drop_height, int distance, char from_gripper, char drop_point) {
  bool switch_can = 0;
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Close_Left + 3);
  servoArmWrite(chanal_Gripper_Right, Close_Right + 3);
  lift(drop_height + 3);
  delay(300);
  if (from_gripper == 'l' && drop_point == 'l') {
    swingGripper('l', Swing_Left_side);
    swingGripper('r', Stock_Right + 5);
  } else if (from_gripper == 'l' && drop_point == 'c') {
    swingGripper('l', Swing_Left_center);
    swingGripper('r', Stock_Right + 5);
  } else if (from_gripper == 'r' && drop_point == 'r') {
    swingGripper('l', Stock_Left + 5);
    swingGripper('r', Swing_Right_side);
  } else if (from_gripper == 'r' && drop_point == 'c') {
    swingGripper('l', Stock_Left + 5);
    swingGripper('r', Swing_Right_center);
  } else {
    vTaskResume(switchGripperTaskHandle);
    delay(10);
    switchGripper(from_gripper, drop_point);
    switch_can = 1;
  }
  delay(300);
  moveToCanPlace(place_can_distance);
  motorStop();
  delay(200);
  setAngleOffset();
  current_degree = 0;
  BB(10, distance);
  if (switch_can == 0) dropCan(drop_height, from_gripper);
  else dropCan(drop_height, drop_point);
  delay(200);
  vTaskSuspend(switchGripperTaskHandle);
}

void placeCan2(int drop_height, int distance, char left_gripper, char right_gripper) {
  bool switch_can = 0;
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Close_Left + 3);
  servoArmWrite(chanal_Gripper_Right, Close_Right + 3);
  lift(drop_height + 3);
  if (left_gripper == 'l' && right_gripper == 'r') {
    swingGripper('l', Swing_Left_side);
    swingGripper('r', Swing_Right_side);
  } else if (left_gripper == 'l' && right_gripper == 'c') {
    swingGripper('l', Swing_Left_side);
    swingGripper('r', Swing_Right_center);
  } else if (left_gripper == 'c' && right_gripper == 'r') {
    swingGripper('l', Swing_Left_center);
    swingGripper('r', Swing_Right_side);
  }
  moveToCanPlace(place_can_distance);
  motorStop();
  delay(200);
  setAngleOffset();
  current_degree = 0;
  BB(10, distance);
  if (left_gripper == 'l' && right_gripper == 'r') {
    dropCan(drop_height, 'a');
  } else if (left_gripper == 'l' && right_gripper == 'c') {
    dropCan(drop_height, 'r');
    lift(drop_height + 3);
    delay(200);
    BB(10, 150);
    dropCan(drop_height, 'l');
  } else if (left_gripper == 'c' && right_gripper == 'r') {
    dropCan(drop_height, 'l');
    lift(drop_height + 3);
    delay(200);
    BB(10, 150);
    dropCan(drop_height, 'r');
  }
  delay(200);
  vTaskSuspend(switchGripperTaskHandle);
}

void autoPlaceCan2(int drop_height, char left_gripper, char right_gripper) {
  servoArmWrite(chanal_Gripper_Left, Close_Left + 3);
  servoArmWrite(chanal_Gripper_Right, Close_Right + 3);
  lift(drop_height + 3);
  if (left_gripper == 'r' && right_gripper == 'l') {
    lift(1);
    delay(300);
    swingGripper('l', swing_switch_can_left);
    swingGripper('r', Swing_Right);
    vTaskResume(switchGripperTaskHandle);
    delay(10);
    delay(200);
    for (int i = Close_Left; i > Open_Left; i -= 1) {
      servoArmWrite(chanal_Gripper_Left, i);
      delay(10);
    }
    delay(200);
    servoArmWrite(chanal_Gripper_Left, Open_Left);
    lift(12);
    delay(600);
    switchGripper('r', 'l');
    delay(1800);
    servoArmWrite(chanal_Gripper_Right, Open_Right - 10);
    swingGripper('r', swing_switch_can_right);
    delay(200);
    lift(0);
    delay(600);
    servoCloseRight();
    delay(200);
    lift(drop_height + 3);
    vTaskSuspend(switchGripperTaskHandle);
    servoArmWrite(chanal_Swing_Left, Swing_Left);
    servoArmWrite(chanal_Swing_Right, Swing_Right);
    placeCan1(drop_height, place_left_side, 'l', 'l');
    if (state_pick == false) BB(30, after_place_can_distance);
    else BB(30, 400);
    delay(200);
    placeCan1(drop_height, place_right_side, 'r', 'r');
  } else {
    if (left_gripper == 'l' && right_gripper == 'r') {
      // placeCan2(drop_height, place_LR, 'l', 'r');
      placeCan1(drop_height, place_left_side, 'l', 'l');
      if (state_pick == false) BB(30, after_place_can_distance);
      else BB(30, 400);
      delay(200);
      placeCan1(drop_height, place_right_side, 'r', 'r');
    } else if (left_gripper == 'l' && right_gripper == 'c') {
      // placeCan2(drop_height, place_right_center, 'l', 'c');
      placeCan1(drop_height, place_right_center, 'r', 'c');
      if (state_pick == false) BB(30, after_place_can_distance);
      else BB(30, 400);
      delay(200);
      placeCan1(drop_height, place_left_side, 'l', 'l');
    } else if (left_gripper == 'c' && right_gripper == 'r') {
      // placeCan2(drop_height, place_left_center, 'c', 'r');
      placeCan1(drop_height, place_left_center, 'l', 'c');
      if (state_pick == false) BB(30, after_place_can_distance);
      else BB(30, 400);
      delay(200);
      placeCan1(drop_height, place_right_side, 'r', 'r');
    } else {
      if (left_gripper == 'c') {
        placeCan1(drop_height, place_left_center, 'l', 'c');
        if (state_pick == false) BB(30, after_place_can_distance);
        else BB(30, 400);
        lift(drop_height + 3);
        vTaskResume(switchGripperTaskHandle);
        delay(10);
        switchGripper('r', 'l');
        delay(1800);
        placeCan1(drop_height, place_left_side, 'l', 'l');
        vTaskSuspend(switchGripperTaskHandle);
      } else if (right_gripper == 'c') {
        placeCan1(drop_height, place_right_center, 'r', 'c');
        if (state_pick == false) BB(30, after_place_can_distance);
        else BB(30, 400);
        lift(drop_height + 3);
        vTaskResume(switchGripperTaskHandle);
        delay(10);
        switchGripper('l', 'r');
        delay(1800);
        placeCan1(drop_height, place_right_side, 'r', 'r');
        vTaskSuspend(switchGripperTaskHandle);
      }
    }
  }
  delay(200);
}

/* --------------------------------------แบบเช็คหลุมวางป๋อง-------------------------------------- */
void placeCan_Fix(int drop_height) {
  // case 1 เขียว เหลือง แดง
  if (hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') {
    // เขียว เหลือง
    if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'l', 'c');

    // เขียว แดง
    else if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'l', 'r');

    // เหลือง เขียว
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'c', 'l');

    // เหลือง แดง
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'c', 'r');

    // แดง เขียว
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'r', 'l');

    // แดง เหลือง
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'r', 'c');

    // กรณีมีกระป๋องเดียวในมือ เขียว แดง เหลือง
    else {
      /*---------------------------มือซ้าย----------------------------*/
      if (can_in_gripper[0] == 'r') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('l', 'r');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_right_side, 'r', 'r');
      }

      if (can_in_gripper[0] == 'l')
        placeCan1(drop_height, place_left_side, 'l', 'l');

      else if (can_in_gripper[0] == 'c')
        placeCan1(drop_height, place_left_center, 'l', 'c');

      /*---------------------------มือขวา----------------------------*/
      else if (can_in_gripper[1] == 'l') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('r', 'l');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_left_side, 'l', 'l');
      }

      else if (can_in_gripper[1] == 'r')
        placeCan1(drop_height, place_right_side, 'r', 'r');

      else if (can_in_gripper[1] == 'c')
        placeCan1(drop_height, place_right_center, 'r', 'c');
    }
  }

  // case 2 เขียว แดง เหลือง
  if (hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') {
    // เขียว เหลือง
    if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'l', 'r');

    // เขียว แดง
    else if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'l', 'c');

    // เหลือง เขียว
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'r', 'l');

    // เหลือง แดง
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'r', 'c');

    // แดง เขียว
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'c', 'l');

    // แดง เหลือง
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'c', 'r');

    // กรณีมีกระป๋องเดียวในมือ เขียว แดง เหลือง
    else {
      /*---------------------------มือซ้าย----------------------------*/
      if (can_in_gripper[0] == 'c') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('l', 'r');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_right_side, 'r', 'r');
      }

      if (can_in_gripper[0] == 'l')
        placeCan1(drop_height, place_left_side, 'l', 'l');

      else if (can_in_gripper[0] == 'r')
        placeCan1(drop_height, place_left_center, 'l', 'c');

      /*---------------------------มือขวา----------------------------*/
      else if (can_in_gripper[1] == 'l') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('r', 'l');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_left_side, 'l', 'l');
      }

      else if (can_in_gripper[1] == 'c')
        placeCan1(drop_height, place_right_side, 'r', 'r');

      else if (can_in_gripper[1] == 'r')
        placeCan1(drop_height, place_right_center, 'r', 'c');
    }
  }

  // case 3 เหลือง เขียว แดง
  if (hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') {
    // เขียว เหลือง
    if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'c', 'l');

    // เขียว แดง
    else if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'c', 'r');

    // เหลือง เขียว
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'l', 'c');

    // เหลือง แดง
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'l', 'r');

    // แดง เขียว
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'r', 'c');

    // แดง เหลือง
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'r', 'l');

    // กรณีมีกระป๋องเดียวในมือ เขียว แดง เหลือง
    else {
      /*---------------------------มือซ้าย----------------------------*/
      if (can_in_gripper[0] == 'r') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('l', 'r');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_right_side, 'r', 'r');
      }

      else if (can_in_gripper[0] == 'c')
        placeCan1(drop_height, place_left_side, 'l', 'l');

      else if (can_in_gripper[0] == 'l')
        placeCan1(drop_height, place_left_center, 'l', 'c');

      /*---------------------------มือขวา----------------------------*/
      if (can_in_gripper[1] == 'c') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('r', 'l');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_left_side, 'l', 'l');
      }

      else if (can_in_gripper[1] == 'r')
        placeCan1(drop_height, place_right_side, 'r', 'r');

      else if (can_in_gripper[1] == 'l')
        placeCan1(drop_height, place_right_center, 'r', 'c');
    }
  }

  // case 4 เหลือง แดง เขียว
  if (hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') {
    // เขียว เหลือง
    if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'r', 'l');

    // เขียว แดง
    else if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'r', 'c');

    // เหลือง เขียว
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'l', 'r');

    // เหลือง แดง
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'l', 'c');

    // แดง เขียว
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'c', 'r');

    // แดง เหลือง
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'c', 'l');

    // กรณีมีกระป๋องเดียวในมือ เหลือง แดง เขียว
    else {
      /*---------------------------มือซ้าย----------------------------*/
      if (can_in_gripper[0] == 'l') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('l', 'r');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_right_side, 'r', 'r');
      }

      else if (can_in_gripper[0] == 'c')
        placeCan1(drop_height, place_left_side, 'l', 'l');

      else if (can_in_gripper[0] == 'r')
        placeCan1(drop_height, place_left_center, 'l', 'c');

      /*---------------------------มือขวา----------------------------*/
      if (can_in_gripper[1] == 'c') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('r', 'l');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_left_side, 'l', 'l');
      }

      else if (can_in_gripper[1] == 'l')
        placeCan1(drop_height, place_right_side, 'r', 'r');

      else if (can_in_gripper[1] == 'r')
        placeCan1(drop_height, place_right_center, 'r', 'c');
    }
  }

  // case 5 แดง เขียว เหลือง
  if (hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') {
    // เขียว เหลือง
    if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'c', 'r');

    // เขียว แดง
    else if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'c', 'l');

    // เหลือง เขียว
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'r', 'c');

    // เหลือง แดง
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'r', 'l');

    // แดง เขียว
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'l', 'c');

    // แดง เหลือง
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'l', 'r');

    // กรณีมีกระป๋องเดียวในมือ แดง เขียว เหลือง
    else {
      /*---------------------------มือซ้าย----------------------------*/
      if (can_in_gripper[0] == 'c') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('l', 'r');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_right_side, 'r', 'r');
      }

      else if (can_in_gripper[0] == 'r')
        placeCan1(drop_height, place_left_side, 'l', 'l');

      else if (can_in_gripper[0] == 'l')
        placeCan1(drop_height, place_left_center, 'l', 'c');

      /*---------------------------มือขวา----------------------------*/
      else if (can_in_gripper[1] == 'r') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('r', 'l');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_left_side, 'l', 'l');
      }

      else if (can_in_gripper[1] == 'c')
        placeCan1(drop_height, place_right_side, 'r', 'r');

      else if (can_in_gripper[1] == 'l')
        placeCan1(drop_height, place_right_center, 'r', 'c');
    }
  }

  // case 6 แดง เหลือง เขียว
  if (hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') {
    // เขียว เหลือง
    if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'r', 'c');

    // เขียว แดง
    else if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'r', 'l');

    // เหลือง เขียว
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'c', 'r');

    // เหลือง แดง
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'c', 'l');

    // แดง เขียว
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'l', 'r');

    // แดง เหลือง
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'l', 'c');

    // กรณีมีกระป๋องเดียวในมือ แดง เหลือง เขียว
    else {
      /*---------------------------มือซ้าย----------------------------*/
      if (can_in_gripper[0] == 'l') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('l', 'r');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_right_side, 'r', 'r');
      }

      else if (can_in_gripper[0] == 'r')
        placeCan1(drop_height, place_left_side, 'l', 'l');

      else if (can_in_gripper[0] == 'c')
        placeCan1(drop_height, place_left_center, 'l', 'c');

      /*---------------------------มือขวา----------------------------*/
      else if (can_in_gripper[1] == 'r') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('r', 'l');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_left_side, 'l', 'l');
      }

      else if (can_in_gripper[1] == 'l')
        placeCan1(drop_height, place_right_side, 'r', 'r');

      else if (can_in_gripper[1] == 'c')
        placeCan1(drop_height, place_right_center, 'r', 'c');
    }
  }

  // 7.เขียว เขียว เขียว
  // 8.เขียว เขียว เหลือง
  // 9.เขียว เขียว แดง
  // 10.เขียว เหลือง เขียว
  // 11.เขียว เหลือง เหลือง
  // 12.เขียว แดง เขียว
  // 13.เขียว แดง แดง
  // 14.เหลือง เขียว เขียว
  // 15.เหลือง เขียว เหลือง
  // 16.เหลือง เหลือง เขียว
  // 17.เหลือง เหลือง เหลือง
  // 18.เหลือง เหลือง แดง
  // 19.เหลือง แดง เหลือง
  // 20.เหลือง แดง แดง
  // 21.แดง เขียว เขียว
  // 22.แดง เขียว แดง
  // 23.แดง เหลือง เหลือง
  // 24.แดง เหลือง แดง
  // 25.แดง แดง เขียว
  // 26.แดง แดง เหลือง
  // 27.แดง แดง แดง
}

void autoPlaceCan(int drop_height, bool increment_count = true) {
  state_pick = false;
  if (state_stock == true) {
    if (can_in_stock[0] != 'u') {
      stockOut('l', true);
      can_in_gripper[1] = 'u';
    } else if (can_in_stock[1] != 'u') {
      stockOut('r', true);
      can_in_gripper[0] = 'u';
    }
    if (drop_height >= 15 && mode_setCan_Stock == 1) {
      setCan();
      lift(15);
      delay(800);
    }
    placeCan_Fix(drop_height);
    delay(200);
    BB(30, after_place_can_distance);
    lift(2);
    servoArmWrite(chanal_Swing_Left, Swing_Left);
    servoArmWrite(chanal_Swing_Right, Swing_Right);
    servoCloseLeft();
    servoCloseRight();
  } else {
    servoArmWrite(chanal_Gripper_Left, Close_Left + 3);
    servoArmWrite(chanal_Gripper_Right, Close_Right + 3);
    if (drop_height >= 15) {
      setCan();
      lift(15);
      delay(800);
    }
    lift(drop_height + 3);
    placeCan_Fix(drop_height);
    delay(200);
    checkPlace(drop_height, station_count);
    if (increment_count) station_count += 1;
    servoArmWrite(chanal_Swing_Left, Swing_Left);
    servoArmWrite(chanal_Swing_Right, Swing_Right);
    servoCloseLeft();
    servoCloseRight();
    if (count_pick == 3) {
      if (State_EndMission == true) {
        state_stock = true;
        Can4();
      } else EndMission();
      motorStop();
      while (1)
        ;
    } else {
    }
  }
}

void checkPlace(int drop_height, int current_station) {
  if (can_in_gripper[0] == 'l' || can_in_gripper[1] == 'l') station[current_station][0] = 'l';
  if (can_in_gripper[0] == 'c' || can_in_gripper[1] == 'c') station[current_station][1] = 'c';
  if (can_in_gripper[0] == 'r' || can_in_gripper[1] == 'r') station[current_station][2] = 'r';

  for (byte i = 0; i < 3; i++) {
    if (station[current_station][i] == 'u') {
      if (i == 0) {
        if (can_in_stock[0] == 'l') {
          BB(30, after_place_can_distance);
          delay(100);
          stockOut('l', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            setCan();
            lift(15);
            delay(600);
          }
          can_in_gripper[0] = 'l';
          can_in_gripper[1] = 'u';
          autoPlaceCan(drop_height, false);
          station_backward = false;
        } else if (can_in_stock[1] == 'l') {
          BB(30, after_place_can_distance);
          delay(100);
          stockOut('r', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            setCan();
            lift(15);
            delay(600);
          }
          can_in_gripper[0] = 'u';
          can_in_gripper[1] = 'l';
          autoPlaceCan(drop_height, false);
          station_backward = false;
        }
      } else if (i == 1) {
        if (can_in_stock[0] == 'c') {
          BB(30, after_place_can_distance);
          delay(100);
          stockOut('l', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            setCan();
            lift(15);
            delay(600);
          }
          can_in_gripper[0] = 'c';
          can_in_gripper[1] = 'u';
          autoPlaceCan(drop_height, false);
          station_backward = false;
        } else if (can_in_stock[1] == 'c') {
          BB(30, after_place_can_distance);
          delay(100);
          stockOut('r', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            setCan();
            lift(15);
            delay(600);
          }
          can_in_gripper[0] = 'u';
          can_in_gripper[1] = 'c';
          autoPlaceCan(drop_height, false);
          station_backward = false;
        }
      } else if (i == 2) {
        if (can_in_stock[0] == 'r') {
          BB(30, after_place_can_distance);
          delay(100);
          stockOut('l', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            setCan();
            lift(15);
            delay(600);
          }
          can_in_gripper[0] = 'r';
          can_in_gripper[1] = 'u';
          autoPlaceCan(drop_height, false);
          station_backward = false;
        } else if (can_in_stock[1] == 'r') {
          BB(30, after_place_can_distance);
          delay(100);
          stockOut('r', true);
          delay(200);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            setCan();
            lift(15);
            delay(600);
          }
          can_in_gripper[0] = 'u';
          can_in_gripper[1] = 'r';
          autoPlaceCan(drop_height, false);
          station_backward = false;
        }
      }
    }
  }
  if (station_backward == true) {
    BB(30, after_place_can_distance);
  }
  station_backward = true;
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  lift(3);
}

void autoPlaceCan_stick(int drop_height, bool increment_count = true) {
  state_pick = true;
  if (state_stock == true) {
    if (can_in_stock[0] != 'u') {
      stockOut('l', true);
      can_in_gripper[1] = 'u';
    } else if (can_in_stock[1] != 'u') {
      stockOut('r', true);
      can_in_gripper[0] = 'u';
    }
    if (drop_height >= 15 && mode_setCan_Stock == 1) {
      setCan();
      lift(15);
      delay(800);
    }
    placeCan_Fix(drop_height);
    BB(30, 450);
    lift(2);
    servoArmWrite(chanal_Swing_Left, Swing_Left);
    servoArmWrite(chanal_Swing_Right, Swing_Right);
    servoCloseLeft();
    servoCloseRight();
  } else {
    servoArmWrite(chanal_Gripper_Left, Close_Left + 3);
    servoArmWrite(chanal_Gripper_Right, Close_Right + 3);
    lift(drop_height + 3);
    placeCan_Fix(drop_height);
    checkPlace_stick(drop_height, station_count);
    if (increment_count) station_count += 1;
    servoArmWrite(chanal_Swing_Left, Swing_Left);
    servoArmWrite(chanal_Swing_Right, Swing_Right);
    servoCloseLeft();
    servoCloseRight();
    if (count_pick == 3) {
      if (State_EndMission == true) {
        state_stock = true;
        Can4();
      } else EndMission();
      motorStop();
      while (1)
        ;
    } else {
    }
  }
}

void checkPlace_stick(int drop_height, int current_station) {
  if (can_in_gripper[0] == 'l' || can_in_gripper[1] == 'l') station[current_station][0] = 'l';
  if (can_in_gripper[0] == 'c' || can_in_gripper[1] == 'c') station[current_station][1] = 'c';
  if (can_in_gripper[0] == 'r' || can_in_gripper[1] == 'r') station[current_station][2] = 'r';

  for (byte i = 0; i < 3; i++) {
    if (station[current_station][i] == 'u') {
      if (i == 0) {
        if (can_in_stock[0] == 'l') {
          BB(30, 400);
          delay(100);
          stockOut('l', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            setCan();
            lift(15);
            delay(800);
          }
          can_in_gripper[0] = 'l';
          can_in_gripper[1] = 'u';
          autoPlaceCan_stick(drop_height, false);
          station_backward = false;
        } else if (can_in_stock[1] == 'l') {
          BB(30, 400);
          delay(100);
          stockOut('r', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            setCan();
            lift(15);
            delay(800);
          }
          can_in_gripper[0] = 'u';
          can_in_gripper[1] = 'l';
          autoPlaceCan_stick(drop_height, false);
          station_backward = false;
        }
      } else if (i == 1) {
        if (can_in_stock[0] == 'c') {
          BB(30, 400);
          delay(100);
          stockOut('l', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            setCan();
            lift(15);
            delay(800);
          }
          can_in_gripper[0] = 'c';
          can_in_gripper[1] = 'u';
          autoPlaceCan_stick(drop_height, false);
          station_backward = false;
        } else if (can_in_stock[1] == 'c') {
          BB(30, 400);
          delay(100);
          stockOut('r', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            setCan();
            lift(15);
            delay(800);
          }
          can_in_gripper[0] = 'u';
          can_in_gripper[1] = 'c';
          autoPlaceCan_stick(drop_height, false);
          station_backward = false;
        }
      } else if (i == 2) {
        if (can_in_stock[0] == 'r') {
          BB(30, 400);
          delay(100);
          stockOut('l', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            setCan();
            lift(15);
            delay(800);
          }
          can_in_gripper[0] = 'r';
          can_in_gripper[1] = 'u';
          autoPlaceCan_stick(drop_height, false);
          station_backward = false;
        } else if (can_in_stock[1] == 'r') {
          BB(30, 400);
          delay(100);
          stockOut('r', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            setCan();
            lift(15);
            delay(800);
          }
          can_in_gripper[0] = 'u';
          can_in_gripper[1] = 'r';
          autoPlaceCan_stick(drop_height, false);
          station_backward = false;
        }
      }
    }
  }
  if (station_backward == true) {
    BB(20, 450);
  }
  station_backward = true;
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  lift(3);
}

void SetFrontToCan(int drop_height, float distance) {
  if (drop_height > 15) drop_height = 15;
  lift(drop_height);
  while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
  moveToCanPlace(distance);
}

void setPlaceTime(int timeleft_side, int timeleft_center, int timeright_center, int timeright_side) {
  place_left_side = timeleft_side;        // ค่าระยะจอดกรณีมือซ้ายวางกระป๋องซ้าย
  place_left_center = timeleft_center;    // ค่าระยะจอดกรณีมือซ้ายวางกระป๋องกลาง
  place_right_center = timeright_center;  // ค่าระยะจอดกรณีมือขวาวางกระป๋องกลาง
  place_right_side = timeright_side;      // ค่าระยะจอดกรณีมือขวาวางกระป๋องขวา
}

void setPlaceTime_side(int timeplace_side) {
  place_LR = timeplace_side;
}

void setStandPlace(char color_left, char color_center, char color_right) {
  hold[0] = color_left;
  hold[1] = color_center;
  hold[2] = color_right;
}

void check_position_stan(char fr_left, char fr_right, char bk_left, char bk_right) {
  position_stan[0] = fr_left;
  position_stan[1] = fr_right;
  position_stan[2] = bk_left;
  position_stan[3] = bk_right;
}

void modesetCanStock(bool state) {
  mode_setCan_Stock = state;
}

void modeSwitchCanColor(bool state) {
  mode_Switch_Can_Color = state;
}

void test_EndMission() {
  EndMission();
}

void test_Can4(char select, char color) {
  if (color == 'r') color = 'r';
  else if (color == 'g') color = 'l';
  else if (color == 'y') color = 'c';
  if (select == 'l') can_in_stock[0] = color;
  else if (select == 'r') can_in_stock[1] = color;
  state_stock = true;
  Can4();
}

void test_stock() {
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  servoArmWrite(chanal_Gripper_Right, Open_Right);
  while (1) {
    STOP();
    lift(0);
    servoArmWrite(chanal_Swing_Left, Swing_Left);
    servoArmWrite(chanal_Swing_Right, Swing_Right);
    delay(500);
    servoClose(0);
    delay(500);

    stockIn('l', 'l', true);
    delay(500);
    stockIn('r', 'r', true);
    delay(500);
    stockOut('l', true);
    delay(500);
    stockOut('r', true);
    delay(500);
  }
}