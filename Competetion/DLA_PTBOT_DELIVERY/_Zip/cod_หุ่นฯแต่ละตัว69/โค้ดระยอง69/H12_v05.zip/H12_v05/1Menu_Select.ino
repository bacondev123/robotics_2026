/* -------------------------------------- readKnob -------------------------------------- */
int readKnob2() {
  long sum = 0;
  for (int i = 0; i < 20; i++) {
    sum += analogRead(32);
    delay(1);
  }
  return sum / 20;
}
/* -------------------------------------- SelectMenu -------------------------------------- */
void SelectMenu() {
  motorStop();
  lcdSetTextSize(1);
  tft.fillScreen(ST77XX_BLACK);

  lcdPrintText(0, 20, "A MenuTest              ", 0xffff);
  lcdPrintText(0, 40, "B MenuRun                   ", 0xffff);

  while (1) {
    if (switchRead(A) == 1) {
      while (switchRead(A) == 1) { delay(10); }
      setupServo();
      MenuTest();
      break;
    } else if (switchRead(B) == 1) {
      while (switchRead(B) == 1) { delay(10); }
      setupServo();
      MenuRun();
      break;
    }
    delay(10);
  }
  lcdClear();
}
/* -------------------------------------- MenuTest -------------------------------------- */
void MenuTest() {
  int lastX = -1;
  int stableX = 0;
  int confidence = 0;

  tft.fillScreen(ST77XX_BLACK);

  while (1) {
    motorStop();
    setAngleOffset();
    current_degree = 0;

    lift(0);
    setupServo();
    // retractArmIN_Setup();

    while (1) {
      if (switchRead(A) == 1 || switchRead(B) == 1) {
        // delay(20);
        char pressedBtn = 'N';
        if (switchRead(A) == 1) pressedBtn = 'A';
        else if (switchRead(B) == 1) pressedBtn = 'B';

        if (pressedBtn != 'N') {
          while (switchRead(A) == 1 || switchRead(B) == 1) { delay(10); }

          X = stableX;
          DoMenuTest(pressedBtn);

          motorStop();
          tft.fillScreen(ST77XX_BLACK);
          lcdSetTextSize(1);

          lcdPrintText(44, 30, "Press A or B", 0xffff);
          lcdPrintText(56, 50, "to Reset", 0xffff);

          while (switchRead(A) == 0 && switchRead(B) == 0) {
            delay(10);
          }

          while (switchRead(A) == 1 || switchRead(B) == 1) {
            delay(10);
          }

          lift(0);
          // retractArmIN_Setup();

          lastX = -1;
          tft.fillScreen(ST77XX_BLACK);
          break;
        }
      }

      if (switchRead(A) == 0 && switchRead(B) == 0) {
        int raw = readKnob2();
        int tempX = map(constrain(raw, 1230, 2530), 1230, 2530, 0, 13);

        if (tempX != stableX) {
          confidence++;
          if (confidence > 4) {
            stableX = tempX;
            confidence = 0;
          }
        } else {
          confidence = 0;
        }

        if (stableX != lastX) {
          tft.fillRect(0, 0, 160, 60, ST77XX_BLACK);
          lcdPrintText(0, 0, "MENU: " + String(stableX), 0xffff);
          X = stableX;
          ReadMenuTest();
          lastX = stableX;
        }
      }
      delay(10);
    }
  }
}
/* -------------------------------------- MenuRun -------------------------------------- */
void MenuRun() {
  int lastX = -1;
  int stableX = 0;
  int confidence = 0;

  tft.fillScreen(ST77XX_BLACK);

  while (1) {
    motorStop();
    setAngleOffset();
    current_degree = 0;

    lift(0);
    servoWrite(chanal_Stock_Tray_Left, Tray_In_Left);
    servoWrite(chanal_Stock_Tray_Right, Tray_In_Right);
    retractArmIN_Setup();

    while (1) {
      if (switchRead(A) == 1 || switchRead(B) == 1) {
        // delay(20);
        char pressedBtn = 'N';
        if (switchRead(A) == 1) pressedBtn = 'A';
        else if (switchRead(B) == 1) pressedBtn = 'B';

        if (pressedBtn != 'N') {
          while (switchRead(A) == 1 || switchRead(B) == 1) { delay(10); }

          X = stableX;
          DoMenuRun(pressedBtn);

          motorStop();
          tft.fillScreen(ST77XX_BLACK);
          lcdSetTextSize(1);

          lcdPrintText(44, 30, "Press A or B", 0xffff);
          lcdPrintText(56, 50, "to Reset", 0xffff);

          while (switchRead(A) == 0 && switchRead(B) == 0) {
            delay(10);
          }

          while (switchRead(A) == 1 || switchRead(B) == 1) {
            delay(10);
          }

          lift(0);
          retractArmIN_Setup();

          lastX = -1;
          tft.fillScreen(ST77XX_BLACK);
          break;
        }
      }

      if (switchRead(A) == 0 && switchRead(B) == 0) {
        int raw = readKnob2();
        int tempX = map(constrain(raw, 1230, 2530), 1230, 2530, 0, 13);

        if (tempX != stableX) {
          confidence++;
          if (confidence > 4) {
            stableX = tempX;
            confidence = 0;
          }
        } else {
          confidence = 0;
        }

        if (stableX != lastX) {
          tft.fillRect(0, 0, 160, 60, ST77XX_BLACK);
          lcdPrintText(0, 0, "MENU: " + String(stableX), 0xffff);
          X = stableX;
          ReadMenuRun();
          lastX = stableX;
        }
      }
      delay(10);
    }
  }
}
/* -------------------------------------- ReadMenuTest -------------------------------------- */
void ReadMenuTest() {
  // ใช้ switch-case
  switch (X) {
    case 0:
      lcdPrintText(0, 20, "A assemblyMode              ", 0xffff);
      lcdPrintText(0, 40, "B assemblyMode_switchCan             ", 0xffff);
      break;
    case 1:
      lcdPrintText(0, 20, "A assemblyMode_placeCan              ", 0xffff);
      lcdPrintText(0, 40, "B ShowValue_Sensor             ", 0xffff);
      break;
    case 2:
      lcdPrintText(0, 20, "A ShowDistanceSensor              ", 0xffff);
      lcdPrintText(0, 40, "B calibrateCanColor             ", 0xffff);
      break;
    case 3:
      lcdPrintText(0, 20, "A calibrateIMU              ", 0xffff);
      lcdPrintText(0, 40, "B CheckColLoop                     ", 0xffff);
      break;
    case 4:
      lcdPrintText(0, 20, "A autoPickCan 5 cm              ", 0xffff);
      lcdPrintText(0, 40, "B MSR             ", 0xffff);
      break;
    case 5:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 6:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 7:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 8:
      lcdPrintText(0, 20, "A              ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 9:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 10:
      lcdPrintText(0, 20, "A                ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 11:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 12:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    default:
      // กรณีค่า X อื่นๆ หรือ 99
      lcdPrintText(0, 20, "A NONE                ", 0xffff);
      lcdPrintText(0, 40, "B NONE                ", 0xffff);
      break;
  }
}
/* -------------------------------------- ReadMenuRun -------------------------------------- */
void ReadMenuRun() {
  // ใช้ switch-case
  switch (X) {
    case 0:
      lcdPrintText(0, 20, "A FullMap              ", 0xffff);
      lcdPrintText(0, 40, "B SelectPlace             ", 0xffff);
      break;
    case 1:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 2:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 3:
      lcdPrintText(0, 20, "A                ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 4:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 5:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 6:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 7:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 8:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 9:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 10:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 11:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    case 12:
      lcdPrintText(0, 20, "A               ", 0xffff);
      lcdPrintText(0, 40, "B              ", 0xffff);
      break;
    default:
      // กรณีค่า X อื่นๆ หรือ 99
      lcdPrintText(0, 20, "A NONE                ", 0xffff);
      lcdPrintText(0, 40, "B NONE                ", 0xffff);
      break;
  }
}