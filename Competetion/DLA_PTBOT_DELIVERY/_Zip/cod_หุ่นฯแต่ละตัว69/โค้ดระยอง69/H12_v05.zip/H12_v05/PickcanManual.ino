void PickCan(int pick_height,int WhatCan)
{
  if(autoplace==true){autoPickCan(pick_height);}
  else{
    if(WhatCan==1){PickManual(pick_height,CanL[0],CanR[0]); ShowColor(0); }
    else if(WhatCan==2){PickManual(pick_height,CanL[1],CanR[1]); ShowColor(1);}
    else if(WhatCan==3){PickManual(pick_height,CanL[2],CanR[2]); ShowColor(2);}
  }
  // setCanA();
}

void ShowColor(int number)
{
    if (CanL[number] =='y') {
      tft.fillRect(0, 0, 80, 128, 0xffc0);
    }
    else {
      if (CanL[number]=='r') {
        tft.fillRect(0, 0, 80, 128, 0xf800);
      }
      else if (CanL[number]=='g') {
        tft.fillRect(0, 0, 80, 128, 0x1d40);
      }
      else {
        tft.fillRect(0, 0, 80, 128, 0x0000);
      }
    }

    if (CanR[number] =='y') {
      tft.fillRect(80, 0, 80, 128, 0xffc0);
    }
    else {
      if (CanR[number]=='r') {
        tft.fillRect(80, 0, 80, 128, 0xf800);
      }
      else if (CanR[number]=='g') {
        tft.fillRect(80, 0, 80, 128, 0x1d40);
      }
      else {
        tft.fillRect(80, 0, 80, 128, 0x0000);
      }
    }

}
void PickManual(int pick_height,char CL,char CR) {
  servoArmWrite(chanal_Swing_Left, Swing_Left - 2);
  servoArmWrite(chanal_Swing_Right, Swing_Right - 2);
  servoArmWrite(chanal_Gripper_Left, Open_Left - 3);
  servoArmWrite(chanal_Gripper_Right, Open_Right - 3);
  if (pick_height != 0) moveToCanPick(pick_can_distance);
  else moveToCanPick(pick_can_floor);
  lift(pick_height);
  // moveToCanPick(distance);
  servoArmWrite(chanal_Gripper_Left, Close_Left - Open_Drop_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right - Open_Drop_Right);
  motorWrite(3, 50);
  delay(100);
  motorStop();
  delay(300);
  servoCloseLeft();
  servoCloseRight();
  delay(200);
  lift(pick_height + 3);
  delay(300);
  can_in_gripper[0] = CL;
  can_in_gripper[1] = CR;
  count_pick += 1;
  if (count_pick == 3 && (can_in_gripper[0] == can_in_gripper[1])) {
    State_EndMission = true;
  } else if (mode_Switch_Can_Color == false) {
    if (((hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'g')) || ((hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') && (can_in_gripper[0] == 'y' && can_in_gripper[1] == 'g')) || ((hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'y')) || ((hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') && (can_in_gripper[0] == 'g' && can_in_gripper[1] == 'y')) || ((hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') && (can_in_gripper[0] == 'y' && can_in_gripper[1] == 'r')) || ((hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') && (can_in_gripper[0] == 'g' && can_in_gripper[1] == 'r'))) {
      swingGripper('r', Swing_Right + 10);
      for (int i = Swing_Left; i > swing_switch_can_left; i -= 1) {
        swingGripper('l', i);
        delay(15);
      }
      vTaskResume(switchGripperTaskHandle);
      delay(10);
      lift(pick_height);
      delay(200);
      for (int i = Close_Left; i > Open_Left; i -= 1) {
        servoArmWrite(chanal_Gripper_Left, i);
        delay(15);
      }
      for (int i = swing_switch_can_left; i < swing_switch_can_left + 5; i += 1) {
        swingGripper('l', i);
        delay(5);
      }
      lift(pick_height + 3);
      BB(30, 350);
      switchGripper('r', 'l');
      delay(1800);
      swingGripper('l', Swing_Left_side);
      swingGripper('r', swing_switch_can_right);
      servoArmWrite(chanal_Gripper_Right, Open_Right - 10);
      delay(200);
      if (pick_height != 0) FF(15, switch_moveToPickCan_distance);  // ระยะทางเดินเข้าไปหยิบป๋องที่สลับไว้บนแท่น
      else FF(15, switch_moveToPickCan_distance_floor);             // ระยะทางเดินเข้าไปหยิบป๋องที่สลับไว้ที่พื้น
      lift(pick_height);
      delay(300);
      servoCloseRight();
      delay(200);
      lift(pick_height + 2);
      vTaskSuspend(switchGripperTaskHandle);
      if (hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') {
        can_in_gripper[0] = 'l';
        can_in_gripper[1] = 'r';
      }
      if (hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') {
        can_in_gripper[0] = 'l';
        can_in_gripper[1] = 'c';
      }
      if (hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') {
        can_in_gripper[0] = 'c';
        can_in_gripper[1] = 'r';
      }
      if (hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') {
        can_in_gripper[0] = 'c';
        can_in_gripper[1] = 'l';
      }
      if (hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') {
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'c';
      }
      if (hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') {
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'l';
      }
    } else {
      if (can_in_gripper[0] == 'r') can_in_gripper[0] = 'r';
      else if (can_in_gripper[0] == 'g') can_in_gripper[0] = 'l';
      else if (can_in_gripper[0] == 'y') can_in_gripper[0] = 'c';
      if (can_in_gripper[1] == 'r') can_in_gripper[1] = 'r';
      else if (can_in_gripper[1] == 'g') can_in_gripper[1] = 'l';
      else if (can_in_gripper[1] == 'y') can_in_gripper[1] = 'c';
    }
  } else if (mode_Switch_Can_Color == true) {
    if (can_in_gripper[0] == 'r') can_in_gripper[0] = 'r';
    else if (can_in_gripper[0] == 'g') can_in_gripper[0] = 'l';
    else if (can_in_gripper[0] == 'y') can_in_gripper[0] = 'c';
    if (can_in_gripper[1] == 'r') can_in_gripper[1] = 'r';
    else if (can_in_gripper[1] == 'g') can_in_gripper[1] = 'l';
    else if (can_in_gripper[1] == 'y') can_in_gripper[1] = 'c';
  }
  retractArmIN_Can();
  BB(30, after_pick_can_distance);
  lift(3);
}