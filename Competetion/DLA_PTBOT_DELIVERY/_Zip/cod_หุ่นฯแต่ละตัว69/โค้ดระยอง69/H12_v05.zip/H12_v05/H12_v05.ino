#include <PTBOTAtomVX.h>
#include <ESP32Encoder.h>
#include <SoftI2C.h>

#define NO_SWITCH_LR 0
#define SWITCH_LR 1

#define chanal_Swing_Left 1
#define chanal_Swing_Right 2
#define chanal_Gripper_Left 0
#define chanal_Gripper_Right 3
#define chanal_Stock_Tray_Left 4
#define chanal_Stock_Tray_Right 5

int X;

/* ค่าเซ็นเซอร์ตรวจจับเส้น */
//                   S0   S1   S2   S3
int sensor_min[] = { 145, 155, 125, 120 };   // ค่าสีดำ
int sensor_max[] = { 625, 550, 655, 505 };  // ค่าสีขาว

/* ค่าเซ็นเซอร์อ่านค่าสี */
int clear_color_left = 3000;   // ค่าสีเหลืองมือจับด้านซ้าย
int clear_color_right = 3000;  // ค่าสีเหลืองมือจับด้านขวา

/* ความเร็วเดินหน้า หยิบป๋อง */
int speed_pick_can = 30;       // ความเร็วสูงสุด
int speed_pick_can_slow = 15;  // ความเร็วต่ำสุด
/* ความเร็วเดินหน้า วางป๋อง */
int speed_place_can = 30;       // ความเร็วสูงสุด
int speed_place_can_slow = 15;  // ความเร็วต่ำสุด

/* ค่าระยะจอด */
// float pick_can_floor = 8.6;     // หยิบป๋อง ที่พื้น (หากหยิบไม่ถึงให้ลด หากชนกระป๋องให้เพิ่ม)
float pick_can_floor = 225; // เดินหน้าเข้า
float pick_can_distance = 4.25;   // หยิบป๋อง หน้าแท่นหยิบ (หากหยิบไม่ถึงให้ลด หากชนกระป๋องให้เพิ่ม)
float place_can_distance = 2.25;  // วางป๋อง หน้าแท่นวาง (หากวางเลยแท่นให้เพิ่ม หากวางไม่ถึงแท่นให้ลด)

/* ค่าระยะจอดหน้าแท่นวาง วางพร้อมกัน 2 ใบ */
int place_LR = 100;  // วางหลุมข้าง ซ้าย ขวา (หากถอยเลยหลุมให้ลด)

/* ระยะทางเดินเข้าไปหยิบป๋องที่สลับไว้ แดงซ้าย เขียวขวา */
int switch_moveToPickCan_distance = 500;  // ค่าระยะจอดสลับป๋อง แดงซ้าย เขียวขวา เดินเข้าไปหยิบป๋องหน้าแท่นหยิบ
int switch_moveToPickCan_distance_floor = 500;  // ค่าระยะจอดสลับป๋อง แดงซ้าย เขียวขวา เดินเข้าไปหยิบป๋องที่พื้น

/* ค่าระยะถอยออก ตอนหยิบและตอนวาง (400 = default) */
unsigned long after_pick_can_distance = 725;   // ระยะถอย หลังจากหยิบกระป๋อง (หากถอยเกิน 1 ช่องให้ลด หากถอยไม่ถึง 1 ช่องให้เพิ่ม)
unsigned long after_place_can_distance = 725;  // ระยะถอย หลังจากวางกระป๋อง (หากถอยเกิน 1 ช่องให้ลด หากถอยไม่ถึง 1 ช่องให้เพิ่ม)

/* ค่าระยะจอดหน้าแท่นวาง วางที่ละข้าง */
int place_left_side = 135;    // ค่าระยะจอดกรณีมือซ้ายวางกระป๋องซ้าย (หากถอยเลยหลุมให้ลด)
int place_left_center = 35;   // ค่าระยะจอดกรณีมือซ้ายวางกระป๋องกลาง (หากถอยเลยหลุมให้ลด)
int place_right_center = 35;  // ค่าระยะจอดกรณีมือขวาวางกระป๋องกลาง (หากถอยเลยหลุมให้ลด)
int place_right_side = 135;   // ค่าระยะจอดกรณีมือขวาวางกระป๋องขวา (หากถอยเลยหลุมให้ลด)

float power_factor = 1.0;
int line_value[] = { 0, 0, 0, 0, 0, 0, 0, 0 };
float current_degree = 0;
float previous_error_forward = 0;
byte servo_pin[] = { 6, 5, 4, 0, 1, 2, 3 };
bool sonar_enable = 0, mode_setCan_Stock = 0, mode_Switch_Can_Color = 0;

long delayALL = 80;

TaskHandle_t sonarTaskHandle = NULL;
TaskHandle_t switchGripperTaskHandle = NULL;
TwoWire Wire2 = TwoWire(1);

/*----------------------------------------------------------------------------------------*/
///////////////////// ASSEMBLYMODE /////////////////////
int Swing_Left = 56; //S0 สวิงแขนซ้าย เพิ่มง้างออก ลด หุบเข้า
int Swing_Right = 55; //S1 สวิงแขนขวา เพิ่มง้างออก ลด หุบเข้า
////////////////////////////////////////////////////////
int Open_Left = 96-15; //S2 อ้ามือ ชุดมือจับมือซ้ายค่ามากยิ่งหุบ
int Close_Left = 120-5; //S2 หุบมือ ชุดมือจับมือซ้ายค่าน้อยยิ่งอ้า
////////////////////////////////////////////////////////
int Open_Right = 95-10; //S3 อ้ามือ ชุดมือจับมือขวา ค่ามากยิ่งหุบ
int Close_Right = 127-5; //S3 หุบมือ ชุดมือจับมือขวา ค่าน้อยยิ่งอ้า
////////////////////////////////////////////////////////
int Tray_In_Left = 145; // S4 เก็บถาดด้านซ้ายเข้า ค่ามากยิ่งเข้า
int Tray_Out_Left = 58; // S4 เอาถาดด้านซ้ายออก ค่าน้อยยิ่งออก
int Tray_In_Right = 89; // S5 เก็บถาดด้านขวาเข้า ค่าน้อยยิ่งเข้า
int Tray_Out_Right = 172; // S5 เอาถาดด้านขวาออก ค่ามากยิ่งออก
////////////////////////////////////////////////////////
int Stock_Left = 147; // S0 สวิงแขนเก็บกระป๋องซ้าย เพิ่มง้างออก ลด หุบเข้า
int Stock_Right = 144; // S1 สวิงแขนเก็บกระป๋องขวา เพิ่มง้างออก ลด หุบเข้า
////////////////////////////////////////////////////////
//////////////// ASSEMBLYMODE SWITCH CAN ///////////////
int swing_switch_can_left = 26; //S0 หุบแขนเข้าเพื่อสลับกระป๋อง แขนซ้าย ค่าน้อยยิ่งหุบเข้า
int swing_switch_can_right = 29; //S1 หุบแขนเข้าเพื่อสลับกระป๋อง แขนขวา ค่าน้อยยิ่งหุบเข้า
////////////////////////////////////////////////////////
//////////////// ASSEMBLYMODE PLACE CAN ////////////////
int Swing_Left_side = 68; //S0 สวิงแขนซ้าย วางป๋องซ้าย เพิ่มง้างออก ลด หุบเข้า
int Swing_Left_center = 29; //S0 สวิงแขนซ้าย วางป๋องกลาง เพิ่มง้างออก ลด หุบเข้า
int Swing_Right_side = 61; //S1 สวิงแขนขวา วางป๋องขวา เพิ่มง้างออก ลด หุบเข้า
int Swing_Right_center = 20 ; //S1 สวิงแขนขวา วางป๋องกลาง เพิ่มง้างออก ลด หุบเข้า
////////////////////////////////////////////////////////
/////////////////////// Air Drop ///////////////////////
int Open_Drop_Left = 10;   //S2 มือซ้าย อ้ามือเล็กน้อยเพื่อวางป๋องให้ลงหลุม ค่ามากยิ่งอ้า
int Open_Drop_Right = 10;  //S3 มือขวา อ้ามือเล็กน้อยเพื่อวางป๋องให้ลงหลุม ค่ามากยิ่งอ้า
////////////////////////////////////////////////////////

int swingL_IN = 13; // S0 ค่าตั้งการ์ดแขนซ้าย
int swingR_IN = 13; // S1 ค่าตั้งการ์ดแขนขวา

int lift_Sensitivity = 28; // ตัวคูนลิฟท์

int switch_degree = 22;
int switch_flag = 0;
int stock_flag = 0;
int lift_target = 0;
int swing_current_degree[] = { 0, 0 };
char can_in_gripper[2] = { 'u', 'u' };
char can_in_stock[2] = { 'u', 'u' };
char station[3][3] = {
  { 'u', 'u', 'u' },
  { 'u', 'u', 'u' },
  { 'u', 'u', 'u' }
};
int station_count = 0, count_pick = 0;

int position_stan[4] = { 'u', 'u', 'u', 'u' };
char hold[3] = { 'g', 'y', 'r' };
bool station_backward = true, State_EndMission = false, state_stock = false, state_pick = false;

ESP32Encoder encoder;
Adafruit_PWMServoDriver servo_arm = Adafruit_PWMServoDriver(0x41, Wire2);
/*----------------------------------------------------------------------------------------*/
int safe = 0, swingRange = 10, delayTime = 15;

char CanL[3]={'u','u','u'};
char CanR[3]={'u','u','u'};
int autoplace=true;

void setup() {
  Serial.begin(115200);
  initialize();
  xTaskCreatePinnedToCore(liftLoop, "liftLoop", 2048, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(sonarLoop, "sonarLoop", 2048, NULL, 1, &sonarTaskHandle, 0);
  xTaskCreatePinnedToCore(switchGripperLoop, "switchGripperLoop", 2048, NULL, 1, &switchGripperTaskHandle, 1);
  xTaskCreatePinnedToCore(stockLoop, "stockLoop", 2048, NULL, 1, NULL, 0);
  vTaskSuspend(sonarTaskHandle);
  vTaskSuspend(switchGripperTaskHandle);
  setupColorSensor();
  setupSensor();
  setupServo();
  lift(0);
  // retractArmIN();

  SelectMenu();
  // MenuTest();
  // MenuRun();
  ///////////////////////// เปิดอ่านค่า เซนเซอร์ ///////////////////////////
  //assemblyMode();            // ประกอบ และปรับค่า Servo (ตั้งค่าเริ่มต้น, โหมดสลับกระป๋อง, ตั้งเซอร์โวหาหลุม)
  //ShowDistanceSensor();      // โชว์ค่าเซ็นเซอร์วัดระยะทาง
  //calibrateCanColor();       // Calibrate เซ็นเซอร์อ่านค่าสีกระป่อง
  //ShowValue_Sensor();        // โชว์ค่าเซ็นเซอร์ตรวจจับเส้น
  /////////////////////////////////////////////////////////
  //assemblyMode_switchCan();  // ปรับค่า Servo โหมดสลับกระป๋อง
  // assemblyMode_placeCan();   // ปรับค่า Servo ตั้งเซอร์โวหาหลุม
  // calibrateIMU();            // Calibrate เซ็นเซอร์ไจโร
  ////////////////////////////////////////////////////////////////////////
  // modesetCanStock(0);     // 0 = no setCan หลังหยิบป๋องออกจากถาดก่อนวางป๋องบนแท่น 15cm, 1 = run setCan หลังหยิบป๋องออกจากถาดก่อนวางป๋องบนแท่น 15cm
  // modeSwitchCanColor(1);  // 0 = no stock สีป๋องไขว้กันจะสลับป๋องซ้ายขวา, 1 = stock สีป๋องไขว้กันจะสต็อกเข้าถาดแทน
  // measureRobot();      // หุบมือ และกางแขนออกถึงถาด gสร็จแล้วครับ เทสได้เลยครับ
}

void loop() {
  // STOP();
  //retractArmIN_Setup();  // พับแขนเข้าตัว (ป้องกันการชนขอบสนาม)

  // Can1();  // ออกจากจุดสตาร์ท ไปหยิบกระป๋อง และไปวางแท่นที่ 1
  // Can2();  // ไปหยิบกระป๋อง และไปวางแท่นที่ 2
  // Can3();  // ไปหยิบกระป๋อง และไปวางแท่นที่ 3

  // ถ้ากรณีมีป๋องในถาด ให้ไปเขียนใน Can4 วางป๋องแท่นที่ 1 หรือแท่นที่ 2 ก็ได้ พร้อมเขียนกลับจุดจบ
  // แต่ถ้ากรณีไม่มีป๋องในถาด ให้ไปเขียนใน EndMission กลับจุดจบได้เลย
}