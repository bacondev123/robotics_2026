void assemblyMode() {
  lift(10);
  int swing_left = 60;
  int swing_right = 60;
  int open_left = 80;
  int close_left = open_left + 30;
  int open_right = 80;
  int close_right = open_right + 30;
  int tray_in_left = 100;
  int tray_in_right = 100;
  int tray_out_left = tray_in_left - 70;
  int tray_out_right = tray_in_right + 70;
  int stock_left = swing_left + 90;
  int stock_right = swing_right + 90;
  unsigned long timer_servo = 0;
  servoArmWrite(chanal_Swing_Left, swing_left);
  servoArmWrite(chanal_Swing_Right, swing_right);
  servoArmWrite(chanal_Gripper_Left, open_left);
  servoArmWrite(chanal_Gripper_Right, open_right);
  servoWrite(chanal_Stock_Tray_Left, tray_in_left);
  servoWrite(chanal_Stock_Tray_Right, tray_in_right);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(2, 55, "ASSEMBLY MODE", 0xf800);
  Serial.println("โหมดตั้งค่าเซอร์โวปกติ");
  Serial.println("กดสวิตซ์ A และ B พร้อมกัน เพื่อเริ่มตั้งค่าเซอร์โว");
  while (!switchRead(A) || !switchRead(B)) {};
  beep(50);
  while (switchRead(A) || switchRead(B)) {};
  Serial.println("หาค่า Swing Left");
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      swing_left += 1;
      beep(20);
    } else if (switchRead(B)) {
      swing_left -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, swing_left);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Swing Right");
  swing_right = swing_left;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      swing_right -= 1;
      beep(20);
    } else if (switchRead(B)) {
      swing_right += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, swing_right);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Close Left");
  timer_servo = millis();
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      close_left -= 1;
      beep(20);
    } else if (switchRead(B)) {
      close_left += 1;
      beep(20);
    }
    if (millis() - timer_servo <= 1000) servoArmWrite(chanal_Gripper_Left, close_left);
    else if (millis() - timer_servo > 1000 && millis() - timer_servo <= 2000) servoArmWrite(chanal_Gripper_Left, close_left - 15);
    else timer_servo = millis();
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Close Right");
  timer_servo = millis();
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      close_right -= 1;
      beep(20);
    } else if (switchRead(B)) {
      close_right += 1;
      beep(20);
    }
    if (millis() - timer_servo <= 1000) servoArmWrite(chanal_Gripper_Right, close_right);
    else if (millis() - timer_servo > 1000 && millis() - timer_servo <= 2000) servoArmWrite(chanal_Gripper_Right, close_right - 15);
    else timer_servo = millis();
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Open Left");
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      open_left -= 1;
      beep(20);
    } else if (switchRead(B)) {
      open_left += 1;
      beep(20);
    }
    servoArmWrite(chanal_Gripper_Left, open_left);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Open Right");
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      open_right -= 1;
      beep(20);
    } else if (switchRead(B)) {
      open_right += 1;
      beep(20);
    }
    servoArmWrite(chanal_Gripper_Right, open_right);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Tray In Left");
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      tray_in_left -= 2;
      beep(20);
    } else if (switchRead(B)) {
      tray_in_left += 2;
      beep(20);
    }
    servoWrite(chanal_Stock_Tray_Left, tray_in_left);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Tray In Right");
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      tray_in_right -= 2;
      beep(20);
    } else if (switchRead(B)) {
      tray_in_right += 2;
      beep(20);
    }
    servoWrite(chanal_Stock_Tray_Right, tray_in_right);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Tray Out Left");
  tray_out_left = tray_in_left - 70;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      tray_out_left -= 2;
      beep(20);
    } else if (switchRead(B)) {
      tray_out_left += 2;
      beep(20);
    }
    servoWrite(chanal_Stock_Tray_Left, tray_out_left);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Tray Out Right");
  tray_out_right = tray_in_right + 70;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      tray_out_right -= 2;
      beep(20);
    } else if (switchRead(B)) {
      tray_out_right += 2;
      beep(20);
    }
    servoWrite(chanal_Stock_Tray_Right, tray_out_right);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Stock Left");
  stock_left = swing_left + 90;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      stock_left -= 1;
      beep(20);
    } else if (switchRead(B)) {
      stock_left += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, stock_left);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Stock Right");
  stock_right = swing_right + 90;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      stock_right += 1;
      beep(20);
    } else if (switchRead(B)) {
      stock_right -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, stock_right);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Swing_Left = swing_left;
  Swing_Right = swing_right;
  Open_Left = open_left;
  Close_Left = close_left;
  Open_Right = open_right;
  Close_Right = close_right;
  Tray_In_Left = tray_in_left;
  Tray_Out_Left = tray_out_left;
  Tray_In_Right = tray_in_right;
  Tray_Out_Right = tray_out_right;
  Stock_Left = stock_left;
  Stock_Right = stock_right;
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  servoArmWrite(chanal_Gripper_Right, Open_Right);
  servoWrite(chanal_Stock_Tray_Left, Tray_In_Left);
  servoWrite(chanal_Stock_Tray_Right, Tray_In_Right);
  delay(1000);
  lift(3);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(31, 55, "COMPLETE", 0x07E0);
  beep(50);
  delay(50);
  beep(50);
  delay(1000);

  lift(0);
  int switch_can_left = Swing_Left - 30;
  int switch_can_right = Swing_Right + 20;
  timer_servo = 0;
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  servoArmWrite(chanal_Gripper_Right, Open_Right);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(2, 35, "ASSEMBLY MODE", 0xf800);
  lcdPrintText(2, 65, " SWITCH CAN  ", 0xf800);
  Serial.println();
  Serial.println("โหมดตั้งค่าเซอร์โว สลับกระป๋อง");
  Serial.println("นำกระป๋องใส่มือซ้าย แล้วกดสวิตซ์ A และ B พร้อมกัน");

  delay(200);
  while (!switchRead(A) || !switchRead(B)) {};
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoArmWrite(chanal_Gripper_Left, Close_Left);
  delay(200);
  lift(3);
  servoArmWrite(chanal_Swing_Left, switch_can_left);
  servoArmWrite(chanal_Swing_Right, switch_can_right);
  Serial.println("หาค่า swing switch can left ตั้งค่าแขนซ้าย หรือให้กระป๋องอยู่ตรงกลางเสาลิฟท์");
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      switch_can_left += 1;
      beep(20);
    } else if (switchRead(B)) {
      switch_can_left -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, switch_can_left);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  switch_can_right = Swing_Right - 30;
  servoArmWrite(chanal_Swing_Left, Swing_Left + 40);
  delay(500);
  servoArmWrite(chanal_Swing_Right, switch_can_right);
  delay(500);
  servoArmWrite(chanal_Swing_Left, switch_can_left);
  delay(500);
  Serial.println("หาค่า swing switch can right ตั้งค่าแขนขวาเข้าหากระป๋อง");
  beep(50);
  delay(50);
  beep(50);
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      switch_can_right -= 1;
      beep(20);
    } else if (switchRead(B)) {
      switch_can_right += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, switch_can_right);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoCloseRight();
  delay(200);
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(31, 55, "COMPLETE", 0x07E0);
  beep(50);
  delay(50);
  beep(50);
  delay(1000);

  swing_switch_can_left = switch_can_left;
  swing_switch_can_right = switch_can_right;
  delay(300);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  delay(300);
  swing_current_degree[0] = Swing_Left + 65;
  swing_current_degree[1] = Swing_Right + (switch_degree - 10);
  servoArmWrite(chanal_Swing_Right, swing_current_degree[1]);
  delay(100);
  servoArmWrite(chanal_Swing_Left, swing_current_degree[0]);
  servoArmWrite(chanal_Gripper_Left, Close_Left);

  delay(200);
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  delay(200);

  setPlaceTime(place_left_side, place_left_center, place_right_side, place_right_center);
  lift(10);
  delay(800);
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(2, 35, "ASSEMBLY MODE", 0xf800);
  lcdPrintText(2, 65, "  PLACE CAN  ", 0xf800);
  Serial.println();
  Serial.println("นำแท่นสูง 10cm มาวางไว้หน้าหุ่นยนต์ แล้วกดสวิตซ์ A และ B พร้อมกัน");
  while (!switchRead(A) || !switchRead(B)) {};
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoArmWrite(chanal_Swing_Right, Swing_Right + 65);

  Serial.println("หาค่ามือจับซ้าย วางป๋องหลุมซ้าย Swing Left side");
  Swing_Left_side = Swing_Left + 12;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Left_side += 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Left_side -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, Swing_Left_side);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่ามือจับขวา วางป๋องหลุมขวา Swing Right side");
  Swing_Right_side = Swing_Right + 12;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Right_side -= 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Right_side += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, Swing_Right_side);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่ามือจับซ้าย วางป๋องหลุมกลาง Swing Left center");
  Swing_Left_center = Swing_Left - 22;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Left_center += 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Left_center -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, Swing_Left_center);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoArmWrite(chanal_Swing_Left, Swing_Left + 65);
  delay(200);

  Serial.println("หาค่ามือจับขวา วางป๋องหลุมกลาง Swing Right center");
  Swing_Right_center = Swing_Right - 22;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Right_center -= 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Right_center += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, Swing_Right_center);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  servoArmWrite(chanal_Swing_Left, Swing_Left + 65);
  servoArmWrite(chanal_Swing_Right, Swing_Right + 65);
  delay(1000);
  lift(3);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(31, 55, "COMPLETE", 0x07E0);
  beep(50);
  delay(50);
  beep(50);

  Serial.println();
  Serial.println("///////////////////// ASSEMBLYMODE /////////////////////");
  Serial.println("int Swing_Left = " + String(swing_left) + "; //S0 สวิงแขนซ้าย เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Swing_Right = " + String(swing_right) + "; //S1 สวิงแขนขวา เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("////////////////////////////////////////////////////////");
  Serial.println("int Open_Left = " + String(open_left) + "; //S2 อ้ามือ ชุดมือจับมือซ้ายค่ามากยิ่งหุบ");
  Serial.println("int Close_Left = " + String(close_left) + "; //S2 หุบมือ ชุดมือจับมือซ้ายค่าน้อยยิ่งอ้า");
  Serial.println("////////////////////////////////////////////////////////");
  Serial.println("int Open_Right = " + String(open_right) + "; //S3 อ้ามือ ชุดมือจับมือขวา ค่ามากยิ่งหุบ");
  Serial.println("int Close_Right = " + String(close_right) + "; //S3 หุบมือ ชุดมือจับมือขวา ค่าน้อยยิ่งอ้า");
  Serial.println("////////////////////////////////////////////////////////");
  Serial.println("int Tray_In_Left = " + String(tray_in_left) + "; // S4 เก็บถาดด้านซ้ายเข้า ค่ามากยิ่งเข้า");
  Serial.println("int Tray_Out_Left = " + String(tray_out_left) + "; // S4 เอาถาดด้านซ้ายออก ค่าน้อยยิ่งออก");
  Serial.println("int Tray_In_Right = " + String(tray_in_right) + "; // S5 เก็บถาดด้านขวาเข้า ค่าน้อยยิ่งเข้า");
  Serial.println("int Tray_Out_Right = " + String(tray_out_right) + "; // S5 เอาถาดด้านขวาออก ค่ามากยิ่งออก");
  Serial.println("////////////////////////////////////////////////////////");
  Serial.println("int Stock_Left = " + String(stock_left) + "; // S0 สวิงแขนเก็บกระป๋องซ้าย เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Stock_Right = " + String(stock_right) + "; // S1 สวิงแขนเก็บกระป๋องขวา เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("////////////////////////////////////////////////////////");
  Serial.println("//////////////// ASSEMBLYMODE SWITCH CAN ///////////////");
  Serial.println("int swing_switch_can_left = " + String(switch_can_left) + "; //S0 หุบแขนเข้าเพื่อสลับกระป๋อง แขนซ้าย ค่าน้อยยิ่งหุบเข้า");
  Serial.println("int swing_switch_can_right = " + String(switch_can_right) + "; //S1 หุบแขนเข้าเพื่อสลับกระป๋อง แขนขวา ค่าน้อยยิ่งหุบเข้า");
  Serial.println("////////////////////////////////////////////////////////");
  Serial.println("//////////////// ASSEMBLYMODE PLACE CAN ////////////////");
  Serial.println("int Swing_Left_side = " + String(Swing_Left_side) + "; //S0 สวิงแขนซ้าย วางป๋องซ้าย เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Swing_Left_center = " + String(Swing_Left_center) + "; //S0 สวิงแขนซ้าย วางป๋องกลาง เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Swing_Right_side = " + String(Swing_Right_side) + "; //S1 สวิงแขนขวา วางป๋องขวา เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Swing_Right_center = " + String(Swing_Right_center) + "; //S1 สวิงแขนขวา วางป๋องกลาง เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("////////////////////////////////////////////////////////");
}

void assemblyMode_switchCan() {
  lift(0);
  int switch_can_left = Swing_Left - 30;
  int switch_can_right = Swing_Right + 20;
  unsigned long timer_servo = 0;
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  servoArmWrite(chanal_Gripper_Right, Open_Right);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(2, 35, "ASSEMBLY MODE", 0xf800);
  lcdPrintText(2, 65, " SWITCH CAN  ", 0xf800);
  Serial.println();
  Serial.println("โหมดตั้งค่าเซอร์โว สลับกระป๋อง");
  Serial.println("นำกระป๋องใส่มือซ้าย แล้วกดสวิตซ์ A และ B พร้อมกัน");

  delay(200);
  while (!switchRead(A) || !switchRead(B)) {};
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoArmWrite(chanal_Gripper_Left, Close_Left);
  delay(200);
  lift(3);
  servoArmWrite(chanal_Swing_Left, switch_can_left);
  servoArmWrite(chanal_Swing_Right, switch_can_right);
  Serial.println("หาค่า swing switch can left ตั้งค่าแขนซ้าย หรือให้กระป๋องอยู่ตรงกลางเสาลิฟท์");
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      switch_can_left += 1;
      beep(20);
    } else if (switchRead(B)) {
      switch_can_left -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, switch_can_left);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  switch_can_right = Swing_Right - 30;
  servoArmWrite(chanal_Swing_Left, Swing_Left + 40);
  delay(500);
  servoArmWrite(chanal_Swing_Right, switch_can_right);
  delay(500);
  servoArmWrite(chanal_Swing_Left, switch_can_left);
  delay(500);
  Serial.println("หาค่า swing switch can right ตั้งค่าแขนขวาเข้าหากระป๋อง");
  beep(50);
  delay(50);
  beep(50);
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      switch_can_right -= 1;
      beep(20);
    } else if (switchRead(B)) {
      switch_can_right += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, switch_can_right);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoCloseRight();
  delay(200);
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(31, 55, "COMPLETE", 0x07E0);
  beep(50);
  delay(50);
  beep(50);
  delay(1000);

  Serial.println();
  Serial.println("//////////////// ASSEMBLYMODE SWITCH CAN ///////////////");
  Serial.println("int swing_switch_can_left = " + String(switch_can_left) + "; //S0 หุบแขนเข้าเพื่อสลับกระป๋อง แขนซ้าย ค่าน้อยยิ่งหุบเข้า");
  Serial.println("int swing_switch_can_right = " + String(switch_can_right) + "; //S1 หุบแขนเข้าเพื่อสลับกระป๋อง แขนขวา ค่าน้อยยิ่งหุบเข้า");
  Serial.println("////////////////////////////////////////////////////////");

  swing_switch_can_left = switch_can_left;
  swing_switch_can_right = switch_can_right;

  delay(300);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  delay(300);
  swing_current_degree[0] = Swing_Left + 65;
  swing_current_degree[1] = Swing_Right + (switch_degree - 10);
  servoArmWrite(chanal_Swing_Right, swing_current_degree[1]);
  delay(100);
  servoArmWrite(chanal_Swing_Left, swing_current_degree[0]);
  servoArmWrite(chanal_Gripper_Left, Close_Left);

  delay(200);
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  delay(200);
  lift(3);
  while (1) {
    STOP();
    beep(50);
    vTaskResume(switchGripperTaskHandle);
    switchGripper('r', 'l');
    delay(1800);
    vTaskSuspend(switchGripperTaskHandle);
    servoArmWrite(chanal_Swing_Left, Swing_Left);
    servoArmWrite(chanal_Swing_Right, Swing_Right);
    beep(50);

    STOP();
    beep(50);
    vTaskResume(switchGripperTaskHandle);
    switchGripper('l', 'r');
    delay(1800);
    vTaskSuspend(switchGripperTaskHandle);
    servoArmWrite(chanal_Swing_Left, Swing_Left);
    servoArmWrite(chanal_Swing_Right, Swing_Right);
    beep(50);
  }
}

void assemblyMode_placeCan() {
  lift(10);
  delay(800);
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(2, 35, "ASSEMBLY MODE", 0xf800);
  lcdPrintText(2, 65, "  PLACE CAN  ", 0xf800);
  Serial.println();
  Serial.println("นำแท่นสูง 10cm มาวางไว้หน้าหุ่นยนต์ แล้วกดสวิตซ์ A และ B พร้อมกัน");
  while (!switchRead(A) || !switchRead(B)) {};
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่ามือจับซ้าย วางป๋องหลุมซ้าย Swing Left side");
  Swing_Left_side = Swing_Left + 12;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Left_side += 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Left_side -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, Swing_Left_side);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่ามือจับขวา วางป๋องหลุมขวา Swing Right side");
  Swing_Right_side = Swing_Right + 12;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Right_side -= 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Right_side += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, Swing_Right_side);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่ามือจับซ้าย วางป๋องหลุมกลาง Swing Left center");
  Swing_Left_center = Swing_Left - 22;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Left_center += 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Left_center -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, Swing_Left_center);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoArmWrite(chanal_Swing_Left, Swing_Left + 65);
  delay(200);

  Serial.println("หาค่ามือจับขวา วางป๋องหลุมกลาง Swing Right center");
  Swing_Right_center = Swing_Right - 22;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Right_center -= 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Right_center += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, Swing_Right_center);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  servoArmWrite(chanal_Swing_Left, Swing_Left + 65);
  servoArmWrite(chanal_Swing_Right, Swing_Right + 65);
  delay(1000);
  lift(3);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(31, 55, "COMPLETE", 0x07E0);
  beep(50);
  delay(50);
  beep(50);

  Serial.println();
  Serial.println("//////////////// ASSEMBLYMODE PLACE CAN ////////////////");
  Serial.println("int Swing_Left_side = " + String(Swing_Left_side) + "; //S0 สวิงแขนซ้าย วางป๋องซ้าย เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Swing_Left_center = " + String(Swing_Left_center) + "; //S0 สวิงแขนซ้าย วางป๋องกลาง เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Swing_Right_side = " + String(Swing_Right_side) + "; //S1 สวิงแขนขวา วางป๋องขวา เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Swing_Right_center = " + String(Swing_Right_center) + "; //S1 สวิงแขนขวา วางป๋องกลาง เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("////////////////////////////////////////////////////////");
}