void Can3() {
}

void Block3_1()
{
  delay(300);
  KA();
  spinDegree(90);
  SetBack(25,140);

  FF(40,660+460,'R');
  MoveBlock40(1,'R');
  SetBack(25,180,'L');
  pickcan(5,3);
  stock();
}

void Block3_2()
{
  KC();
  BackBlock60(1.8);
  SetBack(25,140,'L');delay(150);
  SetBack(25,150);

  autoPlaceCan(15);
}