void Can4() {
  delay(300); //must have
  spinDegree(90);
  SetBack(25,160);
  FF(40,660,'L');
  BB(40,660+440);
  SetBack(25,160,'L');

  autoPlaceCan(10);
}
void Retry1()
{
  count_pick=1;
  SetBack(25,160);
  MoveBlock60(1,'L');

  BackBlock60(1);
  SetBack(25,160,'R');

  FF(40,660,'R');
  BB(40,660+460);
  
  SetBack(25,120);
  SetBack(25,140);

  FF(40,660,'L');
  SetBack(25,160);
  pickcan(0,2);
  stock();

  Block2_2();
  Block3_1();Block3_2();
  EndMission(); //unnescessary
}

void Retry2()
{
  count_pick=2;
  
  SetBack(25,160);
  MoveBlock60(1,'L');

  BackBlock60(1);
  SetBack(25,180,'L');

  pickcan(5,3);
  stock();

  Block3_2();
  EndMission(); //unnescessary
}

void FullMap(){
  Block1_1();Block1_2();
  Block2_1();Block2_2();
  Block3_1();Block3_2();

  EndMission(); //unnescessary
}