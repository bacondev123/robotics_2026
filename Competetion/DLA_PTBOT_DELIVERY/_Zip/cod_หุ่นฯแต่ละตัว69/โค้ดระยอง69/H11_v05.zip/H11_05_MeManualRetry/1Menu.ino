int readKnob2() {
  long sum = 0;
  for (int i = 0; i < 20; i++) {
    sum += analogRead(32);
    delay(1);
  }
  return sum / 20;
}

void SelectMenu() {
  motorStop();
  lcdSetTextSize(1);
  tft.fillScreen(ST77XX_BLACK);

  lcdPrintText(0, 20, "A ComingSoon..                          ", 0xffff);
  lcdPrintText(0, 40, "B Menu                              ", 0xffff);

  while (1) {
    if (switchRead(A) == 1) {
      while (switchRead(A) == 1) { delay(10); }
      // SelectPlace();
      break;
    } else if (switchRead(B) == 1) {
      while (switchRead(B) == 1) { delay(10); }
      MenuTEST();
      break;
    }
    delay(10);
  }
  lcdClear();
}

void MenuTEST() {
  int lastX = -1;
  int stableX = 0;
  int confidence = 0;

  tft.fillScreen(ST77XX_BLACK);
  setupServo();
  while (1) {
    setAngleOffset();
    lcdSetTextSize(1);
    tft.fillScreen(ST77XX_BLACK);
    setupServo();
    lift(0);
    
    beep(300);
    setAngleOffset();
    current_degree = 0;

    while (1) {

      if (switchRead(A) == 1 || switchRead(B) == 1) {
        // delay(20);
        char pressedBtn = 'N';
        if (switchRead(A) == 1) pressedBtn = 'A';
        else if (switchRead(B) == 1) pressedBtn = 'B';
        
        if (pressedBtn != 'N') {
          while (switchRead(A) == 1 || switchRead(B) == 1) { delay(10); }
          
          X = stableX;
          DoMenu(pressedBtn);

          motorStop();
          tft.fillScreen(ST77XX_BLACK);
          lcdSetTextSize(1);
          
          lcdPrintText(44, 30, "Press A or B", 0xffff);
          lcdPrintText(56, 50, "to Reset", 0xffff);

          while (switchRead(A) == 0 && switchRead(B) == 0) {
            delay(10);
          }

          while (switchRead(A) == 1 || switchRead(B) == 1) {
            delay(10);
          }

          lift(2);

          lastX = -1;
          tft.fillScreen(ST77XX_BLACK);
          break;
        }
      }
      
      if (switchRead(A) == 0 && switchRead(B) == 0) {
        int raw = readKnob2();
        int tempX = map(constrain(raw, 1230, 2530), 1230, 2530, 0, 13);
        
        if (tempX != stableX) {
          confidence++;
          if (confidence > 4) { //
            stableX = tempX;
            confidence = 0;
          }
        } else {
          confidence = 0;
        }
        
        if (stableX != lastX) {
          tft.fillRect(0, 0, 160, 60, ST77XX_BLACK);
          lcdPrintText(0, 0, "MENU: " + String(stableX), 0xffff);
          X = stableX;
          ReadMenu();
          lastX = stableX;
        }
      }
      delay(10);
    }
  }
}
void MenuRun() {
  int lastX = -1;
  int stableX = 0;
  int confidence = 0;

  tft.fillScreen(ST77XX_BLACK);
  lift(0);
  KA();
  while (1) {
    setAngleOffset();
    lcdSetTextSize(1);
    tft.fillScreen(ST77XX_BLACK);
    KA();
    lift(0);
    
    beep(300);
    setAngleOffset();
    current_degree = 0;

    while (1) {

      if (switchRead(A) == 1 || switchRead(B) == 1) {
        // delay(20);
        char pressedBtn = 'N';
        if (switchRead(A) == 1) pressedBtn = 'A';
        else if (switchRead(B) == 1) pressedBtn = 'B';
        
        if (pressedBtn != 'N') {
          while (switchRead(A) == 1 || switchRead(B) == 1) { delay(10); }
          
          X = stableX;
          DoMenuRun(pressedBtn);

          motorStop();
          tft.fillScreen(ST77XX_BLACK);
          lcdSetTextSize(1);
          
          lcdPrintText(44, 30, "Press A or B", 0xffff);
          lcdPrintText(56, 50, "to Reset", 0xffff);

          while (switchRead(A) == 0 && switchRead(B) == 0) {
            delay(10);
          }

          while (switchRead(A) == 1 || switchRead(B) == 1) {
            delay(10);
          }

          lift(2);

          lastX = -1;
          tft.fillScreen(ST77XX_BLACK);
          break;
        }
      }
      
      if (switchRead(A) == 0 && switchRead(B) == 0) {
        int raw = readKnob2();
        int tempX = map(constrain(raw, 1230, 2530), 1230, 2530, 0, 1);
        
        if (tempX != stableX) {
          confidence++;
          if (confidence > 4) { //
            stableX = tempX;
            confidence = 0;
          }
        } else {
          confidence = 0;
        }
        
        if (stableX != lastX) {
          tft.fillRect(0, 0, 160, 60, ST77XX_BLACK);
          lcdPrintText(0, 0, "MENU: " + String(stableX), 0xffff);
          X = stableX;
          ReadMenuRun();
          lastX = stableX;
        }
      }
      delay(10);
    }
  }
}

void ReadMenu() {
  // ใช้ switch-case
  switch (X) {
    case 0:
      lcdPrintText(0, 20, "A Calib_Can                               ", 0xffff);
      lcdPrintText(0, 40, "B readloop                              ", 0xffff);
      break;
    case 1:
      lcdPrintText(0, 20, "A Value_SS                             ", 0xffff);
      lcdPrintText(0, 40, "B SonarLCD                         ", 0xffff);
      break;
    case 2:
      lcdPrintText(0, 20, "A sb                              ", 0xffff);
      lcdPrintText(0, 40, "B sf              ", 0xffff);
      break;
    case 3:
      lcdPrintText(0, 20, "A MB40 1                                ", 0xffff);
      lcdPrintText(0, 40, "B MB40 2                                ", 0xffff);
      break;
    case 4:
      lcdPrintText(0, 20, "A bb40 1                            ", 0xffff);
      lcdPrintText(0, 40, "B bb40 2                          ", 0xffff);
      break;
    case 5:
      lcdPrintText(0, 20, "A MB60 1                               ", 0xffff);
      lcdPrintText(0, 40, "B MB60 2                             ", 0xffff);
      break;
    case 6:
      lcdPrintText(0, 20, "A bb60 1                               ", 0xffff);
      lcdPrintText(0, 40, "B bb60 2                            ", 0xffff);
      break;
    case 7:
      lcdPrintText(0, 20, "A MB80 1                               ", 0xffff);
      lcdPrintText(0, 40, "B MB80 2                             ", 0xffff);
      break;
    case 8:
      lcdPrintText(0, 20, "A bb80 1                               ", 0xffff);
      lcdPrintText(0, 40, "B bb80 2                             ", 0xffff);
      break;
    case 9:
      lcdPrintText(0, 20, "A SL 80                              ", 0xffff);
      lcdPrintText(0, 40, "B sppA 65                          ", 0xffff);
      break;
    case 10:
      lcdPrintText(0, 20, "A                             ", 0xffff);
      lcdPrintText(0, 40, "B                           ", 0xffff);
      break;
    case 11:
      lcdPrintText(0, 20, "A                              ", 0xffff);
      lcdPrintText(0, 40, "B                            ", 0xffff);
      break;
    case 12:
      lcdPrintText(0, 20, "A                             ", 0xffff);
      lcdPrintText(0, 40, "B                           ", 0xffff);
      break;
    default:
      // กรณีค่า X อื่นๆ หรือ 99
      lcdPrintText(0, 20, "A Not Use                           ", 0xffff);
      lcdPrintText(0, 40, "B Not Use                           ", 0xffff);
      break;
  }
}
void ReadMenuRun() {
  // ใช้ switch-case
  switch (X) {
    case 0:
      lcdPrintText(0, 20, "A FM                               ", 0xffff);
      lcdPrintText(0, 40, "B Select                              ", 0xffff);
      break;
    case 1:
      lcdPrintText(0, 20, "A R1                             ", 0xffff);
      lcdPrintText(0, 40, "B R2                         ", 0xffff);
      break;
    default:
      // กรณีค่า X อื่นๆ หรือ 99
      lcdPrintText(0, 20, "A Not Use                           ", 0xffff);
      lcdPrintText(0, 40, "B Not Use                           ", 0xffff);
      break;
  }
}