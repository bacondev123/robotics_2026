void Can1() {

}
void Block1_1()
{
  SetBack(25,160,'L');
  pickcan(5,1);
  stock();
}

void Block1_2()
{
  KC();

  spinDegree(-90);
  BB(40,670);
  SetBack(25,120,'R');

  autoPlaceCan(5);
}

void Test5(){
  setStandPlace('g', 'y', 'r');
  autoPickCan(5);
  stock();
  SetBack(25, 160,'L');
  autoPlaceCan(5);
}
void Test10(){
  setStandPlace('g', 'y', 'r');
  autoPickCan(5);
  stock();
  SetBack(25, 160,'L');
  autoPlaceCan(10);
}
void Test15(){
  setStandPlace('g', 'y', 'r');
  autoPickCan(5);
  stock();
  SetBack(25, 160,'L');
  autoPlaceCan(15);
}