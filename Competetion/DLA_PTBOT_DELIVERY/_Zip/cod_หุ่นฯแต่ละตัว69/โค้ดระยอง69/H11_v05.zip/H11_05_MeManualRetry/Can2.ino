void Can2() {

}

void Block2_1()
{
  KA();  // พับแขนเข้าตัว (ป้องกันมือสั่น)
  BB(40,670);
  SetBack(25,160,'R');

  FF(40,660,'R');
  BB(40,660+460);
  
  SetBack(25,120);
  SetBack(25,140);

  FF(40,640,'L');
  SetBack(25,160);
  pickcan(0,2);
  stock();
}

void Block2_2()
{
  KC();

  SetBack(25,160,'R');
  BB(40,660);
  SetBack(25,140,'L');

  autoPlaceCan(10); 
}