/* update : 01-08-2026 */
/* version : OPT-Senion-V3 */
/* ------------------------------------------------------------ */
#include <PTBOTAtomVX.h>
#include <ESP32Encoder.h>
#include <SoftI2C.h>

#define NO_SWITCH_LR 0
#define SWITCH_LR 1

/* ค่าเซ็นเซอร์ตรวจจับเส้น */
//                   S0   S1   S2   S3
int sensor_min[] = { 123, 85, 180, 175 };  // ค่าสีดำ
int sensor_max[] = { 650, 480, 710, 623 };  // ค่าสีขาว

/* ค่าเซ็นเซอร์อ่านค่าสี */
int clear_color_left = 2500;   // ค่าสีเหลืองมือจับด้านซ้าย
int clear_color_right = 2500;  // ค่าสีเหลืองมือจับด้านขวา

/* ความเร็วเดินหน้า หยิบป๋อง */
int speed_pick_can = 15;       // ความเร็วสูงสุด
int speed_pick_can_slow = 10;  // ความเร็วต่ำสุด

/* ความเร็วเดินหน้า วางป๋อง */
int speed_place_can = 15;   //20    // ความเร็วสูงสุด
int speed_place_can_slow = 10;  //10// ความเร็วต่ำสุด

/* ค่าระยะจอด */
float pick_can_floor = 8.65;     // หยิบป๋อง ที่พื้น (หากหยิบไม่ถึงให้ลด หากชนกระป๋องให้เพิ่ม)
float pick_can_distance = 4.75; //4.65   // หยิบป๋อง หน้าแท่นหยิบ (หากหยิบไม่ถึงให้ลด หากชนกระป๋องให้เพิ่ม)
float place_can_distance = 3.0; //2.55  // วางป๋อง หน้าแท่นวาง (หากวางเลยแท่นให้เพิ่ม หากวางไม่ถึงแท่นให้ลด)

/* ค่าระยะจอดหน้าแท่นวาง วางพร้อมกัน 2 ใบ */
int place_LR = 100;  // วางหลุมข้าง ซ้าย ขวา (หากถอยเลยหลุมให้ลด)

/* ค่าระยะจอดหน้าแท่นวาง วางที่ละข้าง */
float place_left_side = 220;     // ค่าระยะจอดกรณีมือซ้ายวางกระป๋องซ้าย
float place_left_center = 120;   // ค่าร bะยะจอดกรณีมือซ้ายวางกระป๋องกลาง
float place_right_side = 200;    // ค่าระย8ะจอดกรณีมือขวาวางกระป๋องขวา
float place_right_center = 120;  // ค่าระยะจอดกรณีมือขวาวางกระป๋องกลาง

/* ระยะทางเดินเข้าไปหยิบป๋องที่สลับไว้ ซ้าย ขวา สลับกัน */
int switch_moveToPickCan_distance = 500; //550       // ระยะทางเดินเข้าไปหยิบป๋องที่สลับไว้บนแท่น (หากหยิบไม่ถึงให้เเพิ่ม หากชนกระป๋องให้ลด)
int switch_moveToPickCan_distance_floor = 500; //550  // ระยะทางเดินเข้าไปหยิบป๋องที่สลับไว้ที่พื้น (หากหยิบไม่ถึงให้เเพิ่ม หากชนกระป๋องให้ลด)

/* ค่าระยะถอยออก ตอนหยิบและตอนวาง (400 = default) */
unsigned long after_pick_can_distance = 670;   // ระยะถอย หลังจากหยิบกระป๋อง (หากถอยเกิน 1 ช่องให้ลด หากถอยไม่ถึง 1 ช่องให้เพิ่ม)
unsigned long after_place_can_distance = 670;  // ระยะถอย หลังจากวางกระป๋อง (หากถอยเกิน 1 ช่องให้ลด หากถอยไม่ถึง 1 ช่องให้เพิ่ม)

float power_factor = 1.0;
int line_value[] = { 0, 0, 0, 0, 0, 0, 0, 0 };
float current_degree = 0;
float previous_error_forward = 0;
byte servo_pin[] = { 6, 5, 4, 0, 1, 2, 3 };
bool sonar_enable = 0, mode_setCan_Stock = 0, mode_Switch_Can_Color = 0;

long delayALL = 75;

int X;
bool Safe=false;
TaskHandle_t sonarTaskHandle = NULL;
TaskHandle_t switchGripperTaskHandle = NULL;
TwoWire Wire2 = TwoWire(1);

char CanL[3]={'u','u','u'};
char CanR[3]={'u','u','u'};
int autoplace=true;

void setup() {
  Serial.begin(115200);
  initialize();
  beep(100, 500); delay(100);
  beep(100, 800); delay(100); beep(100);
  xTaskCreatePinnedToCore(liftLoop, "liftLoop", 2048, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(sonarLoop, "sonarLoop", 2048, NULL, 1, &sonarTaskHandle, 0);
  xTaskCreatePinnedToCore(switchGripperLoop, "switchGripperLoop", 2048, NULL, 1, &switchGripperTaskHandle, 1);
  xTaskCreatePinnedToCore(stockLoop, "stockLoop", 2048, NULL, 1, NULL, 0);
  vTaskSuspend(sonarTaskHandle);
  vTaskSuspend(switchGripperTaskHandle);
  setupColorSensor();
  setupSensor();
  setupServo();

  // MenuTEST();
  // lift(2);

  ///////////////////////// เปิดอ่านค่า เซนเซอร์ ///////////////////////////
  // assemblyMode();        // ประกอบ และปรับค่า Servo (ตั้งค่าเริ่มต้น, โหมดสลับกระป๋อง, ตั้งเซอร์โวหาหลุม)  เลขโชว์ที่คอม
  // test_stock();          // ทดสอบสต็อกเข้า/ออก
  // ShowValue_Sensor();    // โชว์ค่าเซ็นเซอร์ตรวจจับเส้น เลขโชว์ที่หุ่นยนต์
  // ShowDistanceSensor();  // โชว์ค่าเซ็นเซอร์วัดระยะทาง  เลขโชว์ที่คอม
  // calibrateCanColor();   // Calibrate เซ็นเซอร์อ่านค่าสีกระป่อง  เลขโชว์ที่คอม //ค่ามาตราฐาน 2500
  // calibrateIMU();        // Calibrate เซ็นเซอร์ไจโร ไม่มีโชว์
  ////////////////////////////////////////////////////////////////////////

  modesetCanStock(1);     // 0 = no setCan หลังหยิบป๋องออกจากถาดก่อนวางป๋องบนแท่น 15cm, 1 = run setCan หลังหยิบป๋องออกจากถาดก่อนวางป๋องบนแท่น 15cm
  modeSwitchCanColor(0);  // 0 = no stock สีป๋องไขว้กันจะสลับป๋องซ้ายขวา, 1 = stock สีป๋องไขว้กันจะสต็อกเข้าถาดแทน
  // MenuTEST();

  // measureRobot();         // ลิฟท์ขึ้น หุบมือ และกางแขนออกถึงถาด
  // retractArmIN_Setup();   // พับแขนเข้าตัว ลิฟท์ลง (ป้องกันการชนขอบสนาม)
  
  // MenuTEST();
  SelectMenu();
  // STOP(); moveToCan0();
}

void loop() {
  // KA();
  // STOP();
  // MoveBlock60(1);
  // SetBack(25, 220, 'l');

  // Can1();  // ออกจากจุดสตาร์ท ไปหยิบกระป๋อง และไปวางแท่นที่ 1
  // Can2();  // ไปหยิบกระป๋อง และไปวางแท่นที่ 2
  // Can3();  // ไปหยิบกระป๋อง และไปวางแท่นที่ 3

  // Test5();STOP();
  // Test10();STOP();
  // Test15();


  // --------------------------------------------------------------------------------------------------------------------------- //
  // ถ้ากรณีมีป๋องในถาด ให้ไปเขียนใน Can4 วางป๋องแท่นที่ 1 หรือแท่นที่ 2 ก็ได้ พร้อมเขียนกลับจุดจบ
  // แต่ถ้ากรณีไม่มีป๋องในถาด ให้ไปเขียนใน EndMission กลับจุดจบได้เลย
  // ถ้าหากอยากทดสอบ ให้ปิดฟังก์ชั่น Can1(); Can2(); และ Can3(); เพื่อทดสอบ EndMission(); หรือทดสอบ Can4();

  // test_EndMission(); /* ทดสอบ EndMission(); หลังจากวางกระป๋องชุดที่ 3 เสร็จ หุ่นยนจ์วิ่งกลับจุดสตาร์ท */
  
  // test_Can4('l', 'g'); // ทดสอบ Can4(); หุ่นยนต์จะวิ่ง หลังจากวางกระป๋องชุดที่ 3 เสร็จ และจะวิ่งไปวางป๋องตามเส้นทางที่เขียนไว้ พร้อมเขียนกลับจุดสตาร์ท
  /*            |    ^ เลือกสีกระป๋อง ('g' = สีเขียว, 'y' = สีเหลือง, 'r' = สีแดง) */
  /*            ^ เลือกถาดที่จะสต็อกกระป๋อง ('l' = ถาดซ้าย, 'r' = ถาดขวา) */
  // --------------------------------------------------------------------------------------------------------------------------- //
}