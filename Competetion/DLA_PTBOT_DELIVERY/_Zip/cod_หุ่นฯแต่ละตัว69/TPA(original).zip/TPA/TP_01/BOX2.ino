// S 40 D 700 = 1Box
  // S 60 D 535 = 1Box
  // S 60 D 840 = 2Box
  // S 60 D 1220 = 3Box
  ///////--> motorTimeDegree_Enhanced( 30, 60, 840, 'L');
  // 1 Box = 250
  // 2 Box = 600
  // 3 Box = 900
  // 4 Box = 1250
  ///////--> motorTimeDegree_Enhanced( 30, 80, 840, 'L');
  // 1 Box = 200
  // 2 Box = 475
  // 3 Box = 725
  // 4 Box = 975
  ///////--> motorTimeBackDegree_Enhanced( 30, 60, 840, 'L');
  // --> เซ็ตหน้า/หลัง
  // --> 330
  // --> ตอนคีบแล้วจะถอยหลังมากลางบล็อก
  // --> -150
  // SetBack(20, 315);
  // SetFront(20, 315, 'L');
  // SetFront_Wall(20, 315, 'R');
void Box2()
{
  //Box1
  motorTimeDegree_Enhanced( 30, 60, 900, 'R');
  motorTimeDegree_Enhanced( 30, 60, 600, 'R');SetBack(20, 315);
  motorTimeDegree_Enhanced( 30, 60, 250, 'R');
  motorTimeDegree_Enhanced( 30, 60, 250, 'L');
  motorTimeDegree_Enhanced( 30, 60, 250, 'L');SetBack(20, 315);
  motorTimeDegree_Enhanced( 30, 60, 1250, 'R');
  motorTimeDegree_Enhanced( 30, 60, 200);SetFront_Wall(20, 315, 'R');
  motorTimeDegree_Enhanced( 30, 60, 550, 'L');SetFront_Wall(20, 315, 'R');
  pickCan(5, NO_SWITCH_LR);

  motorTimeDegree_Enhanced( -30, -60, 475, 'R');
  motorTimeDegree_Enhanced( 30, 60, 250, 'R');
  motorTimeDegree_Enhanced( 30, 60, 500);SetFront_Wall(20, 315, 'R');
  placeCan1_NoShake(10, 4, 'l', 'l');

  SetBack(20, 315, 'R');
  motorTimeDegree_Enhanced( 30, 60, 250, 'L');
  motorTimeDegree_Enhanced( 30, 60, 250);
  motorTimeDegree_Enhanced( -30, -60, 200);SetBack(20, 315, 'R');
  motorTimeDegree_Enhanced( 30, 60, 250, 'R');
  motorTimeDegree_Enhanced( 30, 60, 250, 'R');
  motorTimeDegree_Enhanced( 30, 60, 250, 'L');
  motorTimeDegree_Enhanced( 30, 60, 200);SetFront_Wall(20, 315, 'R');
  placeCan1_NoShake(10, 4, 'r', 'r');

  // SetBack(20, 315, 'R');SetBack(20, 315);
  // motorTimeDegree_Enhanced( 30, 60, 250, 'L');
  // motorTimeDegree_Enhanced( 30, 60, 250);
  // motorTimeDegree_Enhanced( -30, -60, 250);SetBack(20, 315, 'R');
  // motorTimeDegree_Enhanced( 30, 60, 250, 'R');
  // motorTimeDegree_Enhanced( 30, 60, 250, 'R');
  // motorTimeDegree_Enhanced( 30, 60, 250, 'L');
  // motorTimeDegree_Enhanced( 30, 60, 200);SetFront_Wall(20, 315, 'R');
  // SetBack(20, 315);
  // placeCan1_NoShake(15, 4, 'r', 'c');delay(1000);

  // SetBack(20, 315, 'R');
  // motorTimeDegree_Enhanced( 30, 60, 250);SetFront(20, 315, 'L');
  // motorTimeDegree_Enhanced( 30, 40, 150);
  // pickCan(0, NO_SWITCH_LR);

  // motorTimeDegree_Enhanced( -30, -60, 300);SetBack(20, 315, 'R');
  // motorTimeDegree_Enhanced( 30, 60, 250, 'L');
  // motorTimeDegree_Enhanced( 30, 60, 400);SetFront_Wall(20, 315, 'R');
  // placeCan1_NoShake(10, 4, 'l', 'l');

  // SetBack(20, 315, 'R');
  // SetBack(20, 315);
  // motorTimeDegree_Enhanced( 30, 60, 600);
  // motorTimeDegree_Enhanced( 30, 60, 1250);SetFront(20, 315, 'L');
  // placeCan1_NoShake(5, 4, 'r', 'r');

  // motorTimeDegree_Enhanced( -30, -60, 125, 'L');SetBack(20, 315);
  // motorTimeDegree_Enhanced( 30, 60, 1250, 'L');
  // motorTimeDegree_Enhanced( 30, 60, 550);SetFront_Wall(20, 315, 'L');
  // motorTimeDegree_Enhanced( 30, 60, 550);SetFront(20, 380, 'L');
  // pickCan(5, NO_SWITCH_LR);

  // SetBack(20, 315, 'L');
  // motorTimeDegree_Enhanced( 30, 60, 550);SetFront(20, 315, 'R');
  // motorTimeDegree_Enhanced( 30, 60, 250, 'L');
  // motorTimeDegree_Enhanced( 30, 60, 250, 'L');
  // motorTimeDegree_Enhanced( 30, 60, 200);SetFront_Wall(20, 315, 'R');
  // placeCan1_NoShake(15, 4, 'r', 'r');delay(1000);

  // SetBack(20, 315, 'R');
  // motorTimeDegree_Enhanced( 30, 60, 250, 'R');
  // motorTimeDegree_Enhanced( 30, 60, 250);SetFront(20, 315, 'L');
  // motorTimeDegree_Enhanced( 30, 60, 250, 'R');lift(3);
  // motorTimeDegree_Enhanced( 30, 60, 1250);SetFront(20, 315, 'L');
  // placeCan1_NoShake(5, 4, 'l', 'l');

  // motorTimeDegree_Enhanced( -30, -60, 400);SetBack(20, 315, 'L');
  // motorTimeDegree_Enhanced( 30, 60, 250, 'L');
  // motorTimeDegree_Enhanced( 30, 60, 250, 'L');
  // motorTimeDegree_Enhanced( 30, 60, 500);SetFront_Wall(20, 315, 'L');
  // motorTimeDegree_Enhanced( 30, 60, 900);
  //-->> END
}