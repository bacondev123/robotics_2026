#include <PTBOTAtomVX.h>
#include <ESP32Encoder.h>
#include <SoftI2C.h>

#define NO_SWITCH_LR 0
#define SWITCH_LR 1

/* ค่าเซ็นเซอร์ตรวจจับเส้น */
//                   S0   S1   S2   S3
int sensor_min[] = { 80, 80, 150, 80 };  // ค่าสีดำ
int sensor_max[] = { 430, 490, 700, 600 };  // ค่าสีขาว

/* ค่าเซ็นเซอร์อ่านค่าสี */
int clear_color_left = 3000;   // ค่าสีเหลืองมือจับด้านซ้าย
int clear_color_right = 3000;  // ค่าสีเหลืองมือจับด้านขวา

/* หยิบกระป๋องที่พื้น ultra */
float pick_can_floor = 13.5;  // ที่พื้น

/* ค่าระยะจอดหน้าแท่นหยิบ */
float pick_can_distance = 8.0;  // หน้าแท่นหยิบ


/* ระยะทางเดินเข้าไปหยิบป๋องที่สลับไว้ แดงซ้าย เขียวขวา */
int switch_moveToPickCan_distance = 800;  // ค่าระยะจอดสลับป๋อง แดงซ้าย เขียวขวา เดินเข้าไปหยิบป๋องหน้าแท่นหยิบ

int switch_moveToPickCan_distance_floor = 800;  // ค่าระยะจอดสลับป๋อง แดงซ้าย เขียวขวา เดินเข้าไปหยิบป๋องที่พื้น

/* ค่าระยะจอดหน้าแท่นวาง */
int place_left_side = 250;     // ค่าระยะจอดกรณีมือซ้ายวางกระป๋องซ้าย
int place_left_center = 150;   // ค่าระยะจอดกรณีมือซ้ายวางกระป๋องกลาง
int place_right_side = 250;    // ค่าระยะจอดกรณีมือขวาวางกระป๋องขวา
int place_right_center = 150;  // ค่าระยะจอดกรณีมือขวาวางกระป๋องกลาง

float power_factor = 1.0;
int line_value[] = { 0, 0, 0, 0, 0, 0, 0, 0 };
float current_degree = 0;
float previous_error_forward = 0;
byte servo_pin[] = { 6, 5, 4, 0, 1, 2, 3 };
bool sonar_enable = 0, mode_setCan_Stock = 0;

long delayALL = 100;

TaskHandle_t sonarTaskHandle = NULL;
TaskHandle_t switchGripperTaskHandle = NULL;
TwoWire Wire2 = TwoWire(1);

char Can_Station[2] = {'g' , 'r'};
int Station = 0;

int BackwardDlay = 550;
int BackwardDlayPlace = 300;

float place_can_distance = 7.5;

void setup() {
  Serial.begin(115200);
  initialize();
  xTaskCreatePinnedToCore(liftLoop, "liftLoop", 2048, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(sonarLoop, "sonarLoop", 2048, NULL, 1, &sonarTaskHandle, 0);
  xTaskCreatePinnedToCore(switchGripperLoop, "switchGripperLoop", 2048, NULL, 1, &switchGripperTaskHandle, 1);
  xTaskCreatePinnedToCore(stockLoop, "stockLoop", 2048, NULL, 1, NULL, 0);
  vTaskSuspend(sonarTaskHandle);
  vTaskSuspend(switchGripperTaskHandle);
  // setupColorSensor();
  setupSensor();
  setupServo();
  lift(0);
  STOP();
  // PickCan(5);
  Can1();

  // OnStockIN('a');
  // STOP();
  // OnStockOut('l');
  // Can1();
  // Can2();

  // lift(15);
  ///////////////////////// เปิดอ่านค่า เซนเซอร์ ///////////////////////////
  // assemblyMode();            // ประกอบ และปรับค่า Servo (ตั้งค่าเริ่มต้น, โหมดสลับกระป๋อง, ตั้งเซอร์โวหาหลุม)
  // assemblyMode_switchCan();  // ปรับค่า Servo โหมดสลับกระป๋อง
  // assemblyMode_placeCan();   // ปรับค่า Servo ตั้งเซอร์โวหาหลุม
  // ShowValue_Sensor();        // โชว์ค่าเซ็นเซอร์ตรวจจับเส้น
  // ShowDistanceSensor();      // โชว์ค่าเซ็นเซอร์วัดระยะทาง
  // calibrateCanColor();       // Calibrate เซ็นเซอร์อ่านค่าสีกระป่อง
  // calibrateIMU();            // Calibrate เซ็นเซอร์ไจโร
  ////////////////////////////////////////////////////////////////////////
  // modesetCanStock(1);  // 0 = no setCan หลังหยิบป๋องออกจากถาดก่อนวางป๋องบนแท่น 15cm, 1 = run setCan หลังหยิบป๋องออกจากถาดก่อนวางป๋องบนแท่น 15cm
  // measureRobot();      // หุบมือ และกางแขนออกถึงถาด
}

void loop() {
  // STOP();
  // retractArmIN_Setup();  // พับแขนเข้าตัว (ป้องกันการชนขอบสนาม)

  // Can1();  // ออกจากจุดสตาร์ท ไปหยิบกระป๋อง และไปวางแท่นที่ 1
  // Can2();  // ไปหยิบกระป๋อง และไปวางแท่นที่ 2
  // Can3();  // ไปหยิบกระป๋อง และไปวางแท่นที่ 3

  // ถ้ากรณีมีป๋องในถาด ให้ไปเขียนใน Can4 วางป๋องแท่นที่ 1 หรือแท่นที่ 2 ก็ได้ พร้อมเขียนกลับจุดจบ
  // แต่ถ้ากรณีไม่มีป๋องในถาด ให้ไปเขียนใน EndMission กลับจุดจบได้เลย
}