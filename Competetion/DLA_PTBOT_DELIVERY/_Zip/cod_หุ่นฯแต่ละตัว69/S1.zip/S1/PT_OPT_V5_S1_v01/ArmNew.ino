void OnStockIN(char replaceValue) {
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  if (replaceValue == 'l' && can_in_stock[0] == 'u') {
    stockInNew('l', false);
    delay(500);

    can_in_stock[0] = 'l';
  }
  if (replaceValue == 'r' && can_in_stock[0] == 'u') {
    stockInNew('r', false);
    delay(500);

    can_in_stock[1] = 'r';
  }
  if (replaceValue == 'a' && can_in_stock[0] == 'u' && can_in_stock[1] == 'u') {
    stockInNew('a', false);
    delay(500);

    can_in_stock[0] = 'l';
    can_in_stock[1] = 'r';
  }
  delay(2500);
}
void OnStockOut(int replaceValue) {
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  if (replaceValue == 'l' && can_in_stock[0] != 'u') {
    stockOutNew('l', false);
    delay(500);

    can_in_stock[0] = 'u';
  }
  if (replaceValue == 'r' && can_in_stock[1] != 'u') {
    stockOutNew('r', false);
    delay(500);

    can_in_stock[1] = 'u';
  }
  if (replaceValue == 'a' && can_in_stock[0] != 'u' && can_in_stock[1] != 'u') {
    stockOutNew('a', false);
    delay(500);

    can_in_stock[1] = 'u';
  }
  delay(2500);
}

void ResetCan() {
  delay(300);
  lift(1);
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  delay(200);
  servoArmWrite(chanal_Gripper_Left, Close_Left - 28);
  servoArmWrite(chanal_Gripper_Right, Close_Right - 28);
  delay(150);
  lift(0);
  delay(350);
  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  delay(300);
  lift(3);
  delay(200);
}
void ResetCanA() {
  delay(300);
  lift(1);
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  delay(200);
  servoArmWrite(chanal_Gripper_Left, Close_Left - 28);
  servoArmWrite(chanal_Gripper_Right, Close_Right - 28);
  delay(150);
  lift(0);
  delay(350);
  FF(15,215);
  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  delay(300);
  lift(3);
  delay(200);
  BB(15,215);
}

void PickTEST(int pick_height){
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  servoArmWrite(chanal_Gripper_Right, Open_Right);
  lift(pick_height);
  if (pick_height != 0) moveToCan(pick_can_distance);
  else moveToCan(pick_can_floor);
  delay(100);
  servoCloseLeft();
  servoCloseRight();
}
void PickCan(int pick_height) {
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  servoArmWrite(chanal_Gripper_Right, Open_Right);
  lift(pick_height);
  if (pick_height != 0) moveToCan(pick_can_distance);
  else moveToCan(pick_can_floor);
  // STOP(); //รอกด
  delay(100);
  servoCloseLeft();
  servoCloseRight();
  delay(200);
  lift(pick_height + 3);
  delay(200);
  BB(30, 400);
  lift(3);
  delay(200);
  BB(30, BackwardDlay);
  delay(200);
  ResetCanA();
}

void placeCanOne(int drop_height, char from_gripper, char drop_point) {
  bool switch_can = 0;
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Close_Left + 3);
  servoArmWrite(chanal_Gripper_Right, Close_Right + 3);
  lift(drop_height + 3);
  if (drop_height == 10) {
    delay(500);
  } else if (drop_height == 15) {
    delay(750);
  }
  if (from_gripper == 'l' && drop_point == 'l') {
    swingGripper('l', Swing_Left_side);
    swingGripper('r', Swing_Right + 65);
  } else if (from_gripper == 'l' && drop_point == 'c') {
    swingGripper('l', Swing_Left_center);
    swingGripper('r', Swing_Right + 65);
  } else if (from_gripper == 'r' && drop_point == 'r') {
    swingGripper('l', Swing_Left + 65);
    swingGripper('r', Swing_Right_side);
  } else if (from_gripper == 'r' && drop_point == 'c') {
    swingGripper('l', Swing_Left + 65);
    swingGripper('r', Swing_Right_center);
  } else {
    vTaskResume(switchGripperTaskHandle);
    delay(10);
    switchGripper(from_gripper, drop_point);
    switch_can = 1;
  }
  moveToCan(place_can_distance);
  setAngleOffset();
  current_degree = 0;
  // BB(10, distance);
  lift(drop_height + 0);
  delay(150);
  //--------------------------
  dropCan(from_gripper);
  //----------------------------
  delay(200);
  vTaskSuspend(switchGripperTaskHandle);
  BB(30, 425);
  lift(2);
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoCloseLeft();
  servoCloseRight();
  BB(30, BackwardDlayPlace);
  delay(200);
}

void placeCanTwo(int drop_height, char left_gripper, char right_gripper) {
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Close_Left + 3);
  servoArmWrite(chanal_Gripper_Right, Close_Right + 3);
  lift(drop_height + 3);
  if (drop_height == 10) {
    delay(500);
  } else if (drop_height == 15) {
    delay(750);
  }
  if (left_gripper == 'l' && right_gripper == 'c') {
    swingGripper('l', Swing_Left_side);
    swingGripper('r', Swing_Right_center);
  } else if (left_gripper == 'l' && right_gripper == 'r') {
    swingGripper('l', Swing_Left_side);
    swingGripper('r', Swing_Right_side);
  } else if (left_gripper == 'c' && right_gripper == 'r') {
    swingGripper('l', Swing_Left_center);
    swingGripper('r', Swing_Right_side);
  } else if (left_gripper == 's' && right_gripper == 's') {
    swingGripper('l', Swing_Left_T);
    swingGripper('r', Swing_Right_T);
  } else {
    beep(50);
  }
  moveToCan(place_can_distance);
  setAngleOffset();
  current_degree = 0;
  // BB(10, distance);
  lift(drop_height + 0);
  delay(150);
  //--------------------------
  dropCan('a');
  //----------------------------
  delay(200);
  vTaskSuspend(switchGripperTaskHandle);
  BB(30, 425);
  lift(2);
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoCloseLeft();
  servoCloseRight();
  BB(30, BackwardDlayPlace);
  delay(200);
}