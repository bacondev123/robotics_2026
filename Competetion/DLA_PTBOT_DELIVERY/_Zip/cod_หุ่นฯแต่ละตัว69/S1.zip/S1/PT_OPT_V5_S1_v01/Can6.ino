void Can6() {
  
}

void CanTEST()
{
  SetBack(25,280,'L');
  // PickCan();
}