void DoMenu(char btn) {  // รับชื่อปุ่มมาจาก MenuTESTNEW
  setAngleOffset();
  lcdSetTextSize(1);
  tft.fillScreen(ST77XX_BLACK);
  lift(2);

  beep(300);
  // RA_StartUp();
  setAngleOffset();
  current_degree = 0;

  if (X == 0) {
    if (btn == 'A'){calibrateCanColor();} 
    else if (btn == 'B'){CheckColLoop();}
  } 
  
  else if (X == 1) {
    if (btn == 'A') {ShowValue_Sensor();} 
    else if (btn == 'B'){ShowDistanceSensorLCD();ShowDistanceSensor();}
  } 
  
  else if (X == 2) {
    if (btn == 'A') {SetBack(25, 150);SetBack(25, 280);} 
    else if (btn == 'B') {SetFront(25,150);SetFront(25,280);}
  }
  
  else if (X == 3) {
    if (btn == 'A') {Block1_1();Block1_2();} 
    else if (btn == 'B') {Block2_1();Block2_2();}
  }
  
  else if (X == 4) {
    if (btn == 'A') {Block3_1();Block3_2();} 
    else if (btn == 'B') {FullMap();}
  }
  
  else if (X == 5) {
    if (btn == 'A') {BackBlock40(1);} 
    else if (btn == 'B') {BackBlock40(2);}
  }
  
  else if (X == 6) {
    if (btn == 'A') {BackBlock60(1);} 
    else if (btn == 'B') {BackBlock60(2);}
  }
  
  else if (X == 7) {
    if (btn == 'A') {MoveBlock80(2);} 
    else if (btn == 'B') {BackBlock80(2);}
  }
  
  else if (X == 8) {
    if (btn == 'A') {} 
    else if (btn == 'B') {}
  }
  
  else if (X == 9) {
    if (btn == 'A') {TestHOLD();} 
    else if (btn == 'B') {}
  }
  
  else if (X == 10) {
    if (btn == 'A') {} 
    else if (btn == 'B') {}
  }
  
  else if (X == 11) {
    if (btn == 'A') {} 
    else if (btn == 'B') {}
  }
  
  else if (X == 12) {
    if (btn == 'A') {} 
    else if (btn == 'B') {}
  }

  motorStop();
  delay(100);
}