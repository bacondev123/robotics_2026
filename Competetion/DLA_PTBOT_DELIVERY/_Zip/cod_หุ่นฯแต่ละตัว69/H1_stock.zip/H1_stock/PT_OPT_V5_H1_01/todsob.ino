void TestHOLD() {
  int pick_height=0;
  lift(0);
  delay(100);
  servoCloseLeft();
  servoCloseRight();
  delay(200);
  lift(pick_height + 3);
  delay(200);
  can_in_gripper[0] = readColor('l');
  can_in_gripper[1] = readColor('r');
  delay(50);
  can_in_gripper[0] = readColor('l');
  can_in_gripper[1] = readColor('r');
  delay(50);
  can_in_gripper[0] = readColor('l');
  can_in_gripper[1] = readColor('r');
  count_pick += 1;
  if (can_in_gripper[0] == can_in_gripper[1]) {
    if (count_pick == 3 && (can_in_gripper[0] == can_in_gripper[1])) {
      State_EndMission = true;
    }
    // FF(30,200);
    if (can_in_gripper[0] == 'r') {
      if (can_in_stock[0] == 'u') {
        stockIn('l', can_in_gripper[0], true);
        can_in_gripper[0] = 'u';
        can_in_gripper[1] = 'r';
      } else if (can_in_stock[1] == 'u') {
        stockIn('r', can_in_gripper[0], true);
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'u';
      } else {
        while (1) {
          beep(10000);
        }
      }
    } else {
      if (can_in_gripper[0] == 'g') can_in_gripper[0] = 'l';
      else if (can_in_gripper[0] == 'y') can_in_gripper[0] = 'c';
      if (can_in_stock[1] == 'u') {
        stockIn('r', can_in_gripper[0], true);
        can_in_gripper[1] = 'u';
      } else if (can_in_stock[0] == 'u') {
        stockIn('l', can_in_gripper[0], true);
        can_in_gripper[1] = can_in_gripper[0];
        can_in_gripper[0] = 'u';
      } else {
        while (1) {
          beep(10000);
        }
      }
    }
    // BB(30, 250);
  } else {
    if (((hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'g')) || ((hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') && (can_in_gripper[0] == 'y' && can_in_gripper[1] == 'g')) || ((hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'y')) || ((hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') && (can_in_gripper[0] == 'g' && can_in_gripper[1] == 'y')) || ((hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') && (can_in_gripper[0] == 'y' && can_in_gripper[1] == 'r')) || ((hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') && (can_in_gripper[0] == 'g' && can_in_gripper[1] == 'r'))) {
      vTaskResume(switchGripperTaskHandle);
      delay(10);
      swingGripper('l', Swing_Left_center-3);
      delay(500);
      servoArmWrite(chanal_Gripper_Left, Close_Left - 15);
      delay(300);
      servoArmWrite(chanal_Gripper_Left, Open_Left-20);
      delay(400);
      BB(30, 400);
      switchGripper('r', 'l');
      delay(1400);
      servoArmWrite(chanal_Gripper_Right, Open_Right-20);
      swingGripper('r', Swing_Right_center+2);
      delay(200);
      moveToCan(pick_can_distance);
      lift(pick_height + 2);
      servoCloseRight();
      delay(200);
      vTaskSuspend(switchGripperTaskHandle);
      servoArmWrite(chanal_Swing_Left, Swing_Left);
      servoArmWrite(chanal_Swing_Right, Swing_Right);
      delay(300);
      lift(pick_height + 3);
      delay(200);
      if (hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') {
        can_in_gripper[0] = 'l';
        can_in_gripper[1] = 'r';
      }
      if (hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') {
        can_in_gripper[0] = 'l';
        can_in_gripper[1] = 'c';
      }
      if (hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') {
        can_in_gripper[0] = 'c';
        can_in_gripper[1] = 'r';
      }
      if (hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') {
        can_in_gripper[0] = 'c';
        can_in_gripper[1] = 'l';
      }
      if (hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') {
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'c';
      }
      if (hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') {
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'l';
      }
      delay(200);

      lift(3);
    } else {
      if (can_in_gripper[0] == 'r') can_in_gripper[0] = 'r';
      else if (can_in_gripper[0] == 'g') can_in_gripper[0] = 'l';
      else if (can_in_gripper[0] == 'y') can_in_gripper[0] = 'c';
      if (can_in_gripper[1] == 'r') can_in_gripper[1] = 'r';
      else if (can_in_gripper[1] == 'g') can_in_gripper[1] = 'l';
      else if (can_in_gripper[1] == 'y') can_in_gripper[1] = 'c';

      lift(3);
    }
  }
  lift(3);
  delay(200);
  delay(200);
}