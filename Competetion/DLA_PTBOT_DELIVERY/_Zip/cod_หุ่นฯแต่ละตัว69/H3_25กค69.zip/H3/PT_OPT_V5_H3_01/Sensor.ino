void readLine() {
  for (byte i = 0; i < 4; i++) {
    line_value[i] = map(adcRead(i), sensor_min[i], sensor_max[i], 0, 100);
    if (line_value[i] < 0) line_value[i] = 0;
    else if (line_value[i] > 100) line_value[i] = 100;
  }
}

void ShowValue_Sensor() {
  lcdClear();
  while (1) {
    int num_sensor = 4;
    int sensor_values[num_sensor];
    for (int i = 0; i < num_sensor; i++) {
      sensor_values[i] = adcRead(i);
    }
    lcdDrawChart(sensor_values, num_sensor);
  }
}

void CheckColLoop() {
  delay(100);
  while (1) {
    readColor('r');
    readColor('l');
  }
}

void sonarLoop(void* pvParameters) {
  int TRIG_PIN = 25;
  int ECHO_PIN = 26;
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  while (1) {
    if (sonar_enable == 1) {
      digitalWrite(TRIG_PIN, LOW);
      delayMicroseconds(2);
      digitalWrite(TRIG_PIN, HIGH);
      delayMicroseconds(10);
      digitalWrite(TRIG_PIN, LOW);
      long duration = pulseIn(ECHO_PIN, HIGH);
      float distance = duration * 0.0343 / 2;
      last_distance = distance;
    }
    vTaskDelay(10 / portTICK_PERIOD_MS);
  }
}

float readSonar() {
  return last_distance;
}

float getThreshold(int sensitivity, float min_val, float max_val) {
  return max_val - (sensitivity / 100.0f) * (max_val - min_val);
}

void ShowDistanceSensor() {
  vTaskResume(sonarTaskHandle);
  sonar_enable = 1;
  delay(10);
  while (1) {
    Serial.print("Sonar: ");
    Serial.print(readSonar());
    Serial.println();
    delay(10);
  }
}
void ShowDistanceSensorLCD() {
  lcdClear();
  vTaskResume(sonarTaskHandle);
  delay(10);
  while (1) {
    lcdPrintText(20,20,String(readSonar()) + "         ",0xffff);
  }
}

void write8(SoftI2C& wire, uint8_t reg, uint8_t value) {
  wire.beginTransmission(TCS34725_ADDRESS);
  wire.write(TCS34725_COMMAND_BIT | reg);
  wire.write(value);
  wire.endTransmission();
}

void write8(TwoWire& wire, uint8_t reg, uint8_t value) {
  wire.beginTransmission(TCS34725_ADDRESS);
  wire.write(TCS34725_COMMAND_BIT | reg);
  wire.write(value);
  wire.endTransmission();
}

uint16_t read16(SoftI2C& wire, uint8_t reg) {
  wire.beginTransmission(TCS34725_ADDRESS);
  wire.write(TCS34725_COMMAND_BIT | reg);
  wire.endTransmission();

  wire.requestFrom(TCS34725_ADDRESS, 2);
  uint16_t t = wire.read();
  t |= wire.read() << 8;
  return t;
}

uint16_t read16(TwoWire& wire, uint8_t reg) {
  wire.beginTransmission(TCS34725_ADDRESS);
  wire.write(TCS34725_COMMAND_BIT | reg);
  wire.endTransmission();

  wire.requestFrom(TCS34725_ADDRESS, 2);
  uint16_t t = wire.read();
  t |= wire.read() << 8;
  return t;
}

void initSensor(SoftI2C& wire) {
  write8(wire, 0x00, 0x01);
  delay(3);
  write8(wire, 0x00, 0x03);
  delay(3);
  write8(wire, 0x01, 0xD5);
}

void initSensor(TwoWire& wire) {
  write8(wire, 0x00, 0x01);
  delay(3);
  write8(wire, 0x00, 0x03);
  delay(3);
  write8(wire, 0x01, 0xD5);
}

void setupColorSensor() {
  SoftWire1.begin();
  Wire2.begin(4, 13);
  initSensor(SoftWire1);
  initSensor(Wire2);
}

void readRGB(SoftI2C& wire, int crgb[4]) {
  crgb[0] = read16(wire, 0x14);
  crgb[1] = read16(wire, 0x16);
  crgb[2] = read16(wire, 0x18);
  crgb[3] = read16(wire, 0x1A);
}

void readRGB(TwoWire& wire, int crgb[4]) {
  crgb[0] = read16(wire, 0x14);
  crgb[1] = read16(wire, 0x16);
  crgb[2] = read16(wire, 0x18);
  crgb[3] = read16(wire, 0x1A);
}

void setupSensor() {
  Wire2.begin(4, 13);
  initSensor(Wire2);
}

void calibrateCanColor() {
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  servoArmWrite(chanal_Gripper_Right, Open_Right);
  int clear_color_left_cal;
  int clear_color_right_cal;
  int crgb[4];
  lift(0);
  while (!Serial)
    ;

  Serial.println("นำกระป๋องสีเหลืองวางที่มือด้านซ้าย แล้วกดปุ่ม A หรือ B");
  tft.fillScreen(ST77XX_BLACK);
  lcdPrintText(0, 0, "Place 'Yellow Can' on Left Gripper, then Press A/B", 0xffff);
  while (!switchRead(A) && !switchRead(B))
    ;
  beep(50);
  servoArmWrite(chanal_Gripper_Left, Close_Left);
  tft.fillScreen(ST77XX_BLACK);
  lcdPrintText(0, 0, "Reading...", 0xffff);
  delay(500);
  readRGB(SoftWire1, crgb);
  clear_color_left_cal = crgb[0];
  servoArmWrite(chanal_Gripper_Left, Open_Left);

  Serial.println("นำกระป๋องสีเหลืองวางที่มือด้านขวา แล้วกดปุ่ม A หรือ B");
  tft.fillScreen(ST77XX_BLACK);
  lcdPrintText(0, 0, "Place 'Yellow Can' on Right Gripper, then Press A/B", 0xffff);
  while (!switchRead(A) && !switchRead(B))
    ;
  beep(50);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  tft.fillScreen(ST77XX_BLACK);
  lcdPrintText(0, 0, "Reading...", 0xffff);
  delay(500);
  readRGB(Wire2, crgb);
  clear_color_right_cal = crgb[0];
  servoArmWrite(chanal_Gripper_Right, Open_Right);

  Serial.printf("clear_color_left: %d\n", clear_color_left_cal);
  Serial.printf("clear_color_right: %d\n", clear_color_right_cal);
  tft.fillScreen(ST77XX_BLACK);
  lcdPrintText(0, 0, "Calibrated!", 0xffff);
  lcdPrintText(0, 20, "Left:  " + String(clear_color_left_cal), 0xffff);
  lcdPrintText(0, 30, "Right: " + String(clear_color_right_cal), 0xffff);
  lcdPrintText(0, 50, "Press A or B to return", 0xffff);
  beep(50);
  delay(50);
  beep(50);
  lift(3);
  while (!switchRead(A) && !switchRead(B))
    ;
}

char readColor(char gripper) {
  if (gripper == 'l') {
    int crgb[4];
    readRGB(SoftWire1, crgb);
    
    // เงื่อนไขที่ 1: เช็คจากค่า Clear ที่ Calibrate ไว้
    if (crgb[0] >= (clear_color_left - 500)) {
      tft.fillRect(0, 0, 80, 128, 0xffc0); // สีเหลือง
      return 'y';
    }
    else {
      if (crgb[1] > crgb[2]) { // ถ้าค่าสีแดง > สีเขียว (เป็นไปได้ทั้ง แดง และ เหลือง)
        
        // เงื่อนไขแก้ปัญหา: เช็คว่ามีสีเขียวผสมอยู่เยอะไหม (ถ้าเขียวมีค่ามากกว่า 50% ของแดง แปลว่าเป็นสีเหลือง)
        // หมายเหตุ: ตัวเลข 0.5 (50%) สามารถปรับเพิ่ม/ลดได้ตามค่าจริงที่เซนเซอร์อ่านได้
        if (crgb[2] > (crgb[1] * 0.5)) { 
          tft.fillRect(0, 0, 80, 128, 0xffc0); // วาดจอเป็นสีเหลือง
          return 'y'; 
        } else {
          tft.fillRect(0, 0, 80, 128, 0xf800); // วาดจอเป็นสีแดง
          return 'r';
        }
      }
      else if (crgb[2] > crgb[1]) {
        tft.fillRect(0, 0, 80, 128, 0x1d40); // วาดจอเป็นสีเขียว
        return 'g';
      }
      else {
        tft.fillRect(0, 0, 80, 128, 0x0000);
        return 'u'; // none
      }
    }
    
  } else if (gripper == 'r') {
    int crgb[4];
    readRGB(Wire2, crgb);
    
    // เงื่อนไขที่ 1: เช็คจากค่า Clear ที่ Calibrate ไว้
    if (crgb[0] >= (clear_color_right - 500)) {
      tft.fillRect(80, 0, 80, 128, 0xffc0); // สีเหลือง
      return 'y';
    }
    else {
      if (crgb[1] > crgb[2]) { // ถ้าค่าสีแดง > สีเขียว
        
        // เช็คสัดส่วนสีเขียวเทียบกับสีแดงสำหรับมือขวา
        if (crgb[2] > (crgb[1] * 0.5)) { 
          tft.fillRect(80, 0, 80, 128, 0xffc0); // วาดจอเป็นสีเหลือง
          return 'y';
        } else {
          tft.fillRect(80, 0, 80, 128, 0xf800); // วาดจอเป็นสีแดง
          return 'r';
        }
      }
      else if (crgb[2] > crgb[1]) {
        tft.fillRect(80, 0, 80, 128, 0x1d40); // วาดจอเป็นสีเขียว
        return 'g';
      }
      else {
        tft.fillRect(80, 0, 80, 128, 0x0000);
        return 'u';
      }
    }
  } else return 'u';
}

void STOP() {
  motorStop();
  while (!switchRead(A) && !switchRead(B)) {
    delay(500);
  }
  setAngleOffset();
  current_degree = 0;
}
