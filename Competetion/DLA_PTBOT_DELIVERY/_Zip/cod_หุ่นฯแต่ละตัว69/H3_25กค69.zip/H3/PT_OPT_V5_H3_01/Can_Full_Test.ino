/* -------------------------------------- FullMap -------------------------------------- */
void FullMap() {
}
/* -------------------------------------- MoveBlock -------------------------------------- */
void MoveBlock(int Speed, float numblock) {
  int first_block_time, next_block_time, total_time;
  if (Speed == 40) {
    int first_block_time = 670;
    int next_block_time = 473;
    int total_time = first_block_time + (next_block_time * (numblock - 1));
    FF(Speed, total_time);
  } else if (Speed == 80) {
    int first_block_time = 435;
    int next_block_time = 235;
    int total_time = first_block_time + (next_block_time * (numblock - 1));
    FF(Speed, total_time);
  } else if (Speed == 100) {
    int first_block_time = 390;
    int next_block_time = 195;
    int total_time = first_block_time + (next_block_time * (numblock - 1));
    FF(Speed, total_time);
  }
}
void MoveBlock(int Speed, float numblock, char select) {
  MoveBlock(Speed, numblock);
  delay(delayALL);
  if (select == 'L') {
    spinDegree(-90);
  } else if (select == 'R') {
    spinDegree(90);
  }
  delay(delayALL);
}
void BackBlock(int Speed, float numblock) {
  int first_block_time, next_block_time, total_time;
  if (Speed == 40) {
    int first_block_time = 670;
    int next_block_time = 473;
    int total_time = first_block_time + (next_block_time * (numblock - 1));
    BB(Speed, total_time);
  } else if (Speed == 80) {
    int first_block_time = 435;
    int next_block_time = 235;
    int total_time = first_block_time + (next_block_time * (numblock - 1));
    BB(Speed, total_time);
  } else if (Speed == 100) {
    int first_block_time = 390;
    int next_block_time = 195;
    int total_time = first_block_time + (next_block_time * (numblock - 1));
    BB(Speed, total_time);
  }
}
void BackBlock(int Speed, float numblock, char select) {
  BackBlock(Speed, numblock);
  delay(delayALL);
  if (select == 'L') {
    spinDegree(-90);
  } else if (select == 'R') {
    spinDegree(90);
  }
  delay(delayALL);
}
/* -------------------------------------- CanTest_4Box -------------------------------------- */
