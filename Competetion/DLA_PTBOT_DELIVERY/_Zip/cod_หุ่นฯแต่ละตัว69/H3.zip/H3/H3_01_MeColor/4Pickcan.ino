void pickcan(int pick_height,int WhatCan)
{
  if(autoplace==true){autoPickCan(pick_height);}
  else{
    if(WhatCan==1){PickManual(pick_height,CanL[0],CanR[0]); ShowColor(0); }
    else if(WhatCan==2){PickManual(pick_height,CanL[1],CanR[1]); ShowColor(1);}
    else if(WhatCan==3){PickManual(pick_height,CanL[2],CanR[2]); ShowColor(2);}
  }
  // setCanA();
}

void ShowColor(int number)
{
    if (CanL[number] =='y') {
      tft.fillRect(0, 0, 80, 128, 0xffc0);
    }
    else {
      if (CanL[number]=='r') {
        tft.fillRect(0, 0, 80, 128, 0xf800);
      }
      else if (CanL[number]=='g') {
        tft.fillRect(0, 0, 80, 128, 0x1d40);
      }
      else {
        tft.fillRect(0, 0, 80, 128, 0x0000);
      }
    }

    if (CanR[number] =='y') {
      tft.fillRect(80, 0, 80, 128, 0xffc0);
    }
    else {
      if (CanR[number]=='r') {
        tft.fillRect(80, 0, 80, 128, 0xf800);
      }
      else if (CanR[number]=='g') {
        tft.fillRect(80, 0, 80, 128, 0x1d40);
      }
      else {
        tft.fillRect(80, 0, 80, 128, 0x0000);
      }
    }

}
void PickManual(int pick_height,char CL,char CR) {
  servoArmWrite(chanal_Swing_Left, Swing_Left - 2);
  servoArmWrite(chanal_Swing_Right, Swing_Right - 2);
  servoArmWrite(chanal_Gripper_Left, Open_Left-15);
  servoArmWrite(chanal_Gripper_Right, Open_Right-15);
  lift(pick_height);
  if (pick_height != 0) moveToCan(pick_can_distance);
  else moveToCan0();
  delay(100);
  servoCloseLeft();
  servoCloseRight();
  delay(200);
  lift(pick_height + 3);
  delay(200);
  can_in_gripper[0] = CL;
  can_in_gripper[1] = CR; 
  delay(50);
  count_pick += 1;
  if (can_in_gripper[0] == can_in_gripper[1]) {
    if (count_pick == 3 && (can_in_gripper[0] == can_in_gripper[1])) {
      State_EndMission = true;
    }
    BB(30, 500);
    setCanA();
    // FF(30,200);
    if (can_in_gripper[0] == 'r') {
      if (can_in_stock[0] == 'u') {
        stockIn('l', can_in_gripper[0], true);
        can_in_gripper[0] = 'u';
        can_in_gripper[1] = 'r';
      } else if (can_in_stock[1] == 'u') {
        stockIn('r', can_in_gripper[0], true);
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'u';
      } else {
        while (1) {
          beep(10000);
        }
      }
    } else {
      if (can_in_gripper[0] == 'g') can_in_gripper[0] = 'l';
      else if (can_in_gripper[0] == 'y') can_in_gripper[0] = 'c';
      if (can_in_stock[1] == 'u') {
        stockIn('r', can_in_gripper[0], true);
        can_in_gripper[1] = 'u';
      } else if (can_in_stock[0] == 'u') {
        stockIn('l', can_in_gripper[0], true);
        can_in_gripper[1] = can_in_gripper[0];
        can_in_gripper[0] = 'u';
      } else {
        while (1) {
          beep(10000);
        }
      }
    }
    // BB(30, 250);
  } else {
    if (((hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'g')) || ((hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') && (can_in_gripper[0] == 'y' && can_in_gripper[1] == 'g')) || ((hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'y')) || ((hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') && (can_in_gripper[0] == 'g' && can_in_gripper[1] == 'y')) || ((hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') && (can_in_gripper[0] == 'y' && can_in_gripper[1] == 'r')) || ((hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') && (can_in_gripper[0] == 'g' && can_in_gripper[1] == 'r'))) {
      vTaskResume(switchGripperTaskHandle);
      delay(10);
      swingGripper('l', Swing_Left_center-3);
      delay(500);
      servoArmWrite(chanal_Gripper_Left, Close_Left - 15);
      delay(300);
      servoArmWrite(chanal_Gripper_Left, Open_Left-20);
      delay(400);
      BB(30, 400);
      switchGripper('r', 'l');
      delay(1400);
      servoArmWrite(chanal_Gripper_Right, Open_Right-20);
      swingGripper('r', Swing_Right_center+2);
      delay(200);
      moveToCan(pick_can_distance);
      lift(pick_height + 2);
      servoCloseRight();
      delay(200);
      vTaskSuspend(switchGripperTaskHandle);
      servoArmWrite(chanal_Swing_Left, Swing_Left);
      servoArmWrite(chanal_Swing_Right, Swing_Right);
      delay(300);
      lift(pick_height + 3);
      delay(200);
      if (hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') {
        can_in_gripper[0] = 'l';
        can_in_gripper[1] = 'r';
      }
      if (hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') {
        can_in_gripper[0] = 'l';
        can_in_gripper[1] = 'c';
      }
      if (hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') {
        can_in_gripper[0] = 'c';
        can_in_gripper[1] = 'r';
      }
      if (hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') {
        can_in_gripper[0] = 'c';
        can_in_gripper[1] = 'l';
      }
      if (hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') {
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'c';
      }
      if (hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') {
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'l';
      }
      delay(200);
      BB(30, 480);//400
      setCanA();
      lift(3);
    } else {
      if (can_in_gripper[0] == 'r') can_in_gripper[0] = 'r';
      else if (can_in_gripper[0] == 'g') can_in_gripper[0] = 'l';
      else if (can_in_gripper[0] == 'y') can_in_gripper[0] = 'c';
      if (can_in_gripper[1] == 'r') can_in_gripper[1] = 'r';
      else if (can_in_gripper[1] == 'g') can_in_gripper[1] = 'l';
      else if (can_in_gripper[1] == 'y') can_in_gripper[1] = 'c';
      BB(30, 480);//400
      setCanA();
      lift(3);
    }
  }
  lift(3);
  delay(200);
  BB(30, BackwardDlay);
  delay(200);
}