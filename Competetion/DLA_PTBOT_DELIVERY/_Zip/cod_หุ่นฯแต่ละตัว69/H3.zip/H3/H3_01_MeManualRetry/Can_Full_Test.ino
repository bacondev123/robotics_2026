/* -------------------------------------- FullMap -------------------------------------- */
void FullMap() {
  Block1_1();Block1_2();
  Block2_1();Block2_2();

  Block3_1();Block3_2();

  EndMission();
}
void Retry1()
{
  count_pick=1;
  setStandPlace('r', 'y', 'g'); // left - center - red
  KA();
  SetBack(25,250);
  MoveBlock40(2.05,'R');
  BackBlock40(0.9,'l');
  SetBack(25,200);
  SetBack(25,270,'R');

  BackBlock40(0.8);
  SetBack(25,250,'L');
  pickcan(0,2);

  Block2_2();
  Block3_1();Block3_2();
}
void Retry2()
{
  setStandPlace('g', 'y', 'r'); // left - center - red
  count_pick=2;
  KA();
  SetBack(25,250);
  MoveBlock40(1,'L');
  SetBack(25,250,'L');
  BackBlock40(1.8);
  
  SetBack(25,250,'L');
  pickcan(5,3);
  Block3_2();
}
/* -------------------------------------- MoveBlock -------------------------------------- */
void MoveBlock(int Speed, float numblock) {
  int first_block_time, next_block_time, total_time;
  if (Speed == 40) {
    int first_block_time = 670;
    int next_block_time = 473;
    int total_time = first_block_time + (next_block_time * (numblock - 1));
    FF(Speed, total_time);
  } else if (Speed == 80) {
    int first_block_time = 435;
    int next_block_time = 235;
    int total_time = first_block_time + (next_block_time * (numblock - 1));
    FF(Speed, total_time);
  } else if (Speed == 100) {
    int first_block_time = 390;
    int next_block_time = 195;
    int total_time = first_block_time + (next_block_time * (numblock - 1));
    FF(Speed, total_time);
  }
}
void MoveBlock(int Speed, float numblock, char select) {
  MoveBlock(Speed, numblock);
  delay(delayALL);
  if (select == 'L') {
    spinDegree(-90);
  } else if (select == 'R') {
    spinDegree(90);
  }
  delay(delayALL);
}
void BackBlock(int Speed, float numblock) {
  int first_block_time, next_block_time, total_time;
  if (Speed == 40) {
    int first_block_time = 670;
    int next_block_time = 473;
    int total_time = first_block_time + (next_block_time * (numblock - 1));
    BB(Speed, total_time);
  } else if (Speed == 80) {
    int first_block_time = 435;
    int next_block_time = 235;
    int total_time = first_block_time + (next_block_time * (numblock - 1));
    BB(Speed, total_time);
  } else if (Speed == 100) {
    int first_block_time = 390;
    int next_block_time = 195;
    int total_time = first_block_time + (next_block_time * (numblock - 1));
    BB(Speed, total_time);
  }
}
void BackBlock(int Speed, float numblock, char select) {
  BackBlock(Speed, numblock);
  delay(delayALL);
  if (select == 'L') {
    spinDegree(-90);
  } else if (select == 'R') {
    spinDegree(90);
  }
  delay(delayALL);
}
/* -------------------------------------- CanTest_4Box -------------------------------------- */
