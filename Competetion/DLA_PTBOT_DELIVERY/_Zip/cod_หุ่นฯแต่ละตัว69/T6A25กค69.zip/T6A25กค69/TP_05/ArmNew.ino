void DropCan(int drop_height, char gripper, char drop_point) {
  int delay_time = 250 + (drop_height * 25);
  if (delay_time < 0) delay_time = 0;
  lift(drop_height + 2);
  delay(delay_time);
  switch (gripper) {
    case 'L':
      switch (drop_point) {
        case 'L':
          swingGripper('l', Swing_Left + 10);
          swingGripper('r', Swing_Right + 60);
          break;
        case 'C':
          swingGripper('l', Swing_Left - 20);
          swingGripper('r', Swing_Right + 60);
          break;
        case 'A':
          servoWrite(chanal_Swing_Left, Swing_Left);
          servoWrite(chanal_Swing_Right, Swing_Right + 60);
          break;
      }
      break;

    case 'R':
      switch (drop_point) {
        case 'R':
          swingGripper('l', Swing_Left + 60);
          swingGripper('r', Swing_Right + 10);
          break;
        case 'C':
          swingGripper('l', Swing_Left + 60);
          swingGripper('r', Swing_Right - 20);
          break;
        case 'A':
          servoWrite(chanal_Swing_Left, Swing_Left + 60);
          servoWrite(chanal_Swing_Right, Swing_Right);
          break;
      }
      break;

    case 'A':
      switch (drop_point) {
        case 'A':
          BalanceArm('S');
          break;
      }
      break;
  }

  // FFOBJ(Speed_MID / 2, drop_height);
  // Lift(drop_height);
  // vTaskDelay(Delay_LOW / portTICK_PERIOD_MS);
  // DropPosition(gripper);
  // vTaskDelay(Default_Delay / portTICK_PERIOD_MS);
  // BB(Speed_MID, Time_Withdraw);
  // BalanceArm('S');
  // Lift(Default_Lift);
  // vTaskDelay(delay_time / portTICK_PERIOD_MS);
  // BB(BB_speed, BB_delay);
}
