#include <PTBOTAtomVX.h>  // เรียกใช้งาน Library
#include <ESP32Encoder.h>

#define NO_SWITCH_LR 0
#define SWITCH_LR 1

TwoWire Wire2 = TwoWire(1);
Adafruit_PWMServoDriver servo_arm = Adafruit_PWMServoDriver(0x41, Wire2);

//                    S0   S1   S2   S3
int sensor_min[] = { 150, 120, 50, 50};    // ค่าสีดำ
int sensor_max[] = { 780, 600, 340, 380};  // ค่าสีขาว
float power_factor = 1.0;

int line_value[] = { 0, 0, 0, 0, 0, 0, 0, 0 };
int current_degree = 0;
float previous_error_forward = 0;
byte servo_pin[] = { 6, 5, 4, 0, 1, 2, 3 };

long delayALL = 150;

TaskHandle_t sonarTaskHandle = NULL;
TaskHandle_t switchGripperTaskHandle = NULL;

int BackwardDlay = 525;          // ระยะถอยออกมาหลังจากจับกระป๋องเสร็จ
int BackwardDlayPlace = 350;     // ระยะถอยออกมาหลังจากวางกระป๋องเสร็จ
float place_can_distance = 7.5;  // ระยะจอดหน้าแท่นวาง
float pick_can_distance = 5.0;   // ระยะจอดหน้าแท่นจับ
float pick_can_floor = 13.5;     // ระยะจอดหน้าแท่นจับที่พื้น

// มอเตอร์ ต่อ 1 ซ้าย 2 ขวา
// เซ็นเซอร์ ซ้ายหน้า = 0 ขวา หน้า 1
// เซ้็นเซอร์ หลัง ขวา 2 - ซ้ายสุด 5
void setup() {
  initialize();          // เริ่มต้นการทำงานบอร์ด
  Serial.begin(115200);  // เริ่มต้นใช้งาน Serial
  // สร้างงาน Muti-Tasking
  xTaskCreatePinnedToCore(liftLoop, "liftLoop", 2048, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(sonarLoop, "sonarLoop", 2048, NULL, 1, &sonarTaskHandle, 1);
  xTaskCreatePinnedToCore(switchGripperLoop, "switchGripperLoop", 2048, NULL, 1, &switchGripperTaskHandle, 1);
  vTaskSuspend(sonarTaskHandle);
  vTaskSuspend(switchGripperTaskHandle);
  setupDistanceSensor();
  setupServo();
  // Lift M3
  // lift(3);  // ยกแขน 3 จากจุดเดิม *ก่อนเปิดหุ่นต้องกดลงให้สุดก่อน ** สำคัญต้องปรับก่อน
  /////////////////////// เปิดอ่านค่าเซนเซอร์ ////////////////////////////////
  // ShowValue_Sensor(); // จับเส้น
  // ShowDistanceSensor(); // ระยะทาง
}

void loop() {
  STOP();

// placeCanTwo(5, 's', 's');
  // SetBack(20, 275, 'L');
  // pickCan(5, NO_SWITCH_LR);
  // SetBack(20, 275, 'R');
  // FF(40, 600);
  // SetFront(20, 350, 'L');
  // placeCanTwo(5, 's', 's');

  // STOP();
  // placeCanOne(5, 'l', 's');

  // STOP();
  // placeCanOne(5, 'r', 's');
}
