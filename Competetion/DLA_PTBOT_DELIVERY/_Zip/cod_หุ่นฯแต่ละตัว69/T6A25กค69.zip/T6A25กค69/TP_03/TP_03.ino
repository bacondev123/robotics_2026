#include <PTBOTAtomVX.h>  // เรียกใช้งาน Library
#include <ESP32Encoder.h>

#define NO_SWITCH_LR 0
#define SWITCH_LR 1

TwoWire Wire2 = TwoWire(1);
Adafruit_PWMServoDriver servo_arm = Adafruit_PWMServoDriver(0x41, Wire2);

//                    S0   S1   S2   S3   S4   S5
int sensor_min[] = { 150, 120, 40, 40, 0, 0 };  // ค่าสีดำ
int sensor_max[] = { 775, 550, 340, 370, 0, 0 };  // ค่าสีขาว
float power_factor = 1.0;

int line_value[] = { 0, 0, 0, 0, 0, 0, 0, 0 };
int current_degree = 0;
float previous_error_forward = 0;
byte servo_pin[] = { 6, 5, 4, 0, 1, 2, 3 };

long delayALL = 150;

TaskHandle_t sonarTaskHandle = NULL;
TaskHandle_t switchGripperTaskHandle = NULL;

int BackwardDlay = 525;       // ระยะถอยออกมาหลังจากจับกระป๋องเสร็จ
int BackwardDlayPlace = 350;  // ระยะถอยออกมาหลังจากวางกระป๋องเสร็จ
float place_can_distance = 7.5;  // ระยะจอดหน้าแท่นวาง
float pick_can_distance = 8.0;   // ระยะจอดหน้าแท่นจับ
float pick_can_floor = 13.5;     // ระยะจอดหน้าแท่นจับที่พื้น

// มอเตอร์ ต่อ 1 ซ้าย 2 ขวา
//เซ็นเซอร์ ซ้ายหน้า = 0 ขวา หน้า 1
//เซ้็นเซอร์ หลัง ขวา 2-ซ้ายสุด 5
void setup() {
  initialize();          // เริ่มต้นการทำงานบอร์ด Atom VX  จะแสดง รูป PT
  Serial.begin(115200);  // เริ่มต้นใช้งาน Serial
  // สร้างงาน Muti-Tasking (ทำพร้อมกัน)
  xTaskCreatePinnedToCore(liftLoop, "liftLoop", 2048, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(sonarLoop, "sonarLoop", 2048, NULL, 1, &sonarTaskHandle, 1);
  xTaskCreatePinnedToCore(switchGripperLoop, "switchGripperLoop", 2048, NULL, 1, &switchGripperTaskHandle, 1);
  vTaskSuspend(sonarTaskHandle);
  vTaskSuspend(switchGripperTaskHandle);
  setupDistanceSensor();
  setupServo();
  // SetServo_New();
  //Lift M3
  // lift(3);  // ยกแขน 3 จากจุดเดิม *ก่อนเปิดหุ่นต้องกดลงให้สุดก่อน ** สำคัญต้องปรับก่อน
  ///////////////////////เปิดอ่าค่า เซนเซอร์ ////////////////////////////////
  // ShowValue_Sensor(); // โชว์ค่าเซ็นเซอร์ตรวจจับเส้น
  // ShowDistanceSensor(); // โชว์ค่าเซ็นเซอร์วัดระยะทาง
  //////////////////////////////////////////////////////////
}

void loop() {
  STOP();
  // SetBack(20);
  SetFront(20, 300, 'L');
  // // lift(2000); delay(1500); lift(0);
  // STOP();  //สั่งหยุด กด SW1 or SW2 เพื่อทำงานต่อ
  // setAngleOffset(); // เช็ตตั้งค่า servo 
  // current_degree = 0;

  // /////////////////////////
  // // Start(); //--->>> เริ่มทำจริง
  // Box1(); //--->>> ซ้อม
  // // Box2(); //--->>> ซ้อม2
  // // Test_Function(); //--->>> เทสฟังชั่นต่างๆ
  // // ServoTest_LR(5);
}
