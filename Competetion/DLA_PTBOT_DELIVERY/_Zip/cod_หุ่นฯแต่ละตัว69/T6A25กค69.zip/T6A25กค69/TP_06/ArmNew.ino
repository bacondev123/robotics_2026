int Default_lift = 3;

void pickCan(int pick_height) {
  BalanceArm('O');
  lift(pick_height);
  if (pick_height != 0) moveToCan(pick_can_distance);
  else moveToCan0(pick_can_floor);
  servoWrite(chanal_Gripper_Left, Close_Left);
  servoWrite(chanal_Gripper_Right, Close_Right);
  delay(250);
  lift(pick_height + 3);
  delay(250);
  BB(30, 500);
  lift(Default_lift);
  servoWrite(chanal_Swing_Left, Swing_Left);
  servoWrite(chanal_Swing_Right, Swing_Right);
  StableOBJ();
}

void placeCan(int drop_height, char gripper, char drop_point) {
  int delay_time = 250 + (drop_height * 25);
  if (delay_time < 0) delay_time = 0;
  lift(drop_height + 2);
  delay(delay_time);
  switch (gripper) {
    case 'L':
      switch (drop_point) {
        case 'L':
          swingGripper('l', Swing_Left + 10);
          swingGripper('r', Swing_Right + 60);
          break;
        case 'C':
          swingGripper('l', Swing_Left - 20);
          swingGripper('r', Swing_Right + 60);
          break;
        case 'S':
          servoWrite(chanal_Swing_Left, Swing_Left);
          servoWrite(chanal_Swing_Right, Swing_Right + 60);
          break;
      }
      break;

    case 'R':
      switch (drop_point) {
        case 'R':
          swingGripper('l', Swing_Left + 60);
          swingGripper('r', Swing_Right + 10);
          break;
        case 'C':
          swingGripper('l', Swing_Left + 60);
          swingGripper('r', Swing_Right - 20);
          break;
        case 'S':
          servoWrite(chanal_Swing_Left, Swing_Left + 60);
          servoWrite(chanal_Swing_Right, Swing_Right);
          break;
      }
      break;

    case 'A':
      switch (drop_point) {
        case 'A':
          BalanceArm('S');
          break;
      }
      break;
  }

  moveToCan(place_can_distance);
  lift(drop_height);
  delay(500);
  DropPosition(gripper);
  delay(250);
  BB(30, 500);
  BalanceArm('S');
  lift(Default_lift);
}

void BalanceArm(char position) {
  switch (position) {
    case 'C':
      servoWrite(chanal_Gripper_Left, Close_Left);
      servoWrite(chanal_Gripper_Right, Close_Right);
      servoWrite(chanal_Swing_Left, Swing_Left - 15);
      servoWrite(chanal_Swing_Right, Swing_Right - 15);
      break;

    case 'O':
      servoWrite(chanal_Swing_Left, Swing_Left);
      servoWrite(chanal_Swing_Right, Swing_Right);
      servoWrite(chanal_Gripper_Left, Open_Left);
      servoWrite(chanal_Gripper_Right, Open_Right);
      break;

    case 'L':
      servoWrite(chanal_Gripper_Left, Close_Left);
      servoWrite(chanal_Gripper_Right, Close_Right);
      servoWrite(chanal_Swing_Left, Swing_Left + 100);
      servoWrite(chanal_Swing_Right, Swing_Right - 30);
      break;

    case 'R':
      servoWrite(chanal_Gripper_Left, Close_Left);
      servoWrite(chanal_Gripper_Right, Close_Right);
      servoWrite(chanal_Swing_Right, Swing_Right + 100);
      servoWrite(chanal_Swing_Left, Swing_Left - 30);
      break;

    case 'S':
      servoWrite(chanal_Swing_Left, Swing_Left);
      servoWrite(chanal_Swing_Right, Swing_Right);
      break;

    case 'W':
      servoWrite(chanal_Gripper_Left, Close_Left);
      servoWrite(chanal_Gripper_Right, Close_Right);
      servoWrite(chanal_Swing_Left, Swing_Left + 100);
      servoWrite(chanal_Swing_Right, Swing_Right + 100);
      break;
  }
  delay(250);
}

void DropPosition(char gripper) {
  switch (gripper) {
    case 'L':
      servoWrite(chanal_Gripper_Left, Close_Left - 10);
      delay(250);
      servoWrite(chanal_Gripper_Left, Open_Left);
      break;

    case 'R':
      servoWrite(chanal_Gripper_Right, Close_Right - 10);
      delay(250);
      servoWrite(chanal_Gripper_Right, Open_Right);
      break;

    case 'A':
      servoWrite(chanal_Gripper_Left, Close_Left - 10);
      servoWrite(chanal_Gripper_Right, Close_Right - 10);
      delay(250);
      servoWrite(chanal_Gripper_Left, Open_Left);
      servoWrite(chanal_Gripper_Right, Open_Right);
      break;
  }
  delay(500);
}

void StableOBJ() {
  BalanceArm('S');
  lift(0);
  BB(10, 500);
  delay(250);
  servoWrite(chanal_Gripper_Left, Close_Left - 15);
  servoWrite(chanal_Gripper_Right, Close_Right - 15);
  delay(250);
  FF(10, 500);
  servoWrite(chanal_Gripper_Left, Close_Left);
  servoWrite(chanal_Gripper_Right, Close_Right);
  delay(125);
  lift(Default_lift);
  delay(125);
}

void spinDegree(int relative_degree) {
  delay(125);
  unsigned long timer_turn = millis();
  int min_speed = 20;
  int max_speed = 100;
  float kp = 1.0;
  float kd = 1.0;
  float small_angle_threshold = 30.0;
  float stop_threshold = 2.0;
  float target_degree = current_degree + relative_degree;
  while (target_degree > 180)  target_degree -= 360;
  while (target_degree < -180) target_degree += 360;
  float previous_error = 0;

  while (1) {
    float current_angle = angleRead(YAW);
    float error = target_degree - current_angle;
    if (error > 180)       error -= 360;
    else if (error < -180) error += 360;
    
    if (abs(error) <= stop_threshold) {
      motorStop();
      if (millis() - timer_turn >= 80) {
        break;
      }
    } 
    else if (error > 0 && error < small_angle_threshold) {
      motorWrite(1, min_speed);
      motorWrite(2, -min_speed);
      timer_turn = millis();
    } 
    else if (error < 0 && error > -small_angle_threshold) {
      motorWrite(1, -min_speed);
      motorWrite(2, min_speed);
      timer_turn = millis();
    } 
    else {
      float derivative = error - previous_error;
      if (derivative > 180)       derivative -= 360;
      else if (derivative < -180) derivative += 360;

      int pd_value = round((error * kp) + (derivative * kd));
      if (error > 0) {
        if (pd_value < min_speed) pd_value = min_speed;
        if (pd_value > max_speed) pd_value = max_speed;
      } else {
        if (pd_value > -min_speed) pd_value = -min_speed;
        if (pd_value < -max_speed) pd_value = -max_speed;
      }
      motorWrite(1, pd_value);
      motorWrite(2, -pd_value);
      timer_turn = millis();
    }
    previous_error = error;
  }
  motorStop();
  current_degree = angleRead(YAW);
  delay(125);
}