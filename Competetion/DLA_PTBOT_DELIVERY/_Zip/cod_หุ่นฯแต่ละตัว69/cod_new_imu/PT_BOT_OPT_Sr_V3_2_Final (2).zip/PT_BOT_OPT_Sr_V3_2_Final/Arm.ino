#define chanal_Swing_Left 1
#define chanal_Swing_Right 2
#define chanal_Gripper_Left 0
#define chanal_Gripper_Right 3
#define chanal_Stock_Tray_Left 4
#define chanal_Stock_Tray_Right 5

///////////////////// ASSEMBLYMODE /////////////////////
int Swing_Left = 56; //S0 สวิงแขนซ้าย เพิ่มง้างออก ลด หุบเข้า
int Swing_Right = 60; //S1 สวิงแขนขวา เพิ่มง้างออก ลด หุบเข้า
////////////////////////////////////////////////////////
int Open_Left = 56; //S2 อ้ามือ ชุดมือจับมือซ้ายค่ามากยิ่งหุบ
int Close_Left = 95; //S2 หุบมือ ชุดมือจับมือซ้ายค่าน้อยยิ่งอ้า
////////////////////////////////////////////////////////
int Open_Right = 59; //S3 อ้ามือ ชุดมือจับมือขวา ค่ามากยิ่งหุบ
int Close_Right = 101; //S3 หุบมือ ชุดมือจับมือขวา ค่าน้อยยิ่งอ้า
////////////////////////////////////////////////////////
int Tray_In_Left = 120; // S4 เก็บถาดด้านซ้ายเข้า ค่ามากยิ่งเข้า
int Tray_Out_Left = 36; // S4 เอาถาดด้านซ้ายออก ค่าน้อยยิ่งออก
int Tray_In_Right = 63; // S5 เก็บถาดด้านขวาเข้า ค่าน้อยยิ่งเข้า
int Tray_Out_Right = 156; // S5 เอาถาดด้านขวาออก ค่ามากยิ่งออก
////////////////////////////////////////////////////////
int Stock_Left = 155; // S0 สวิงแขนเก็บกระป๋องซ้าย เพิ่มง้างออก ลด หุบเข้า
int Stock_Right = 156; // S1 สวิงแขนเก็บกระป๋องขวา เพิ่มง้างออก ลด หุบเข้า
////////////////////////////////////////////////////////
//////////////// ASSEMBLYMODE SWITCH CAN ///////////////
int swing_switch_can_left = 33; //S0 หุบแขนเข้าเพื่อสลับกระป๋อง แขนซ้าย ค่าน้อยยิ่งหุบเข้า
int swing_switch_can_right = 27; //S1 หุบแขนเข้าเพื่อสลับกระป๋อง แขนขวา ค่าน้อยยิ่งหุบเข้า
////////////////////////////////////////////////////////
//////////////// ASSEMBLYMODE PLACE CAN ////////////////
int Swing_Left_side = 66; //S0 สวิงแขนซ้าย วางป๋องซ้าย เพิ่มง้างออก ลด หุบเข้า
int Swing_Left_center = 34; //S0 สวิงแขนซ้าย วางป๋องกลาง เพิ่มง้างออก ลด หุบเข้า
int Swing_Right_side = 67; //S1 สวิงแขนขวา วางป๋องขวา เพิ่มง้างออก ลด หุบเข้า
int Swing_Right_center = 28; //S1 สวิงแขนขวา วางป๋องกลาง เพิ่มง้างออก ลด หุบเข้า
////////////////////////////////////////////////////////
/////////////////////// Air Drop ///////////////////////
int Open_Drop_Left = 10;   //S2 มือซ้าย อ้ามือเล็กน้อยเพื่อวางป๋องให้ลงหลุม ค่ามากยิ่งอ้า
int Open_Drop_Right = 8;  //S3 มือขวา อ้ามือเล็กน้อยเพื่อวางป๋องให้ลงหลุม ค่ามากยิ่งอ้า
////////////////////////////////////////////////////////

int swingL_IN = 8; // S0 ค่าตั้งการ์ดแขนซ้าย
int swingR_IN = 8; // S1 ค่าตั้งการ์ดแขนขวา

int lift_Sensitivity = 28; // ตัวคูนลิฟท์

int switch_degree = 22;
int switch_flag = 0;
int stock_flag = 0;
int lift_target = 0;
int swing_current_degree[] = { 0, 0 };
char can_in_gripper[2] = { 'u', 'u' };
char can_in_stock[2] = { 'u', 'u' };
char station[3][3] = {
  { 'u', 'u', 'u' },
  { 'u', 'u', 'u' },
  { 'u', 'u', 'u' }
};
int station_count = 0, count_pick = 0;

char hold[3] = { 'g', 'y', 'r' };
bool station_backward = true, State_EndMission = false, state_stock = false;

ESP32Encoder encoder;
Adafruit_PWMServoDriver servo_arm = Adafruit_PWMServoDriver(0x41, Wire2);

void servoArmWrite(byte channel, byte degree) {
  if (channel <= 4) {
    byte servo_pin[] = { 12, 13, 14, 15 };
    if (degree < 0)
      degree = 0;
    else if (degree > 180)
      degree = 180;
    servo_arm.setPWM(servo_pin[channel], 0, map(degree, 0, 180, 111, 492));
  }
}

void measureRobot() {
  setupServo();
  lift(7);
  delay(700);
  servoArmWrite(chanal_Swing_Left, Stock_Left + 15);
  servoArmWrite(chanal_Swing_Right, Stock_Right + 15);
  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
}

void setupServo() {
  servo_arm.begin();
  servo_arm.setOscillatorFrequency(27000000);
  servo_arm.setPWMFreq(50);
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  servoArmWrite(chanal_Gripper_Right, Open_Right);
  servoWrite(chanal_Stock_Tray_Left, Tray_In_Left);
  servoWrite(chanal_Stock_Tray_Right, Tray_In_Right);
}

void retractArmIN() {
  servoArmWrite(chanal_Gripper_Left, Close_Left + 2);
  servoArmWrite(chanal_Gripper_Right, Close_Right + 2);
  servoArmWrite(chanal_Swing_Left, Swing_Left_center - 5);
  servoArmWrite(chanal_Swing_Right, Swing_Right_center - 5);
}

void retractArmIN_Setup() {
  servoArmWrite(chanal_Gripper_Left, Close_Left + 2);
  servoArmWrite(chanal_Gripper_Right, Close_Right + 2);
  servoArmWrite(chanal_Swing_Left, Swing_Left_center - 5);
  servoArmWrite(chanal_Swing_Right, Swing_Right_center - 5);
  delay(200);
  lift(2);
}

void retractArmIN_Can() {
  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  servoArmWrite(chanal_Swing_Left, swing_switch_can_left + swingL_IN);
  servoArmWrite(chanal_Swing_Right, swing_switch_can_right + swingR_IN);
}

void servoOpenLeft() {
  for (int i = Close_Left; i > Open_Left; i--) {
    servoArmWrite(chanal_Gripper_Left, i);
    delay(5);
  }
}

void servoCloseLeft() {
  servoArmWrite(chanal_Gripper_Left, Close_Left);
}

void servoOpenRight() {
  for (int i = Close_Right; i > Open_Right; i--) {
    servoArmWrite(chanal_Gripper_Right, i);
    delay(5);
  }
}

void servoCloseRight() {
  servoArmWrite(chanal_Gripper_Right, Close_Right);
}

void servoClose(int close_degree) {
  servoArmWrite(chanal_Gripper_Left, Close_Left + close_degree);
  servoArmWrite(chanal_Gripper_Right, Close_Right + close_degree);
}

void extendArm() {
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoOpenRight();
  servoOpenLeft() ;
}

void retractArm() {
  swingGripper('l', Swing_Left + 65);
  swingGripper('r', Swing_Right + 65);
}

void assemblyMode() {
  lift(10);
  int swing_left = 60;
  int swing_right = 60;
  int open_left = 80;
  int close_left = open_left + 30;
  int open_right = 80;
  int close_right = open_right + 30;
  int tray_in_left = 100;
  int tray_in_right = 100;
  int tray_out_left = tray_in_left - 70;
  int tray_out_right = tray_in_right + 70;
  int stock_left = swing_left + 90;
  int stock_right = swing_right + 90;
  unsigned long timer_servo = 0;
  servoArmWrite(chanal_Swing_Left, swing_left);
  servoArmWrite(chanal_Swing_Right, swing_right);
  servoArmWrite(chanal_Gripper_Left, open_left);
  servoArmWrite(chanal_Gripper_Right, open_right);
  servoWrite(chanal_Stock_Tray_Left, tray_in_left);
  servoWrite(chanal_Stock_Tray_Right, tray_in_right);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(2, 55, "ASSEMBLY MODE", 0xf800);
  Serial.println("โหมดตั้งค่าเซอร์โวปกติ");
  Serial.println("กดสวิตซ์ A และ B พร้อมกัน เพื่อเริ่มตั้งค่าเซอร์โว");
  while (!switchRead(A) || !switchRead(B)) {};
  beep(50);
  while (switchRead(A) || switchRead(B)) {};
  Serial.println("หาค่า Swing Left");
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      swing_left += 1;
      beep(20);
    } else if (switchRead(B)) {
      swing_left -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, swing_left);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Swing Right");
  swing_right = swing_left;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      swing_right -= 1;
      beep(20);
    } else if (switchRead(B)) {
      swing_right += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, swing_right);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Close Left");
  timer_servo = millis();
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      close_left -= 1;
      beep(20);
    } else if (switchRead(B)) {
      close_left += 1;
      beep(20);
    }
    if (millis() - timer_servo <= 1000) servoArmWrite(chanal_Gripper_Left, close_left);
    else if (millis() - timer_servo > 1000 && millis() - timer_servo <= 2000) servoArmWrite(chanal_Gripper_Left, close_left - 15);
    else timer_servo = millis();
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Close Right");
  timer_servo = millis();
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      close_right -= 1;
      beep(20);
    } else if (switchRead(B)) {
      close_right += 1;
      beep(20);
    }
    if (millis() - timer_servo <= 1000) servoArmWrite(chanal_Gripper_Right, close_right);
    else if (millis() - timer_servo > 1000 && millis() - timer_servo <= 2000) servoArmWrite(chanal_Gripper_Right, close_right - 15);
    else timer_servo = millis();
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Open Left");
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      open_left -= 1;
      beep(20);
    } else if (switchRead(B)) {
      open_left += 1;
      beep(20);
    }
    servoArmWrite(chanal_Gripper_Left, open_left);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Open Right");
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      open_right -= 1;
      beep(20);
    } else if (switchRead(B)) {
      open_right += 1;
      beep(20);
    }
    servoArmWrite(chanal_Gripper_Right, open_right);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Tray In Left");
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      tray_in_left -= 2;
      beep(20);
    } else if (switchRead(B)) {
      tray_in_left += 2;
      beep(20);
    }
    servoWrite(chanal_Stock_Tray_Left, tray_in_left);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Tray In Right");
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      tray_in_right -= 2;
      beep(20);
    } else if (switchRead(B)) {
      tray_in_right += 2;
      beep(20);
    }
    servoWrite(chanal_Stock_Tray_Right, tray_in_right);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Tray Out Left");
  tray_out_left = tray_in_left - 70;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      tray_out_left -= 2;
      beep(20);
    } else if (switchRead(B)) {
      tray_out_left += 2;
      beep(20);
    }
    servoWrite(chanal_Stock_Tray_Left, tray_out_left);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Tray Out Right");
  tray_out_right = tray_in_right + 70;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      tray_out_right -= 2;
      beep(20);
    } else if (switchRead(B)) {
      tray_out_right += 2;
      beep(20);
    }
    servoWrite(chanal_Stock_Tray_Right, tray_out_right);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Stock Left");
  stock_left = swing_left + 90;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      stock_left -= 1;
      beep(20);
    } else if (switchRead(B)) {
      stock_left += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, stock_left);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่า Stock Right");
  stock_right = swing_right + 90;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      stock_right += 1;
      beep(20);
    } else if (switchRead(B)) {
      stock_right -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, stock_right);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Swing_Left = swing_left;
  Swing_Right = swing_right;
  Open_Left = open_left;
  Close_Left = close_left;
  Open_Right = open_right;
  Close_Right = close_right;
  Tray_In_Left = tray_in_left;
  Tray_Out_Left = tray_out_left;
  Tray_In_Right = tray_in_right;
  Tray_Out_Right = tray_out_right;
  Stock_Left = stock_left;
  Stock_Right = stock_right;
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  servoArmWrite(chanal_Gripper_Right, Open_Right);
  servoWrite(chanal_Stock_Tray_Left, Tray_In_Left);
  servoWrite(chanal_Stock_Tray_Right, Tray_In_Right);
  delay(1000);
  lift(3);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(31, 55, "COMPLETE", 0x07E0);
  beep(50);
  delay(50);
  beep(50);
  delay(1000);

  lift(0);
  int switch_can_left = Swing_Left - 30;
  int switch_can_right = Swing_Right + 20;
  timer_servo = 0;
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  servoArmWrite(chanal_Gripper_Right, Open_Right);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(2, 35, "ASSEMBLY MODE", 0xf800);
  lcdPrintText(2, 65, " SWITCH CAN  ", 0xf800);
  Serial.println();
  Serial.println("โหมดตั้งค่าเซอร์โว สลับกระป๋อง");
  Serial.println("นำกระป๋องใส่มือซ้าย แล้วกดสวิตซ์ A และ B พร้อมกัน");

  delay(200);
  while (!switchRead(A) || !switchRead(B)) {};
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoArmWrite(chanal_Gripper_Left, Close_Left);
  delay(200);
  lift(3);
  servoArmWrite(chanal_Swing_Left, switch_can_left);
  servoArmWrite(chanal_Swing_Right, switch_can_right);
  Serial.println("หาค่า swing switch can left ตั้งค่าแขนซ้าย หรือให้กระป๋องอยู่ตรงกลางเสาลิฟท์");
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      switch_can_left += 1;
      beep(20);
    } else if (switchRead(B)) {
      switch_can_left -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, switch_can_left);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  switch_can_right = Swing_Right - 30;
  servoArmWrite(chanal_Swing_Left, Swing_Left + 40);
  delay(500);
  servoArmWrite(chanal_Swing_Right, switch_can_right);
  delay(500);
  servoArmWrite(chanal_Swing_Left, switch_can_left);
  delay(500);
  Serial.println("หาค่า swing switch can right ตั้งค่าแขนขวาเข้าหากระป๋อง");
  beep(50);
  delay(50);
  beep(50);
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      switch_can_right -= 1;
      beep(20);
    } else if (switchRead(B)) {
      switch_can_right += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, switch_can_right);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoCloseRight();
  delay(200);
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(31, 55, "COMPLETE", 0x07E0);
  beep(50);
  delay(50);
  beep(50);
  delay(1000);

  swing_switch_can_left = switch_can_left;
  swing_switch_can_right = switch_can_right;
  delay(300);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  delay(300);
  swing_current_degree[0] = Swing_Left + 65;
  swing_current_degree[1] = Swing_Right + (switch_degree - 10);
  servoArmWrite(chanal_Swing_Right, swing_current_degree[1]);
  delay(100);
  servoArmWrite(chanal_Swing_Left, swing_current_degree[0]);
  servoArmWrite(chanal_Gripper_Left, Close_Left);

  delay(200);
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  delay(200);

  setPlaceTime(place_left_side, place_left_center, place_right_side, place_right_center);
  lift(10);
  delay(800);
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(2, 35, "ASSEMBLY MODE", 0xf800);
  lcdPrintText(2, 65, "  PLACE CAN  ", 0xf800);
  Serial.println();
  Serial.println("นำแท่นสูง 10cm มาวางไว้หน้าหุ่นยนต์ แล้วกดสวิตซ์ A และ B พร้อมกัน");
  while (!switchRead(A) || !switchRead(B)) {};
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoArmWrite(chanal_Swing_Right, Swing_Right + 65);

  Serial.println("หาค่ามือจับซ้าย วางป๋องหลุมซ้าย Swing Left side");
  Swing_Left_side = Swing_Left + 12;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Left_side += 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Left_side -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, Swing_Left_side);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่ามือจับขวา วางป๋องหลุมขวา Swing Right side");
  Swing_Right_side = Swing_Right + 12;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Right_side -= 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Right_side += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, Swing_Right_side);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่ามือจับซ้าย วางป๋องหลุมกลาง Swing Left center");
  Swing_Left_center = Swing_Left - 22;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Left_center += 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Left_center -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, Swing_Left_center);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoArmWrite(chanal_Swing_Left, Swing_Left + 65);
  delay(200);

  Serial.println("หาค่ามือจับขวา วางป๋องหลุมกลาง Swing Right center");
  Swing_Right_center = Swing_Right - 22;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Right_center -= 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Right_center += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, Swing_Right_center);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  servoArmWrite(chanal_Swing_Left, Swing_Left + 65);
  servoArmWrite(chanal_Swing_Right, Swing_Right + 65);
  delay(1000);
  lift(3);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(31, 55, "COMPLETE", 0x07E0);
  beep(50);
  delay(50);
  beep(50);

  Serial.println();
  Serial.println("///////////////////// ASSEMBLYMODE /////////////////////");
  Serial.println("int Swing_Left = " + String(swing_left) + "; //S0 สวิงแขนซ้าย เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Swing_Right = " + String(swing_right) + "; //S1 สวิงแขนขวา เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("////////////////////////////////////////////////////////");
  Serial.println("int Open_Left = " + String(open_left) + "; //S2 อ้ามือ ชุดมือจับมือซ้ายค่ามากยิ่งหุบ");
  Serial.println("int Close_Left = " + String(close_left) + "; //S2 หุบมือ ชุดมือจับมือซ้ายค่าน้อยยิ่งอ้า");
  Serial.println("////////////////////////////////////////////////////////");
  Serial.println("int Open_Right = " + String(open_right) + "; //S3 อ้ามือ ชุดมือจับมือขวา ค่ามากยิ่งหุบ");
  Serial.println("int Close_Right = " + String(close_right) + "; //S3 หุบมือ ชุดมือจับมือขวา ค่าน้อยยิ่งอ้า");
  Serial.println("////////////////////////////////////////////////////////");
  Serial.println("int Tray_In_Left = " + String(tray_in_left) + "; // S4 เก็บถาดด้านซ้ายเข้า ค่ามากยิ่งเข้า");
  Serial.println("int Tray_Out_Left = " + String(tray_out_left) + "; // S4 เอาถาดด้านซ้ายออก ค่าน้อยยิ่งออก");
  Serial.println("int Tray_In_Right = " + String(tray_in_right) + "; // S5 เก็บถาดด้านขวาเข้า ค่าน้อยยิ่งเข้า");
  Serial.println("int Tray_Out_Right = " + String(tray_out_right) + "; // S5 เอาถาดด้านขวาออก ค่ามากยิ่งออก");
  Serial.println("////////////////////////////////////////////////////////");
  Serial.println("int Stock_Left = " + String(stock_left) + "; // S0 สวิงแขนเก็บกระป๋องซ้าย เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Stock_Right = " + String(stock_right) + "; // S1 สวิงแขนเก็บกระป๋องขวา เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("////////////////////////////////////////////////////////");
  Serial.println("//////////////// ASSEMBLYMODE SWITCH CAN ///////////////");
  Serial.println("int swing_switch_can_left = " + String(switch_can_left) + "; //S0 หุบแขนเข้าเพื่อสลับกระป๋อง แขนซ้าย ค่าน้อยยิ่งหุบเข้า");
  Serial.println("int swing_switch_can_right = " + String(switch_can_right) + "; //S1 หุบแขนเข้าเพื่อสลับกระป๋อง แขนขวา ค่าน้อยยิ่งหุบเข้า");
  Serial.println("////////////////////////////////////////////////////////");
  Serial.println("//////////////// ASSEMBLYMODE PLACE CAN ////////////////");
  Serial.println("int Swing_Left_side = " + String(Swing_Left_side) + "; //S0 สวิงแขนซ้าย วางป๋องซ้าย เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Swing_Left_center = " + String(Swing_Left_center) + "; //S0 สวิงแขนซ้าย วางป๋องกลาง เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Swing_Right_side = " + String(Swing_Right_side) + "; //S1 สวิงแขนขวา วางป๋องขวา เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Swing_Right_center = " + String(Swing_Right_center) + "; //S1 สวิงแขนขวา วางป๋องกลาง เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("////////////////////////////////////////////////////////");
}

void assemblyMode_switchCan() {
  lift(0);
  int switch_can_left = Swing_Left - 30;
  int switch_can_right = Swing_Right + 20;
  unsigned long timer_servo = 0;
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  servoArmWrite(chanal_Gripper_Right, Open_Right);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(2, 35, "ASSEMBLY MODE", 0xf800);
  lcdPrintText(2, 65, " SWITCH CAN  ", 0xf800);
  Serial.println();
  Serial.println("โหมดตั้งค่าเซอร์โว สลับกระป๋อง");
  Serial.println("นำกระป๋องใส่มือซ้าย แล้วกดสวิตซ์ A และ B พร้อมกัน");

  delay(200);
  while (!switchRead(A) || !switchRead(B)) {};
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoArmWrite(chanal_Gripper_Left, Close_Left);
  delay(200);
  lift(3);
  servoArmWrite(chanal_Swing_Left, switch_can_left);
  servoArmWrite(chanal_Swing_Right, switch_can_right);
  Serial.println("หาค่า swing switch can left ตั้งค่าแขนซ้าย หรือให้กระป๋องอยู่ตรงกลางเสาลิฟท์");
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      switch_can_left += 1;
      beep(20);
    } else if (switchRead(B)) {
      switch_can_left -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, switch_can_left);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  switch_can_right = Swing_Right - 30;
  servoArmWrite(chanal_Swing_Left, Swing_Left + 40);
  delay(500);
  servoArmWrite(chanal_Swing_Right, switch_can_right);
  delay(500);
  servoArmWrite(chanal_Swing_Left, switch_can_left);
  delay(500);
  Serial.println("หาค่า swing switch can right ตั้งค่าแขนขวาเข้าหากระป๋อง");
  beep(50);
  delay(50);
  beep(50);
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      switch_can_right -= 1;
      beep(20);
    } else if (switchRead(B)) {
      switch_can_right += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, switch_can_right);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoCloseRight();
  delay(200);
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(31, 55, "COMPLETE", 0x07E0);
  beep(50);
  delay(50);
  beep(50);
  delay(1000);

  Serial.println();
  Serial.println("//////////////// ASSEMBLYMODE SWITCH CAN ///////////////");
  Serial.println("int swing_switch_can_left = " + String(switch_can_left) + "; //S0 หุบแขนเข้าเพื่อสลับกระป๋อง แขนซ้าย ค่าน้อยยิ่งหุบเข้า");
  Serial.println("int swing_switch_can_right = " + String(switch_can_right) + "; //S1 หุบแขนเข้าเพื่อสลับกระป๋อง แขนขวา ค่าน้อยยิ่งหุบเข้า");
  Serial.println("////////////////////////////////////////////////////////");

  swing_switch_can_left = switch_can_left;
  swing_switch_can_right = switch_can_right;

  delay(300);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  delay(300);
  swing_current_degree[0] = Swing_Left + 65;
  swing_current_degree[1] = Swing_Right + (switch_degree - 10);
  servoArmWrite(chanal_Swing_Right, swing_current_degree[1]);
  delay(100);
  servoArmWrite(chanal_Swing_Left, swing_current_degree[0]);
  servoArmWrite(chanal_Gripper_Left, Close_Left);

  delay(200);
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  delay(200);
  lift(3);
  while (1) {
    STOP();
    beep(50);
    vTaskResume(switchGripperTaskHandle);
    switchGripper('r', 'l');
    delay(1800);
    vTaskSuspend(switchGripperTaskHandle);
    servoArmWrite(chanal_Swing_Left, Swing_Left);
    servoArmWrite(chanal_Swing_Right, Swing_Right);
    beep(50);

    STOP();
    beep(50);
    vTaskResume(switchGripperTaskHandle);
    switchGripper('l', 'r');
    delay(1800);
    vTaskSuspend(switchGripperTaskHandle);
    servoArmWrite(chanal_Swing_Left, Swing_Left);
    servoArmWrite(chanal_Swing_Right, Swing_Right);
    beep(50);
  }
}

void assemblyMode_placeCan() {
  lift(10);
  delay(800);
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(2, 35, "ASSEMBLY MODE", 0xf800);
  lcdPrintText(2, 65, "  PLACE CAN  ", 0xf800);
  Serial.println();
  Serial.println("นำแท่นสูง 10cm มาวางไว้หน้าหุ่นยนต์ แล้วกดสวิตซ์ A และ B พร้อมกัน");
  while (!switchRead(A) || !switchRead(B)) {};
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่ามือจับซ้าย วางป๋องหลุมซ้าย Swing Left side");
  Swing_Left_side = Swing_Left + 12;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Left_side += 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Left_side -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, Swing_Left_side);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่ามือจับขวา วางป๋องหลุมขวา Swing Right side");
  Swing_Right_side = Swing_Right + 12;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Right_side -= 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Right_side += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, Swing_Right_side);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  Serial.println("หาค่ามือจับซ้าย วางป๋องหลุมกลาง Swing Left center");
  Swing_Left_center = Swing_Left - 22;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Left_center += 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Left_center -= 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Left, Swing_Left_center);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoArmWrite(chanal_Swing_Left, Swing_Left + 65);
  delay(200);

  Serial.println("หาค่ามือจับขวา วางป๋องหลุมกลาง Swing Right center");
  Swing_Right_center = Swing_Right - 22;
  while (1) {
    if (switchRead(A) && switchRead(B)) break;
    else if (switchRead(A)) {
      Swing_Right_center -= 1;
      beep(20);
    } else if (switchRead(B)) {
      Swing_Right_center += 1;
      beep(20);
    }
    servoArmWrite(chanal_Swing_Right, Swing_Right_center);
    delay(200);
  }
  beep(50);
  delay(50);
  beep(50);
  while (switchRead(A) || switchRead(B)) {};

  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  servoArmWrite(chanal_Swing_Left, Swing_Left + 65);
  servoArmWrite(chanal_Swing_Right, Swing_Right + 65);
  delay(1000);
  lift(3);
  lcdClear();
  lcdSetTextSize(2);
  lcdPrintText(31, 55, "COMPLETE", 0x07E0);
  beep(50);
  delay(50);
  beep(50);

  Serial.println();
  Serial.println("//////////////// ASSEMBLYMODE PLACE CAN ////////////////");
  Serial.println("int Swing_Left_side = " + String(Swing_Left_side) + "; //S0 สวิงแขนซ้าย วางป๋องซ้าย เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Swing_Left_center = " + String(Swing_Left_center) + "; //S0 สวิงแขนซ้าย วางป๋องกลาง เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Swing_Right_side = " + String(Swing_Right_side) + "; //S1 สวิงแขนขวา วางป๋องขวา เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("int Swing_Right_center = " + String(Swing_Right_center) + "; //S1 สวิงแขนขวา วางป๋องกลาง เพิ่มง้างออก ลด หุบเข้า");
  Serial.println("////////////////////////////////////////////////////////");
}

void setCan() {
  lift(0);
  delay(300);
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  servoArmWrite(chanal_Gripper_Right, Open_Right);
  delay(300);
  servoArmWrite(chanal_Gripper_Left, Close_Left);
  servoArmWrite(chanal_Gripper_Right, Close_Right);
  delay(300);
  lift(3);
  delay(300);
}

void switchGripperLoop(void *pvParameters) {
  while (1) {
    if (switch_flag == -1) {
      servoArmWrite(chanal_Swing_Right, Swing_Right + 10);
      servoArmWrite(chanal_Gripper_Left, Open_Left);
      servoArmWrite(chanal_Swing_Left, swing_switch_can_left);
      delay(300);
      servoArmWrite(chanal_Swing_Right, swing_switch_can_right);
      delay(300);
      servoCloseLeft();
      delay(300);
      servoArmWrite(chanal_Gripper_Right, Open_Right - 5);
      delay(300);
      servoArmWrite(chanal_Swing_Left, Swing_Left);
      delay(300);
      switch_flag = 0;
    } else if (switch_flag == 1) {
      servoArmWrite(chanal_Swing_Left, Swing_Left + 10);
      servoArmWrite(chanal_Gripper_Right, Open_Right);
      servoArmWrite(chanal_Swing_Right, swing_switch_can_right);
      delay(300);
      servoArmWrite(chanal_Swing_Left, swing_switch_can_left);
      delay(300);
      servoCloseRight();
      delay(300);
      servoArmWrite(chanal_Gripper_Left, Open_Left - 5);
      delay(300);
      servoArmWrite(chanal_Swing_Right, Swing_Right);
      delay(300);
      switch_flag = 0;
    }
    vTaskDelay(10 / portTICK_PERIOD_MS);
  }
}

void switchGripper(char from_gripper, char to_gripper) {
  if (from_gripper == 'l' && to_gripper == 'r') switch_flag = 1;
  else if (from_gripper == 'r' && to_gripper == 'l') switch_flag = -1;
}

void swingGripper(char gripper, int degree) {
  if (gripper == 'l') {
    swing_current_degree[0] = degree;
    servoArmWrite(chanal_Swing_Left, swing_current_degree[0]);
  } else if (gripper == 'r') {
    swing_current_degree[1] = degree;
    servoArmWrite(chanal_Swing_Right, swing_current_degree[1]);
  }
}

void liftLoop(void *pvParameters) {
  const int CLK = 39;
  const int DT = 36;
  float error, previous_error = 0, integral = 0, derivative;
  float p_value, i_value, d_value, motor_speed;
  float Kp = 3.0, Ki = 0.001, Kd = 0.05;

  encoder.attachHalfQuad(DT, CLK);
  encoder.setCount(0);

  long last_encoder_count = 0;
  unsigned long last_change_time = millis();
  const unsigned long timeout_ms = 500;

  int last_lift_target = lift_target;
  bool stopped_due_to_timeout = false;

  while (1) {
    long current_count = encoder.getCount() / 2;
    error = current_count - lift_target;

    // ตรวจจับการเปลี่ยนแปลงของ encoder
    if (abs(abs(current_count) - abs(last_encoder_count)) > 5) {
      last_change_time = millis();
      last_encoder_count = current_count;
    }

    // ตรวจสอบว่ามีการเปลี่ยนแปลง lift_target หรือไม่
    if (lift_target != last_lift_target) {
      // หากเคยหยุดจาก timeout ให้เริ่มใหม่
      stopped_due_to_timeout = false;
      last_change_time = millis();
      integral = 0;
      previous_error = 0;
      last_lift_target = lift_target;
    }

    // หยุดหาก encoder ไม่ขยับเป็นระยะเวลาหนึ่ง
    if (!stopped_due_to_timeout && millis() - last_change_time > timeout_ms) {
      motorWrite(3, 0);
      stopped_due_to_timeout = true;
    }

    // หากอยู่ในสถานะหยุดจาก timeout ให้รอจน lift_target เปลี่ยนก่อนจะกลับมาทำงาน
    if (stopped_due_to_timeout) {
      vTaskDelay(10 / portTICK_PERIOD_MS);
      continue;
    }

    // PID control
    p_value = Kp * error;
    integral += error;
    i_value = Ki * integral;
    derivative = error - previous_error;
    d_value = Kd * derivative;
    motor_speed = p_value + i_value + d_value;

    motor_speed = constrain(motor_speed, -100, 100);

    if (abs(error) >= 5)
      motorWrite(3, motor_speed);
    else
      motorWrite(3, 0);

    previous_error = error;
    vTaskDelay(50 / portTICK_PERIOD_MS);
  }
}

void lift(int position) {
  if (position > 17) position = 17;
  lift_target = position * lift_Sensitivity;
  if (lift_target > 900) lift_target = 900;
}

void stockLoop(void *pvParameters) {
  while (1) {
    if (stock_flag == -1) {  // stock in left
      lift(13);
      while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
      servoWrite(chanal_Stock_Tray_Left, Tray_Out_Left);
      servoArmWrite(chanal_Swing_Left, Stock_Left);
      delay(800);
      lift(9);
      while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
      delay(300);
      servoArmWrite(chanal_Gripper_Left, Close_Left - 15);
      delay(200);
      servoArmWrite(chanal_Gripper_Left, 0);
      delay(200);
      servoWrite(chanal_Stock_Tray_Left, Tray_In_Left);
      delay(200);
      servoArmWrite(chanal_Swing_Left, Swing_Left);
      servoArmWrite(chanal_Gripper_Left, Close_Left);
      lift(3);
      stock_flag = 0;
    } else if (stock_flag == 1) {  // stock out left
      lift(7);
      while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
      servoArmWrite(chanal_Gripper_Left, 0);
      servoArmWrite(chanal_Swing_Left, Stock_Left);
      delay(500);
      servoWrite(chanal_Stock_Tray_Left, Tray_Out_Left);
      delay(200);
      servoArmWrite(chanal_Gripper_Left, Close_Left - Open_Drop_Left);
      delay(300);
      lift(5);
      while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
      delay(300);
      servoArmWrite(chanal_Gripper_Left, Close_Left + 3);
      delay(200);
      lift(15);
      delay(400);
      servoArmWrite(chanal_Swing_Left, Swing_Left);
      servoWrite(chanal_Stock_Tray_Left, Tray_In_Left);
      can_in_gripper[0] = can_in_stock[0];
      can_in_stock[0] = 'u';
      delay(500);
      lift(3);
      servoArmWrite(chanal_Gripper_Left, Close_Left);
      stock_flag = 0;
    } else if (stock_flag == -2) {  // stock in right
      lift(13);
      while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
      servoWrite(chanal_Stock_Tray_Right, Tray_Out_Right);
      servoArmWrite(chanal_Swing_Right, Stock_Right);
      delay(800);
      lift(9);
      while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
      delay(300);
      servoArmWrite(chanal_Gripper_Right, Close_Right - 15);
      delay(200);
      servoArmWrite(chanal_Gripper_Right, 0);
      delay(200);
      servoWrite(chanal_Stock_Tray_Right, Tray_In_Right);
      delay(200);
      servoArmWrite(chanal_Swing_Right, Swing_Right);
      servoArmWrite(chanal_Gripper_Right, Close_Right);
      lift(3);
      stock_flag = 0;
    } else if (stock_flag == 2) {  // stock out right
      lift(7);
      while (abs((encoder.getCount() / 2) - lift_target) > 30) { delay(10); }
      servoArmWrite(chanal_Gripper_Right, 0);
      servoArmWrite(chanal_Swing_Right, Stock_Right);
      delay(500);
      servoWrite(chanal_Stock_Tray_Right, Tray_Out_Right);
      delay(200);
      servoArmWrite(chanal_Gripper_Right, Close_Right - Open_Drop_Right);
      delay(300);
      motorWrite(3, 50);
      delay(150);
      motorStop();
      servoArmWrite(chanal_Gripper_Right, Close_Right + 3);
      delay(200);
      lift(15);
      delay(400);
      servoArmWrite(chanal_Swing_Right, Swing_Right);
      servoWrite(chanal_Stock_Tray_Right, Tray_In_Right);
      can_in_gripper[1] = can_in_stock[1];
      can_in_stock[1] = 'u';
      delay(500);
      lift(3);
      servoArmWrite(chanal_Gripper_Right, Close_Right);
      stock_flag = 0;
    }
    vTaskDelay(100 / portTICK_PERIOD_MS);
  }
}

void stockIn(char stock, char color, bool wait) {
  switch_flag = 0;
  if (stock == 'l') {
    stock_flag = -1;
    can_in_stock[0] = color;
  } else if (stock == 'r') {
    stock_flag = -2;
    can_in_stock[1] = color;
  }
  if (wait == true) {
    while (1) {
      if (stock_flag == 0) break;
      delay(10);
    }
  }
}

void stockOut(char stock, bool wait) {
  switch_flag = 0;
  if (stock == 'l') stock_flag = 1;
  else if (stock == 'r') stock_flag = 2;
  if (wait == true) {
    while (1) {
      if (stock_flag == 0) break;
      delay(10);
    }
  }
}

void moveToCan(float distance) {
  vTaskResume(sonarTaskHandle);
  sonar_enable = 1;
  delay(10);
  unsigned long int timer = millis();
  while (readSonar() > distance || millis() - timer <= 500) FF(15);
  FF(10, 250);
  motorStop();
  vTaskSuspend(sonarTaskHandle);
  sonar_enable = 0;
}

void moveToCanTime(int time) {
  unsigned long int timer = millis();
  while (millis() - timer < time) FF(15);
  motorStop();
}

void shakeGripper(char gripper) {
  int increment = 1;
  int delayTime = 25;
  int swingRange = 10;
  int count_swing = 0;
  if (gripper == 'a') count_swing = 1;
  else count_swing = 3;
  for (int i = 0; i < count_swing; i++) {
    if (gripper == 'l' || gripper == 'a') {
      for (int i = 0; i <= swingRange; i += increment) {
        servoArmWrite(chanal_Swing_Left, swing_current_degree[0] - i);
        if (gripper == 'a') servoArmWrite(chanal_Swing_Right, swing_current_degree[1] - i);
        delay(delayTime);
      }
      for (int i = 0; i <= swingRange * 2; i += increment) {
        servoArmWrite(chanal_Swing_Left, swing_current_degree[0] - swingRange + i);
        if (gripper == 'a') servoArmWrite(chanal_Swing_Right, swing_current_degree[1] - swingRange + i);
        delay(delayTime);
      }
      for (int i = 0; i <= swingRange; i += increment) {
        servoArmWrite(chanal_Swing_Left, swing_current_degree[0] + swingRange - i);
        if (gripper == 'a') servoArmWrite(chanal_Swing_Right, swing_current_degree[1] + swingRange - i);
        delay(delayTime);
      }
    }
    if (gripper == 'r' || gripper == 'a') {
      for (int i = 0; i <= swingRange; i += increment) {
        servoArmWrite(chanal_Swing_Right, swing_current_degree[1] - i);
        if (gripper == 'a') servoArmWrite(chanal_Swing_Left, swing_current_degree[0] - i);
        delay(delayTime);
      }
      for (int i = 0; i <= swingRange * 2; i += increment) {
        servoArmWrite(chanal_Swing_Right, swing_current_degree[1] - swingRange + i);
        if (gripper == 'a') servoArmWrite(chanal_Swing_Left, swing_current_degree[0] - swingRange + i);
        delay(delayTime);
      }
      for (int i = 0; i <= swingRange; i += increment) {
        servoArmWrite(chanal_Swing_Right, swing_current_degree[1] + swingRange - i);
        if (gripper == 'a') servoArmWrite(chanal_Swing_Left, swing_current_degree[0] + swingRange - i);
        delay(delayTime);
      }
    }
  }
}

void dropCan(char gripper) {
  if (gripper == 'l') {
    servoArmWrite(chanal_Gripper_Left, Close_Left - Open_Drop_Left);
    shakeGripper('l');
    delay(200);
    servoArmWrite(chanal_Gripper_Left, Open_Left - 10);
  } else if (gripper == 'r') {
    servoArmWrite(chanal_Gripper_Right, Close_Right - Open_Drop_Right);
    shakeGripper('r');
    delay(200);
    servoArmWrite(chanal_Gripper_Right, Open_Right - 10);
  } else if (gripper == 'a') {
    servoArmWrite(chanal_Gripper_Left, Close_Left - Open_Drop_Left);
    servoArmWrite(chanal_Gripper_Right, Close_Right - Open_Drop_Right);
    shakeGripper('a');
    delay(200);
    servoArmWrite(chanal_Gripper_Left, Open_Left - 10);
    servoArmWrite(chanal_Gripper_Right, Open_Right - 10);
  }
}

void stock() {
  // ซ้าย ขวา สีป๋องสลับกัน
  if (mode_Switch_Can_Color == true) {
    if (((hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'l')) ||
        ((hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') && (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'l')) ||
        ((hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'c')) ||
        ((hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') && (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'c')) ||
        ((hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') && (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'r')) ||
        ((hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') && (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'r'))) {
      if (can_in_stock[0] == 'u') {
        stockIn('l', can_in_gripper[0], true);
        can_in_gripper[0] = 'u';
      } else if (can_in_stock[1] == 'u') {
        stockIn('r', can_in_gripper[1], true);
        can_in_gripper[1] = 'u';
      }
      delay(200);
      lift(3);
      retractArmIN_Can();
      delay(200);
    }
  }
  // ซ้าย ขวา สีป๋องเหมือนกัน
  if (can_in_gripper[0] == can_in_gripper[1]) {
    if (can_in_gripper[0] == 'r') {
      if (can_in_stock[0] == 'u') {
        stockIn('l', can_in_gripper[0], true);
        can_in_gripper[0] = 'u';
        can_in_gripper[1] = 'r';
      } else if (can_in_stock[1] == 'u') {
        stockIn('r', can_in_gripper[0], true);
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'u';
      } else {
        while (1) {
          beep(10000);
        }
      }
    } else {
      if (can_in_gripper[0] == 'g') can_in_gripper[0] = 'l';
      else if (can_in_gripper[0] == 'y') can_in_gripper[0] = 'c';
      if (can_in_stock[1] == 'u') {
        stockIn('r', can_in_gripper[0], true);
        can_in_gripper[1] = 'u';
      } else if (can_in_stock[0] == 'u') {
        stockIn('l', can_in_gripper[0], true);
        can_in_gripper[1] = can_in_gripper[0];
        can_in_gripper[0] = 'u';
      } else {
        while (1) {
          beep(10000);
        }
      }
    }
    delay(200);
    lift(3);
    retractArmIN_Can();
    delay(200);
  }

  // ซ้าย ขวา สีป๋องไม่เหมือนกัน
  else {
    lift(3);
    retractArmIN_Can();
  }
}

void autoPickCan(int pick_height) {
  servoArmWrite(chanal_Swing_Left, Swing_Left );
  servoArmWrite(chanal_Swing_Right, Swing_Right );
  servoArmWrite(chanal_Gripper_Left, Open_Left);
  servoArmWrite(chanal_Gripper_Right, Open_Right);
  lift(pick_height);
  if (pick_height != 1) moveToCan(pick_can_distance);
  else moveToCan(pick_can_floor);
  delay(100);
  servoCloseLeft();
  servoCloseRight();
  delay(200);
  lift(pick_height + 3);
  delay(300);
  can_in_gripper[0] = readColor('l');
  can_in_gripper[1] = readColor('r');
  count_pick += 1;
  if (can_in_gripper[0] == can_in_gripper[1]) {
    if (count_pick == 3 && (can_in_gripper[0] == can_in_gripper[1])) {
      State_EndMission = true;
    }
    // BB(30, 200);
    // if (can_in_gripper[0] == 'r') {
    //   if (can_in_stock[0] == 'u') {
    //     stockIn('l', can_in_gripper[0], true);
    //     can_in_gripper[0] = 'u';
    //     can_in_gripper[1] = 'r';
    //   } else if (can_in_stock[1] == 'u') {
    //     stockIn('r', can_in_gripper[0], true);
    //     can_in_gripper[0] = 'r';
    //     can_in_gripper[1] = 'u';
    //   } else {
    //     while (1) {
    //       beep(10000);
    //     }
    //   }
    // } else {
    //   if (can_in_gripper[0] == 'g') can_in_gripper[0] = 'l';
    //   else if (can_in_gripper[0] == 'y') can_in_gripper[0] = 'c';
    //   if (can_in_stock[1] == 'u') {
    //     stockIn('r', can_in_gripper[0], true);
    //     can_in_gripper[1] = 'u';
    //   } else if (can_in_stock[0] == 'u') {
    //     stockIn('l', can_in_gripper[0], true);
    //     can_in_gripper[1] = can_in_gripper[0];
    //     can_in_gripper[0] = 'u';
    //   } else {
    //     while (1) {
    //       beep(10000);
    //     }
    //   }
    // }
    // BB(30, 250);
    BB(30, 400);
    lift(3);
  } else if (mode_Switch_Can_Color == false) {
    if (((hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'g')) ||
    ((hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') && (can_in_gripper[0] == 'y' && can_in_gripper[1] == 'g')) ||
    ((hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') && (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'y')) ||
    ((hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') && (can_in_gripper[0] == 'g' && can_in_gripper[1] == 'y')) ||
    ((hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') && (can_in_gripper[0] == 'y' && can_in_gripper[1] == 'r')) ||
    ((hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') && (can_in_gripper[0] == 'g' && can_in_gripper[1] == 'r'))) {
      swingGripper('l', swing_switch_can_left);
      swingGripper('r', Swing_Right + 10);
      delay(200);
      vTaskResume(switchGripperTaskHandle);
      delay(10);
      lift(pick_height);
      delay(200);
      for (int i = Close_Left; i > Open_Left; i -= 1) {
        servoArmWrite(chanal_Gripper_Left, i);
        delay(5);
      }
      delay(200);
      swingGripper('l', swing_switch_can_left + 5);
      lift(pick_height + 3);
      BB(30, 400);
      switchGripper('r', 'l');
      delay(1800);
      swingGripper('l', Swing_Left_side);
      servoArmWrite(chanal_Gripper_Right, Open_Right - 10);
      swingGripper('r', swing_switch_can_right + 5);
      delay(200);
      if (pick_height != 0) FF(15, switch_moveToPickCan_distance);  // ระยะทางเดินเข้าไปหยิบป๋องที่สลับไว้บนแท่น
      else FF(15, switch_moveToPickCan_distance_floor);             // ระยะทางเดินเข้าไปหยิบป๋องที่สลับไว้ที่พื้น
      lift(pick_height);
      delay(300);
      servoCloseRight();
      delay(200);
      lift(pick_height + 2);
      vTaskSuspend(switchGripperTaskHandle);
      servoArmWrite(chanal_Swing_Left, Swing_Left);
      servoArmWrite(chanal_Swing_Right, Swing_Right);
      delay(200);
      if (hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') {
        can_in_gripper[0] = 'l';
        can_in_gripper[1] = 'r';
      }
      if (hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') {
        can_in_gripper[0] = 'l';
        can_in_gripper[1] = 'c';
      }
      if (hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') {
        can_in_gripper[0] = 'c';
        can_in_gripper[1] = 'r';
      }
      if (hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') {
        can_in_gripper[0] = 'c';
        can_in_gripper[1] = 'l';
      }
      if (hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') {
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'c';
      }
      if (hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') {
        can_in_gripper[0] = 'r';
        can_in_gripper[1] = 'l';
      }
      delay(200);
      BB(30, 400);
      lift(3);
    } else {
      if (can_in_gripper[0] == 'r') can_in_gripper[0] = 'r';
      else if (can_in_gripper[0] == 'g') can_in_gripper[0] = 'l';
      else if (can_in_gripper[0] == 'y') can_in_gripper[0] = 'c';
      if (can_in_gripper[1] == 'r') can_in_gripper[1] = 'r';
      else if (can_in_gripper[1] == 'g') can_in_gripper[1] = 'l';
      else if (can_in_gripper[1] == 'y') can_in_gripper[1] = 'c';
      BB(30, 400);
      lift(3);
    }
  } else if (mode_Switch_Can_Color == true) {
    if (can_in_gripper[0] == 'r') can_in_gripper[0] = 'r';
    else if (can_in_gripper[0] == 'g') can_in_gripper[0] = 'l';
    else if (can_in_gripper[0] == 'y') can_in_gripper[0] = 'c';
    if (can_in_gripper[1] == 'r') can_in_gripper[1] = 'r';
    else if (can_in_gripper[1] == 'g') can_in_gripper[1] = 'l';
    else if (can_in_gripper[1] == 'y') can_in_gripper[1] = 'c';
    BB(30, 400);
    lift(3);
  }
  retractArmIN_Can();    // พับแขนเข้าตัว (ป้องกันมือสั่นและกระป๋องสั่น)
}

void placeCan1(int drop_height, int distance, char from_gripper, char drop_point) {
  bool switch_can = 0;
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  servoArmWrite(chanal_Gripper_Left, Close_Left + 3);
  servoArmWrite(chanal_Gripper_Right, Close_Right + 3);
  lift(drop_height + 3);
  if (from_gripper == 'l' && drop_point == 'l') {
    swingGripper('l', Swing_Left_side);
    swingGripper('r', Swing_Right + 65);
  } else if (from_gripper == 'l' && drop_point == 'c') {
    swingGripper('l', Swing_Left_center);
    swingGripper('r', Swing_Right + 65);
  } else if (from_gripper == 'r' && drop_point == 'r') {
    swingGripper('l', Swing_Left + 65);
    swingGripper('r', Swing_Right_side);
  } else if (from_gripper == 'r' && drop_point == 'c') {
    swingGripper('l', Swing_Left + 65);
    swingGripper('r', Swing_Right_center);
  } else {
    vTaskResume(switchGripperTaskHandle);
    delay(10);
    switchGripper(from_gripper, drop_point);
    switch_can = 1;
  }
  moveToCan(4.0);
  motorWrite(1, 10);
  motorWrite(2, 10);
  delay(400);
  motorStop();
  delay(200);
  setAngleOffset();
  current_degree = 0;
  BB(10, distance);
  lift(drop_height + 1);
  delay(200);
  if (switch_can == 0) dropCan(from_gripper);
  else dropCan(drop_point);
  delay(200);
  vTaskSuspend(switchGripperTaskHandle);
}

void test() {
  autoPickCan(0);
}

void autoPlaceCan2(int drop_height, char left_gripper, char right_gripper) {
  servoArmWrite(chanal_Gripper_Left, Close_Left + 3);
  servoArmWrite(chanal_Gripper_Right, Close_Right + 3);
  lift(drop_height + 3);
  if (left_gripper == 'r' && right_gripper == 'l') {
    lift(1);
    delay(300);
    swingGripper('l', swing_switch_can_left);
    swingGripper('r', Swing_Right);
    vTaskResume(switchGripperTaskHandle);
    delay(10);
    delay(200);
    for (int i = Close_Left; i > Open_Left; i -= 1) {
      servoArmWrite(chanal_Gripper_Left, i);
      delay(10);
    }
    delay(200);
    servoArmWrite(chanal_Gripper_Left, Open_Left);
    lift(12);
    delay(600);
    switchGripper('r', 'l');
    delay(1800);
    servoArmWrite(chanal_Gripper_Right, Open_Right - 10);
    swingGripper('r', swing_switch_can_right);
    delay(200);
    lift(0);
    delay(600);
    servoCloseRight();
    delay(200);
    lift(drop_height + 3);
    vTaskSuspend(switchGripperTaskHandle);
    servoArmWrite(chanal_Swing_Left, Swing_Left);
    servoArmWrite(chanal_Swing_Right, Swing_Right);
    placeCan1(drop_height, place_left_side, 'l', 'l');
    BB(30, 400);
    delay(200);
    placeCan1(drop_height, place_right_side, 'r', 'r');
  } else {
    if (left_gripper == 'l' && right_gripper == 'r') {
      placeCan1(drop_height, place_left_side, 'l', 'l');
      BB(30, 400);
      delay(200);
      placeCan1(drop_height, place_right_side, 'r', 'r');
    } else if (left_gripper == 'l' && right_gripper == 'c') {
      placeCan1(drop_height, place_right_center, 'r', 'c');
      BB(30, 400);
      delay(200);
      placeCan1(drop_height, place_left_side, 'l', 'l');
    } else if (left_gripper == 'c' && right_gripper == 'r') {
      placeCan1(drop_height, place_left_center, 'l', 'c');
      BB(30, 400);
      delay(200);
      placeCan1(drop_height, place_right_side, 'r', 'r');
    } else {
      if (left_gripper == 'c') {
        placeCan1(drop_height, place_left_center, 'l', 'c');
        BB(30, 400);
        lift(drop_height + 3);
        vTaskResume(switchGripperTaskHandle);
        delay(10);
        switchGripper('r', 'l');
        delay(1800);
        placeCan1(drop_height, place_left_side, 'l', 'l');
        vTaskSuspend(switchGripperTaskHandle);
      } else if (right_gripper == 'c') {
        placeCan1(drop_height, place_right_center, 'r', 'c');
        BB(30, 400);
        lift(drop_height + 3);
        vTaskResume(switchGripperTaskHandle);
        delay(10);
        switchGripper('l', 'r');
        delay(1800);
        placeCan1(drop_height, place_right_side, 'r', 'r');
        vTaskSuspend(switchGripperTaskHandle);
      }
    }
  }
  delay(200);
}

/* --------------------------------------แบบเช็คหลุมวางป๋อง-------------------------------------- */
void placeCan_Fix(int drop_height) {
  // case 1 เขียว เหลือง แดง
  if (hold[0] == 'g' && hold[1] == 'y' && hold[2] == 'r') {
    // เขียว เหลือง
    if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'l', 'c');

    // เขียว แดง
    else if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'l', 'r');

    // เหลือง เขียว
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'c', 'l');

    // เหลือง แดง
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'c', 'r');

    // แดง เขียว
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'r', 'l');

    // แดง เหลือง
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'r', 'c');

    // กรณีมีกระป๋องเดียวในมือ เขียว แดง เหลือง
    else {
      /*---------------------------มือซ้าย----------------------------*/
      if (can_in_gripper[0] == 'r') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('l', 'r');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_right_side, 'r', 'r');
      }

      if (can_in_gripper[0] == 'l')
        placeCan1(drop_height, place_left_side, 'l', 'l');

      else if (can_in_gripper[0] == 'c')
        placeCan1(drop_height, place_left_center, 'l', 'c');

      /*---------------------------มือขวา----------------------------*/
      else if (can_in_gripper[1] == 'l') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('r', 'l');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_left_side, 'l', 'l');
      }

      else if (can_in_gripper[1] == 'r')
        placeCan1(drop_height, place_right_side, 'r', 'r');

      else if (can_in_gripper[1] == 'c')
        placeCan1(drop_height, place_right_center, 'r', 'c');
    }
  }

  // case 2 เขียว แดง เหลือง
  if (hold[0] == 'g' && hold[1] == 'r' && hold[2] == 'y') {
    // เขียว เหลือง
    if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'l', 'r');

    // เขียว แดง
    else if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'l', 'c');

    // เหลือง เขียว
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'r', 'l');

    // เหลือง แดง
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'r', 'c');

    // แดง เขียว
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'c', 'l');

    // แดง เหลือง
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'c', 'r');

    // กรณีมีกระป๋องเดียวในมือ เขียว แดง เหลือง
    else {
      /*---------------------------มือซ้าย----------------------------*/
      if (can_in_gripper[0] == 'c') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('l', 'r');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_right_side, 'r', 'r');
      }

      if (can_in_gripper[0] == 'l')
        placeCan1(drop_height, place_left_side, 'l', 'l');

      else if (can_in_gripper[0] == 'r')
        placeCan1(drop_height, place_left_center, 'l', 'c');

      /*---------------------------มือขวา----------------------------*/
      else if (can_in_gripper[1] == 'l') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('r', 'l');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_left_side, 'l', 'l');
      }

      else if (can_in_gripper[1] == 'c')
        placeCan1(drop_height, place_right_side, 'r', 'r');

      else if (can_in_gripper[1] == 'r')
        placeCan1(drop_height, place_right_center, 'r', 'c');
    }
  }

  // case 3 เหลือง เขียว แดง
  if (hold[0] == 'y' && hold[1] == 'g' && hold[2] == 'r') {
    // เขียว เหลือง
    if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'c', 'l');

    // เขียว แดง
    else if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'c', 'r');

    // เหลือง เขียว
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'l', 'c');

    // เหลือง แดง
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'l', 'r');

    // แดง เขียว
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'r', 'c');

    // แดง เหลือง
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'r', 'l');

    // กรณีมีกระป๋องเดียวในมือ เขียว แดง เหลือง
    else {
      /*---------------------------มือซ้าย----------------------------*/
      if (can_in_gripper[0] == 'r') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('l', 'r');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_right_side, 'r', 'r');
      }

      else if (can_in_gripper[0] == 'c')
        placeCan1(drop_height, place_left_side, 'l', 'l');

      else if (can_in_gripper[0] == 'l')
        placeCan1(drop_height, place_left_center, 'l', 'c');

      /*---------------------------มือขวา----------------------------*/
      if (can_in_gripper[1] == 'c') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('r', 'l');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_left_side, 'l', 'l');
      }

      else if (can_in_gripper[1] == 'r')
        placeCan1(drop_height, place_right_side, 'r', 'r');

      else if (can_in_gripper[1] == 'l')
        placeCan1(drop_height, place_right_center, 'r', 'c');
    }
  }

  // case 4 เหลือง แดง เขียว
  if (hold[0] == 'y' && hold[1] == 'r' && hold[2] == 'g') {
    // เขียว เหลือง
    if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'r', 'l');

    // เขียว แดง
    else if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'r', 'c');

    // เหลือง เขียว
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'l', 'r');

    // เหลือง แดง
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'l', 'c');

    // แดง เขียว
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'c', 'r');

    // แดง เหลือง
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'c', 'l');

    // กรณีมีกระป๋องเดียวในมือ เหลือง แดง เขียว
    else {
      /*---------------------------มือซ้าย----------------------------*/
      if (can_in_gripper[0] == 'l') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('l', 'r');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_right_side, 'r', 'r');
      }

      else if (can_in_gripper[0] == 'c')
        placeCan1(drop_height, place_left_side, 'l', 'l');

      else if (can_in_gripper[0] == 'r')
        placeCan1(drop_height, place_left_center, 'l', 'c');

      /*---------------------------มือขวา----------------------------*/
      if (can_in_gripper[1] == 'c') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('r', 'l');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_left_side, 'l', 'l');
      }

      else if (can_in_gripper[1] == 'l')
        placeCan1(drop_height, place_right_side, 'r', 'r');

      else if (can_in_gripper[1] == 'r')
        placeCan1(drop_height, place_right_center, 'r', 'c');
    }
  }

  // case 5 แดง เขียว เหลือง
  if (hold[0] == 'r' && hold[1] == 'g' && hold[2] == 'y') {
    // เขียว เหลือง
    if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'c', 'r');

    // เขียว แดง
    else if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'c', 'l');

    // เหลือง เขียว
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'r', 'c');

    // เหลือง แดง
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'r', 'l');

    // แดง เขียว
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'l', 'c');

    // แดง เหลือง
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'l', 'r');

    // กรณีมีกระป๋องเดียวในมือ แดง เขียว เหลือง
    else {
      /*---------------------------มือซ้าย----------------------------*/
      if (can_in_gripper[0] == 'c') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('l', 'r');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_right_side, 'r', 'r');
      }

      else if (can_in_gripper[0] == 'r')
        placeCan1(drop_height, place_left_side, 'l', 'l');

      else if (can_in_gripper[0] == 'l')
        placeCan1(drop_height, place_left_center, 'l', 'c');

      /*---------------------------มือขวา----------------------------*/
      else if (can_in_gripper[1] == 'r') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('r', 'l');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_left_side, 'l', 'l');
      }

      else if (can_in_gripper[1] == 'c')
        placeCan1(drop_height, place_right_side, 'r', 'r');

      else if (can_in_gripper[1] == 'l')
        placeCan1(drop_height, place_right_center, 'r', 'c');
    }
  }

  // case 6 แดง เหลือง เขียว
  if (hold[0] == 'r' && hold[1] == 'y' && hold[2] == 'g') {
    // เขียว เหลือง
    if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'r', 'c');

    // เขียว แดง
    else if (can_in_gripper[0] == 'l' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'r', 'l');

    // เหลือง เขียว
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'c', 'r');

    // เหลือง แดง
    else if (can_in_gripper[0] == 'c' && can_in_gripper[1] == 'r')
      autoPlaceCan2(drop_height, 'c', 'l');

    // แดง เขียว
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'l')
      autoPlaceCan2(drop_height, 'l', 'r');

    // แดง เหลือง
    else if (can_in_gripper[0] == 'r' && can_in_gripper[1] == 'c')
      autoPlaceCan2(drop_height, 'l', 'c');

    // กรณีมีกระป๋องเดียวในมือ แดง เหลือง เขียว
    else {
      /*---------------------------มือซ้าย----------------------------*/
      if (can_in_gripper[0] == 'l') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('l', 'r');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_right_side, 'r', 'r');
      }

      else if (can_in_gripper[0] == 'r')
        placeCan1(drop_height, place_left_side, 'l', 'l');

      else if (can_in_gripper[0] == 'c')
        placeCan1(drop_height, place_left_center, 'l', 'c');

      /*---------------------------มือขวา----------------------------*/
      else if (can_in_gripper[1] == 'r') {
        vTaskResume(switchGripperTaskHandle);
        switchGripper('r', 'l');
        delay(1800);
        vTaskSuspend(switchGripperTaskHandle);
        placeCan1(drop_height, place_left_side, 'l', 'l');
      }

      else if (can_in_gripper[1] == 'l')
        placeCan1(drop_height, place_right_side, 'r', 'r');

      else if (can_in_gripper[1] == 'c')
        placeCan1(drop_height, place_right_center, 'r', 'c');
    }
  }
}

void autoPlaceCan(int drop_height, bool increment_count = true) {
  if (state_stock == true) {
    if (can_in_stock[0] != 'u') {
      stockOut('l', true);
      can_in_gripper[1] = 'u';
    } else if (can_in_stock[1] != 'u') {
      stockOut('r', true);
      can_in_gripper[0] = 'u';
    }
    placeCan_Fix(drop_height);
    BB(30, 450);
    lift(2);
    servoArmWrite(chanal_Swing_Left, Swing_Left);
    servoArmWrite(chanal_Swing_Right, Swing_Right);
    servoCloseLeft();
    servoCloseRight();
  } else {
    servoArmWrite(chanal_Gripper_Left, Close_Left + 3);
    servoArmWrite(chanal_Gripper_Right, Close_Right + 3);
    lift(drop_height + 3);
    placeCan_Fix(drop_height);
    checkPlace(drop_height, station_count);
    if (increment_count) station_count += 1;
    servoArmWrite(chanal_Swing_Left, Swing_Left);
    servoArmWrite(chanal_Swing_Right, Swing_Right);
    servoCloseLeft();
    servoCloseRight();
    if (count_pick == 3) {
      if (State_EndMission == true) {
        state_stock = true;
        Can4();
      } else EndMission();
      motorStop();
      while (1)
        ;
    } else {
    }
  }
}

void checkPlace(int drop_height, int current_station) {
  if (can_in_gripper[0] == 'l' || can_in_gripper[1] == 'l') station[current_station][0] = 'l';
  if (can_in_gripper[0] == 'c' || can_in_gripper[1] == 'c') station[current_station][1] = 'c';
  if (can_in_gripper[0] == 'r' || can_in_gripper[1] == 'r') station[current_station][2] = 'r';

  for (byte i = 0; i < 3; i++) {
    if (station[current_station][i] == 'u') {
      if (i == 0) {
        if (can_in_stock[0] == 'l') {
          BB(30, 400);
          delay(100);
          stockOut('l', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            lift(0);
            delay(800);
            setCan();
            lift(15);
            delay(800);
          }
          delay(200);
          can_in_gripper[0] = 'l';
          can_in_gripper[1] = 'u';
          autoPlaceCan(drop_height, false);
          station_backward = false;
        } else if (can_in_stock[1] == 'l') {
          BB(30, 400);
          delay(100);
          stockOut('r', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            lift(0);
            delay(800);
            setCan();
            lift(15);
            delay(800);
          }
          delay(200);
          can_in_gripper[0] = 'u';
          can_in_gripper[1] = 'l';
          autoPlaceCan(drop_height, false);
          station_backward = false;
        }
      } else if (i == 1) {
        if (can_in_stock[0] == 'c') {
          BB(30, 400);
          delay(100);
          stockOut('l', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            lift(0);
            delay(800);
            setCan();
            lift(15);
            delay(800);
          }
          delay(200);
          can_in_gripper[0] = 'c';
          can_in_gripper[1] = 'u';
          autoPlaceCan(drop_height, false);
          station_backward = false;
        } else if (can_in_stock[1] == 'c') {
          BB(30, 400);
          delay(100);
          stockOut('r', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            lift(0);
            delay(800);
            setCan();
            lift(15);
            delay(800);
          }
          delay(200);
          can_in_gripper[0] = 'u';
          can_in_gripper[1] = 'c';
          autoPlaceCan(drop_height, false);
          station_backward = false;
        }
      } else if (i == 2) {
        if (can_in_stock[0] == 'r') {
          BB(30, 400);
          delay(100);
          stockOut('l', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            lift(0);
            delay(800);
            setCan();
            lift(15);
            delay(800);
          }
          delay(200);
          can_in_gripper[0] = 'r';
          can_in_gripper[1] = 'u';
          autoPlaceCan(drop_height, false);
          station_backward = false;
        } else if (can_in_stock[1] == 'r') {
          BB(30, 400);
          delay(100);
          stockOut('r', true);
          if (drop_height >= 15 && mode_setCan_Stock == 1) {
            lift(0);
            delay(800);
            setCan();
            lift(15);
            delay(800);
          }
          delay(200);
          can_in_gripper[0] = 'u';
          can_in_gripper[1] = 'r';
          autoPlaceCan(drop_height, false);
          station_backward = false;
        }
      }
    }
  }
  if (station_backward == true) {
    BB(30, 400);
  }
  station_backward = true;
  servoArmWrite(chanal_Swing_Left, Swing_Left);
  servoArmWrite(chanal_Swing_Right, Swing_Right);
  lift(3);
}

void setPlaceTime(int timeleft_side, int timeleft_center, int timeright_side, int timeright_center) {
  place_left_side = timeleft_side;        // ค่าระยะจอดกรณีมือซ้ายวางกระป๋องซ้าย
  place_left_center = timeleft_center;    // ค่าระยะจอดกรณีมือซ้ายวางกระป๋องกลาง
  place_right_side = timeright_side;      // ค่าระยะจอดกรณีมือขวาวางกระป๋องขวา
  place_right_center = timeright_center;  // ค่าระยะจอดกรณีมือขวาวางกระป๋องกลาง
}

void setStandPlace(char color_left, char color_center, char color_right) {
  hold[0] = color_left;
  hold[1] = color_center;
  hold[2] = color_right;
}

void modesetCanStock(bool state) {
  mode_setCan_Stock = state;
}

void modeSwitchCanColor(bool state) {
  mode_Switch_Can_Color = state;
}